# Deploy — Wild 1.7.0 + Vault 1.6.0 + Guide 2.5.3

## Upload jars (remove old versions)
- plugins/MAVOWild-1.7.0.jar
- plugins/MAVOVault-1.6.0.jar
- plugins/MAVOGuide-2.5.3.jar

Restart recommended (Vault data shape extended; Wild config gains defaults).

## Post-restart
Wild range/blacklist apply automatically. To refresh Wild holo text to "2,000–400,000":
re-run portal corners (same spots):
  /wild portal pos1   (bottom corner)
  /wild portal pos2   (top opposite)

Vault:
- Existing single rooms keep working (legacy playerroom migrated on first use).
- Sneak + right-click YOUR door when room is full → Expand Up GUI.
- Sneak + right-click unlocked chest → rename/recolor sign.
- First unlock of each slot auto-places a sign if missing.

Guide auto-opens once (content v10).
