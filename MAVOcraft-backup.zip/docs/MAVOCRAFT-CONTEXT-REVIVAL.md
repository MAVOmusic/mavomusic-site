# MAVOcraft — FULL CONTEXT & REVIVAL DOCUMENT
Last updated: 2026-09-01 (ChunkBorders 1.2.0 red/blue ground-hugging lines; ClaimChunk perms fix via lp)

Read this file top-to-bottom to fully restore working context for the MAVOcraft
Minecraft server project. Everything here is CONFIRMED DEPLOYED unless marked otherwise.

---

## 1. WHO / WHAT / WHERE

- Owner: Kick streamer "MAVO" — Java name **MAVOmusicYT** (OP, LuckPerms owner,
  UUID 53322438-a7a2-4eb2-bb2b-1c648a43dccf). Whitelist: MAVOmusicYT, NecroCaticGames.
- Host: **PebbleHost Premium 4GB** ($9/mo), Ryzen 9 EU node.
- Server: **Paper 26.2 build 119**, Java 25, IP **185.206.148.185:25567**,
  domain `mavocraft.my.pebble.host`, BlueMap web map port **8156**, Geyser (Bedrock crossplay) UDP **19132**.
- Sky spawn plaza: center **-2578 / 200 / -1684**, protection cube ±60 (only OP+creative build;
  villager interaction allowed). Wishing well at -2587 201 -1684. Wild Portal north, Home Portal south.
- User plays Java. Crossplay via Geyser+floodgate. World was FULLY RESET once; keep plugin suite.




## CHUNKBORDERS 1.2.0 + CLAIMCHUNK PERMISSIONS FIX (2026-09-01)
BUG 1 - /chunk claim etc. OP-only: ClaimChunk 0.0.25-FIX3's plugin.yml uses
the SINGULAR key `permission:` instead of `permissions:`, so Bukkit never
registers its default-true player nodes; unregistered nodes = OP-only.
FIX (permanent, one console line): 
  lp group default permission set claimchunk.player true
(every basic subcommand - claim/unclaim/list/info/access/give/name/alert/
auto/show/scan - accepts claimchunk.player). Never remove this node.
BUG 2 - broken border lines: old renderer used the MOTION_BLOCKING heightmap
(includes LEAVES) -> lines rendered on treetops/roofs, looked gappy on the
ground. MAVOChunkBorders 1.2.0 (src at _Old/src-chunkborders, rebuilt from
decompiled 1.1.0): MOTION_BLOCKING_NO_LEAVES heightmap + down-scan from
player Y+3 when surface is above head; defaults changed PURPLE glass ->
RED_STAINED_GLASS border + BLUE_STAINED_GLASS corners (no-purple rule; guide
already said red/blue - no guide bump needed). Deploy requires deleting the
old plugins/MAVOChunkBorders/config.yml so new defaults generate.
Also verify plugins/ClaimChunk/config.yml has economy.useEconomy=false
(MAVOChunkPrices is the only charger).

## STANDING MAINTENANCE PROTOCOL (user-mandated - ALWAYS follow)
1. EVERY update that changes gameplay, prices, systems or flows MUST also
   update MAVOGuide (changelog bump + affected feature/tutorial pages),
   rebuild MAVOGuide-x.y.z.jar and deliver it alongside the feature jar.
2. After EVERY delivered update: rebuild MAVOcraft-backup.zip (jars/ docs/
   sources/), print its SHA-256, and append what changed to this document.
   User uploads the backup to GitHub - it is the disaster-recovery source.
3. This document is the single source of truth for reviving context.

## OWNER RANK = TAG ONLY (since 2026-09-01 fresh-start stream)
MAVOmusicYT plays as a NORMAL player: de-opped, no fly/creative/supermod.
"owner" LuckPerms group carries ONLY the prefix (priority 100, red OWNER tag),
no admin permission nodes. Moderation happens from PebbleHost CONSOLE only
(ban/kick/whitelist/lp). If any MAVO plugin admin action is needed, run it
from console or temp-op then de-op. Setup commands (console):
  lp creategroup owner            (already exists)
  lp group owner clear            (strip any permission nodes, keep meta)
  lp group owner meta setprefix 100 "&4&lOWNER &r"
  lp user MAVOmusicYT parent add owner
Result: red OWNER tag in chat/TAB, zero elevated permissions in game.

## VAULT 1.5.0 - LOCK-STATE PORTAL HOLOS (2026-09-01)
Plaza gate portals (vault / portalroom) now spawn TWO stacked TextDisplays:
- "UNLOCKED" variant (green check, usage hint) - visibleByDefault
- "LOCKED" variant (red padlock, "One-time entry: <price> coins",
  "Step in to unlock") - hidden by default
holoVisibilityLoop (every 40t, players within 64 blocks) uses
p.showEntity/hideEntity to show each player exactly one variant based on
hasAccessRaw. gateHolos map holds [openUuid, lockUuid]; portalremove sweep
still removes both via the portalholo_<id> PDC tag. Return portals unchanged
(single green holo). Prices in locked holo read live from config at (re)spawn
- rerun /vaultroom reload after price changes.

## LATEST SYSTEMS (2026-09-01)

### Rooms built by datapack (world/datapacks/MAVOcraft-builder-datapack.zip)
Functions: build_all / portal_room / portal_frames / vault_shell / vault_build /
purge_mobs / demolish_all. pack_format 81 (exact, no range - ranges error on Paper 26.2).
Functions forceload their own areas (fills silently fail in unloaded chunks!).
- PORTAL ROOM shell X -2450..-2350, Y198..228, Z -1700..-1670, bedrock, deepslate
  lining, red nether brick pillars, froglight grid every 8 blocks (light>=11,
  no mob spawns), doorway west face. 26 portal frames (13 N + 13 S), 3w x 4t,
  black concrete void, themed frame blocks, every 7 blocks starting x=-2446
  (frame opening interior x = L+1..L+3 where L=-2446+7*slot).
- VAULT shell X -2800..-2700, Y198..238, Z -1705..-1665. INTERIOR = Vault 2.0:
  6 levels (floor walk Y 200/206/212/218/224/230), gold corridor z-1685 with
  glowstone edges each level, ladders both ends (x=-2798 east-facing,
  x=-2702 west-facing), 96 private rooms = 8 columns x 2 sides x 6 levels.
  Room column A=-2793+11*col (interior A..A+8, door at A+4), north rooms
  z-1703..-1689 (door z-1689), south z-1681..-1667 (door z-1681), themed wall
  blocks (16 material rotation shifted per level), birch door + oak wall sign
  above (y0+2), 15 double chests per room in bank layout (non-touching),
  sea lantern ceiling + glowstone floor lights per room.

### MAVOVault 1.4.0 (deployed; source _Old/src-vault)
- Gates: vault 50,000 / portalroom 25,000 one-time (regions in config gates.*.region,
  RE-RUN pos1/pos2 gate vault to cover Y198..238 all levels!).
- Plaza portals ACTIVE (portals.vault / portals.portalroom via pos1/pos2 +
  /vaultroom portal <id>): locked players get unlock GUI, unlocked get 3s
  countdown then teleport to portal-dest.<id> (set via /vaultroom portaldest
  <id> standing at arrival spot; fallback just inside doorway).
- Return portals: portals.vault_return / portalroom_return (green/gold FX),
  3s countdown -> return-spawn.* (set via /vaultroom returnspawn at plaza).
- PRIVATE ROOMS: room table hardcoded matching datapack (LEVEL_Y, colA etc).
  Room ids L<1-6><N|S><1-8>. data.yml: rooms.<id>.owner / rooms.<id>.slots
  (list of unlocked unit ints 0..14), playerroom.<uuid> -> room id (ONE room
  per player). Claim = chest-price (5,000) via door/chest right-click GUI ->
  slot #1 free + door sign written gold/red "<name>'s Vault". Slot ladder
  SLOT_PRICES = 0,1000,1000,2500,2500,2500,5000x4,10000x5 (full room 81,500
  total incl. claim). Sealed chest right-click = unlock GUI (charged on click
  only). Doors: owner-only (creative admin bypass). NOTHING breakable in vault
  region except admin creative. Old per-chest holo/rename system REMOVED.
- Admin: /vaultroom roominfo | releaseroom <roomId|player> | signs (rewrite 96
  signs) | portalremove <id> | portaldest <id> | returnspawn | reload.

### MAVOPortalRoom 1.0.1 (deployed; source _Old/src-portalroom)
- 26 jump portals, geometry derived from frame math (NO in-game setup).
  TABLE rows: side|slot|id|kind|key|landing|ymin|ymax|price|r|g|b|cc|name|desc.
  North biomes: desert 1000, savanna 1200, swamp 1500, darkforest 2000,
  taiga 2500, flower 3000, peaks 3500, jungle 4000, bamboo 4500, ice 6000,
  cherry 7000, badlands 8000, mushroom 10000.
  South danger: shipwreck 1500, mineshaft 3000, dripstone 3500, lush 4000,
  pyramid 4500, witchhut 5000, jungletemple 5500, deepcaves 6000, outpost 7000,
  monument 9000, stronghold 11000, trial 13000, deepdark (ancient_city) 15000.
- Per-portal FX veil (unique DustOptions color) + small holo (name/desc/price).
- Jump: balance pre-check (red error title if poor), 7s countdown, step-out
  instant cancel, monsters-12-blocks block, charge ONLY after successful
  teleport. Creative = free 3s countdown (NOT instant - caused accidents).
- Destination: random angle, 25,000-400,000 blocks from room, rejects within
  2x100 blocks of this portal's last 50 zones (data.yml zones.<id> list
  "x,z"). BIOME kind -> locateNearestBiome (mushroom radius 12k step 256,
  else 6.4k/128); STRUCTURE -> locateNearestStructure r5000; CAVE landing
  scans y-range for air pocket else carves 3x3 glowstone pocket. SURFACE
  lands highest block (lava capped with obsidian).
- Admin: /portalroom list | clearzones <id|all> | reload. Config: world,
  min/max-distance, blacklist-radius/size, countdown-seconds.

### Player reset procedure
See RESET-PROGRESS.md (root + in backup): per-file deletion list to zero one
player (Essentials userdata, world playerdata/advancements/stats, MAVO*
data.yml files, ClaimChunk data, lp user clear). Never delete config.yml or
the four never-folder-delete plugins (EconomyShopGUI/LuckPerms/TAB/MAVOWild).

## 2. DEPLOYED PLUGIN SUITE (boot-verified versions)

Third-party: BlueMap 5.23, ClaimChunk 0.0.25-FIX3, CoreProtect 24.0, EssentialsX 2.22.0
(+Chat/+Spawn), Geyser+floodgate, LuckPerms 5.5.78, PlaceholderAPI 2.12.3, TAB 6.1.2,
Vault 1.7.3-b131, EconomyShopGUI 7.2.1.

Custom MAVO plugins (all sources in `sources/` of the backup archive):
| Jar | What it does |
|---|---|
| MAVOAchievements-1.5.0 | 14 lifetime categories incl. 6 gambling + museum; public API `externalProgress(Player,String,long)` + `externalHighwater(...)` |
| MAVOCasino-1.1.0 | Lucky Louie: 5 games (Cups 2.7x, Flip 2x@47.5%, Dice 2.3x ties-lose, Wheel 0-10x weights 34/25/15/16/9/1, TNT Tiles 1.2→32x, 2 TNT, cash-out). 10 attempts/10 MC days. Bets 100-5000 coins or 1-10 lucky coins. Reads gambler stick (material→luck), awards gambler XP via Professions.externalXp |
| MAVOChunkBorders-1.1.0 | always-visible claim borders + 1-chunk no-build buffer |
| MAVOChunkPrices-1.0.1 | tier table 1 free/5x100/5x250/5x500/5x1000/10x1500/10x2000/10x2500, max 51 |
| MAVOCommunityGoals-1.1.1 | donation pots instead of chunk tax |
| MAVOCurator-1.0.0 | THE MUSEUM: 103 auto-built sections, 1413 items. Grey/green GUI, click-donate 1, Deposit Crate (dump+close), dupes bounce with error. Section complete = items×1000⛃. Milestones 25/50/75/100% → LP curator25/50/75/100 + 10k/25k/50k/250k coins. Feeds `museum` achievement |
| MAVODeathChest-1.0.0 | locked grave 30 min |
| MAVOEvents-1.1.0 | Lucky Hour / Coin Rain / Mob Hunt |
| MAVOGuide-2.4.0 | guide GUI content v6 (auto-opens once/version), tutorial chapters, feature pages incl. Vault private rooms + Portal Room jumps |
| MAVOHomes-1.2.0 | bed right-click in OWNED chunks only binds /home; renameable |
| MAVOHud-2.0.0 | %mavohud_day/time/coords% placeholders for TAB sidebar |
| MAVOLuckyCoins-1.4.0 | 1% grind drops, wishing well (/wish disabled, toss coin with Q), /ccollect every 10 MC days, **admin: /ccollect give [n]** |
| MAVOPets-1.0.0 | pets |
| MAVOProfessions-3.13.0 | 9 professions (8 + GAMBLER max-1000), tool-bound XP, cap 999, prestige 250/420/666/999, per-profession rank-commands, public `externalXp(Player,String,double)`, tier note/name support, bound tools can't be placed as blocks |
| MAVOQuests-1.4.0 | daily board 10 quests |
| MAVOShopNPC-1.3.1 | villager NPCs running arbitrary commands + /shopnpc holo floating signs (scale 0.9) |
| MAVOSpawn-1.0.0 | spawn protection cube |
| MAVOStreaks-1.0.0 | login streaks |
| MAVOTrades-1.0.0 | master trader stalls |
| MAVOWanderer-1.0.0 | curated wandering trader stock (83 offers) |
| MAVOWild-1.6.2 | Wild+Home portals (pos1 bottom → fly → pos2 top), liquid-glass FX, 3s stand-in teleport, step-out instant cancel, /spawn for all, orphan holo sweep. Player /wild REMOVED (portal only) |

## 3. KEY CROSS-PLUGIN CONTRACTS (do not break)

- Lucky Coin identity: SUNFLOWER, name `&e&l⛀ Lucky Coin`, PDC byte
  `mavoluckycoins:luckycoin`, Unbreaking-1 + HIDE_ENCHANTS. Casino replicates it; well accepts casino coins.
- Profession tools: PDC `mavoprofessions:proftool` = "profId:branchId",
  `mavoprofessions:profowner` = player UUID, `mavoprofessions:proflock` byte (enchant-block).
- Casino reads gambler stick by MATERIAL (must match professions config tiers):
  STICK 1% / BAMBOO 2% / BONE 3.5% / SUGAR_CANE 5% / POINTED_DRIPSTONE 6.5% / BREEZE_ROD 8% /
  END_ROD 10% (+LP gambler) / LIGHTNING_ROD 12% (+LP 777) / BLAZE_ROD 15% (+mavocasino.pokercards emote).
- Achievements categories used by other plugins: betting, luckybets, winnings, luckywins,
  fortune (highwater), luckyhoard (highwater), museum.
- Curator refuses: renamed items, proflock-tagged, luckycoin-tagged; blacklists spawn eggs /
  creative-only items. SURVIVAL-only like ALL progress systems.
- Everything progression-related counts ONLY in SURVIVAL mode.

## 4. LP GROUPS (all created in console, confirmed)

flex(250)/yeman(420)/satan(666)/god(999) prestige; gambler (Gambler L250), 777 (L500);
curator25/50/75/100. Owner prefix priority 100 must outrank all.
⚠ NOTE: console showed `?` instead of ✦ in curator prefixes — console charset only, verify
in-game; if actually broken re-run setprefix with a simpler symbol like *.

## 5. STANDING RULES / USER PREFERENCES (hard requirements)

- NO purple anywhere → red or red/blue gradient. Currency symbol ⛃. Sell = 20% of buy.
- Villager-first economy: shop deliberately 5-10x expensive; villager trading is the way.
- Ores/raw must cost MORE than smelted (Fortune exploit guard) — v4 shops deployed.
- All teleports: 3s, cancel-on-move, blocked if monsters within 12 blocks; portals cancel on step-out.
- No chat spam: professions use bossbar; sidebar lists ALL professions.
- Floating holo signs: small scale (NPC 0.9 / well 1.9 / portal 2.2); never require chat-paste
  of long commands; /shopnpc holo auto-replaces; Wild sweeps orphan signs within 8 blocks.
- GUI-first: all info NPCs use GUI pages with Back+Quit. Tab-completion on commands.
- Gambling: in-game currency ONLY.
- User's config reset method = folder deletion. NEVER folder-delete: EconomyShopGUI, LuckPerms,
  TAB, MAVOWild (portal coords live there). Delete only specific config.yml, keep data.yml.
- Workspace rule: keep NEWEST deliverables in workspace root; move superseded into `_Old/`.
  Delete build targets/uploads after every build (stay under limits).
- Deliverables: agent builds all jars; user uploads via PebbleHost file manager.

## 6. BUILD RECIPE (sandbox)

```
ls /tmp/jdk/bin/java || (redownload JDK 25: adoptium api v3 binary latest/25/ga/linux/x64/jdk/hotspot/normal/eclipse -> /tmp/jdk)
chmod +x /home/user/_Old/apache-maven-3.9.9/bin/mvn
export JAVA_HOME=/tmp/jdk PATH=/tmp/jdk/bin:/home/user/_Old/apache-maven-3.9.9/bin:$PATH
cd <src-dir> && mvn -q package -DskipTests
```
- paper-api 26.2.build.48-alpha (papermc repo), VaultAPI 1.7.1 (jitpack com.github.MilkBowl),
  placeholderapi 2.11.6 (only professions). Local repo `.m2` in workspace root.
- ALWAYS bump: plugin.yml version + pom `<version>` + pom `<finalName>`.
- /tmp gets wiped often — check JDK before every build session.
- Verify configs INSIDE jar after resource edits (`unzip -p target/X.jar config.yml | grep ...`).

## 7. KNOWN PITFALLS (do not retry)

- Adventure showBossBar broken on this Paper — use Bukkit boss API.
- Action bar position is client-fixed — HUD lives in TAB sidebar.
- Console-dispatch of Essentials /spawn breaks — performCommand + bypass flag.
- Long /summon text_display > 256 chars — plugin commands only.
- Holo removal by stored UUID alone unreliable — pair with PDC-tag area sweep.
- CFR decompile needs ~4-5 generic fixes per class. Grep-filtered mvn output can hide errors.
- python .replace() silently no-ops — use asserts.
- Cosmetic boot noise to IGNORE: Essentials "unsupported server version", Vault update check,
  BlueMap manual-save WARN, TAB %mavohud_time% hint, "Re-applied protection to 0 shop NPC(s)",
  sun.misc.Unsafe warnings, ESGUI spawner-provider + Debug mode lines.

## 8. RELOAD COMMANDS (never global /reload)

/ess reload, /sreload, /chunk admin reload, /geyser reload, /borders reload, /tab reload,
/papi reload, /chunkprice reload, /goal reload, /quest reload, /ach reload, /profession reload,
/updates reload, /spawnprot reload, /museum reload, /wish well (re-place well holo).
Portal refresh: re-run pos1 (bottom corner) then pos2 (opposite TOP corner, fly).

## 9. SPAWN NPC ROSTER (spawn + holo commands in TEST-COMMANDS-FULL.md style)

Profession_Master (professions GUI), Tutorial_Guide, Update_Crier, Achievement_Keeper,
Lucky_Louie (`/shopnpc spawn Lucky_Louie casino`), The_Curator (`/shopnpc spawn The_Curator museum`,
holo `&d&l✦ THE MUSEUM ✦|&fOne of everything. Bring me wonders!`).

## 10. OUTSTANDING BACKLOG

- Confirm `time set 0` done after reset; achievements/streaks data.yml zeroing if wanted.
- Essentials disabled-commands (sethome/home/delhome vs MAVOHomes) in-game verify.
- Recruiter LP group idea; build contest (deferred); lottery (prepared, deploy later).
- MD manual refresh (portals/warmup/well/sidebar/guide2/no-wild/holo/casino/museum) — stale.
- User testing Museum + Casino + Gambler right now; watch for feedback.

## 11. RESTORING FROM THE BACKUP ARCHIVE

Archive layout (`MAVOcraft-backup.zip`):
- `jars/` — all 21 current MAVO plugin jars, ready to upload to `plugins/`.
- `sources/` — full Maven source tree for every plugin (src-*/pom.xml + src/main/...).
  Rebuild any of them with the recipe in §6.
- `configs/` — tab-config.yml (TAB sidebar w/ 9 professions), achievements-config.yml,
  esgui-config.yml, MAVOcraft-shops-villager-economy-v4.tar.gz (28 ESGUI shop/section files).
- `docs/` — manuals, checklists, this file.

To revive an agent session from zero: give the agent this file + the archive URL; it downloads,
extracts to workspace, moves everything into `_Old/` except current deliverables, and continues.
