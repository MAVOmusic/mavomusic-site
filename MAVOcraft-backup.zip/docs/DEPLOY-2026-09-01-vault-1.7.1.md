# Deploy — Vault 1.7.1 (block-above tax + wipe)

## Upload
plugins/MAVOVault-1.7.1.jar

## Block-above tax
Claiming an EMPTY room that sits **directly above someone else's room**
costs **chest-price × 100** (default: 5,000 × 100 = **500,000 ⛃**).

Owner expanding via their own door is still only **2× what they paid**.

Config: `block-above-multiplier: 100` in plugins/MAVOVault/config.yml
(add if missing after first boot — plugin copies defaults only for new keys if you use copyDefaults; otherwise set manually).

## Fresh start for MAVOmusicYT
```
/vaultroom wipeplayer MAVOmusicYT
```
Releases ALL their rooms (signs reset), clears playerrooms, revokes
vault + portalroom gate access. They rebuy gate (50k) then a room (5k).

Or access only:
```
/vaultroom wipeaccess MAVOmusicYT
```

## Startup log check (your paste)
No MAVOVault errors. "Refreshed 15 vault chest sign(s)" = healthy.
Essentials "unsupported server version" is noise on Paper 26.2.
ShopNPC "0 shop NPC(s)" means config empty / chunks not loaded yet —
run `/shopnpc resholo` near plaza if holos missing.
