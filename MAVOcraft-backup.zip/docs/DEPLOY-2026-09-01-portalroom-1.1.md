# Deploy — MAVOPortalRoom 1.1.0

## Upload
plugins/MAVOPortalRoom-1.1.0.jar

## Fixes
### Shipwreck
- Lands ON/NEAR the wreck (wood/chest scan), not a random inland hill.
- Underwater: small prismarine platform + sea lantern so you don't drown.
- Signs point at wreck coords.
- **Buried Treasure explorer map** added to inventory (real map cursor → dig site).
  Hold map and walk until the X is centered, then dig.

### Mineshaft
- Scans for rails / fences / planks / cobwebs near structure origin.
- Lands beside them with glow platform.
- **4 oak signs**: direction (N/S/E/W), UP/DOWN, distance, coords.
- Torch path 6 blocks toward the shaft mark.
- If nothing found: carved platform + 4 torch tunnels outward + tip signs.

### Structures generally
- Retries locate up to 12 far origins (was often failing once).
- Larger locate radius (config `structure-locate-radius: 6400`).
- Loads 3×3 chunks around destination.
