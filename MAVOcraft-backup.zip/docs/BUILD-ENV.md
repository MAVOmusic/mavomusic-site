# MAVOcraft build env (this workspace)

```bash
export JAVA_HOME=/tmp/jdk
export PATH=/tmp/jdk/bin:/home/user/_Old/apache-maven-3.9.9/bin:$PATH
cd /home/user/_Old/src-<plugin> && mvn -q package -DskipTests
# jar lands in target/MAVO*-x.y.z.jar
```

- JDK 25 Temurin at `/tmp/jdk` (wiped often — re-fetch via adoptium if missing)
- Maven 3.9.9 at `/home/user/_Old/apache-maven-3.9.9`
- CFR 0.152 at `/home/user/_Old/cfr.jar`
- Paper API `26.2.build.48-alpha`, VaultAPI 1.7.1 (jitpack)
- Local `.m2` caches under `~/.m2` after first resolve

## Layout
| Path | What |
|---|---|
| `jars/` | Current deliverable jars |
| `_Old/src-*` | Maven source trees (edit + rebuild here) |
| `_extract/<jar-name>/` | Unpacked jar contents (classes, embedded config/plugin.yml, pom) |
| `_extract/_decompiled/` | CFR dumps for reference |
| `_Old/jars/` | Backup copy of jars |
