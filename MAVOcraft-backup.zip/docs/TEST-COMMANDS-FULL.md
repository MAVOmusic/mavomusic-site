# ✅ MAVOcraft Full Test Sheet — every plugin, old & new

Run as **MAVOmusicYT** (op). Do the two jar swaps FIRST (ChunkPrices 1.0.1, CommunityGoals 1.1.1), restart, then test top to bottom.

---

## 0. Boot sanity
- [ ] `/version` → Paper 26.2-119
- [ ] `/plugins` → all MAVO plugins green, versions: ChunkPrices **1.0.1**, CommunityGoals **1.1.1**, Professions **3.10.0**, Quests **1.3.1**, everything else 1.x green

---

## 1. MAVOGuide (NEW)
- [ ] Log in → after ~3s the guide GUI auto-opens with welcome message (first time per version)
- [ ] Click the **★ What's New book** → changelog prints in chat
- [ ] Click any feature icon (e.g. Professions) → how-to + commands print in chat
- [ ] `/updates` reopens it; `/guide`, `/mods`, `/features` all work
- [ ] Relog → GUI does **NOT** auto-open again (already seen v1)
- [ ] Edit `plugins/MAVOGuide/config.yml` → `version: 2` → `/updates reload` → relog → popup returns saying "updated to v2" *(set back to 1 after, or leave it)*

## 2. MAVOTrades (NEW)
- [ ] `/mtrade` → usage line shows
- [ ] `/mtrade spawn librarian` → "Master Librarian" appears, name visible, doesn't walk (AI off)
- [ ] Right-click it → trades list: Mending 48em+book, Efficiency V, Fortune III, Silk Touch, etc.
- [ ] Buy something → stock does NOT run out, price does NOT drift
- [ ] Hit it → no damage (invulnerable)
- [ ] `/mtrade spawn smith`, `farmer`, `collector` → each has its themed trades (collector PAYS emeralds for heart of the sea etc.)
- [ ] `/mtrade list` → all 4 listed with coords
- [ ] Stand next to one → `/mtrade remove` → gone
- [ ] Tab-complete: `/mtrade ` suggests spawn/remove/list; `/mtrade spawn ` suggests the 4 types

## 3. MAVOStreaks (NEW)
- [ ] On login you got: `🔥 Login streak: 1 day +⛃20` (arrives ~3s after join)
- [ ] `/bal` → balance increased by 20
- [ ] `/streak` → "Your streak: 1 day (best 1)"
- [ ] `/streak top` → leaderboard shows you at #1
- [ ] Relog → NO second payout today (once per calendar day)

## 4. MAVOEvents (NEW)
- [ ] `/event` → "No event running right now"
- [ ] `/event list` → 5 events listed with colors
- [ ] `/event start coinrain` → broadcast + sound; every 30s a random online player gets ⛃5–20
- [ ] `/event` → shows COIN RAIN live with minutes left
- [ ] `/event stop` → "has ended" broadcast
- [ ] `/event start mobhunt` → kill any hostile mob → `⚔ +2-4` in chat + coins
- [ ] `/event start fishingfrenzy` → catch a fish → `🎣 +3-6`
- [ ] `/event start minersrush` → mine a NATURAL ore → coins; place an ore yourself and mine it → NO coins
- [ ] `/event start luckyhour` → then check `plugins/MAVOLuckyCoins` behavior: coin drops noticeably more often while mining; after `/event stop` back to 1%

## 5. MAVOPets (NEW)
- [ ] `/pets` → red/blue GUI with 10 pets + info book
- [ ] Click Cat (⛃500) with enough balance → bought, balance drops, menu refreshes green
- [ ] Click Cat again → baby cat spawns, named "MAVOmusicYT's Cat", follows you
- [ ] Run 20+ blocks away → it teleports/pathfinds to you
- [ ] Hit it → can't be hurt; right-click → nothing (no breeding/sitting)
- [ ] Buy + summon a second pet → first one is replaced (one at a time)
- [ ] Click active pet in GUI → dismissed ("went home")
- [ ] Relog → pet gone from world, still owned in `/pets`, summon free
- [ ] Try buying with insufficient coins → red "You need ⛃…" + villager no-sound

## 6. MAVODeathChest (NEW)
- [ ] Put junk items in inventory, `/kill` → chest appears at death spot, message with coords
- [ ] `/grave` → lists the grave with ~30 min left
- [ ] Second account (or ask a friend): they CANNOT open it ("That grave isn't yours") and CANNOT break it
- [ ] Put a hopper under it → nothing gets extracted
- [ ] You open it, take everything, close → chest deletes itself
- [ ] `/grave` → "No active graves"
- [ ] (Optional) set `expire-minutes: 1` in config, restart, die again, wait 1 min near it → chest bursts, items pop out

## 7. MAVOWild
- [ ] `/wild` → teleports 500–4000 blocks out, safe landing (no lava/water/void)
- [ ] `/rtp` → alias works
- [ ] Immediately `/wild` again → cooldown message (you have `mavowild.nocooldown`? then it works — test cooldown on a non-op account)

## 8. MAVOLuckyCoins
- [ ] `/ccollect` → free ⚜ Lucky Coin (sunflower with glint)
- [ ] `/ccollect` again → "come back later" style message (10 MC-day window)
- [ ] Hold coin in MAIN hand → `/wish` → coin consumed, prize given, broadcast to chat
- [ ] `/wish` with empty hand → error message
- [ ] Grind mining a few minutes → occasional 1% coin drop (or run `/event start luckyhour` to speed-test)
- [ ] Place a stone block, mine it → never drops a coin (placed-block guard)

## 9. MAVOWanderer
- [ ] Summon one: `/summon wandering_trader` → right-click → 7–9 offers, ALL useful (buckets, hoppers, shulker shell, sponge…), zero junk (no dye-for-emerald garbage)

## 10. MAVOProfessions (3.10.0)
- [ ] `/prof` → GUI opens, 8 professions
- [ ] Chop natural logs with axe → bossbar + sidebar XP ticks (no chat spam)
- [ ] Place a log, chop it → NO XP
- [ ] `/prof check` → levels list
- [ ] `/prof top miner` → leaderboard
- [ ] Reward claim at a tier level → enchanted tool, lore shows "max rollable" values
- [ ] (You're already FLEXER — check `/lp user MAVOmusicYT info` shows flex group, and tab shows **[OWNER]** prefix, NOT [FLEX])

## 11. MAVOAchievements
- [ ] `/ach` → GUI, 7 categories, woodcutting separate from mining
- [ ] Mine 10 blocks → progress ticks
- [ ] Check a milestone reward is the SMALL amount (⛃60–75 range, not 400+) — confirms new config is live

## 12. MAVOQuests (1.3.1)
- [ ] `/quest` → board with 10 quests
- [ ] `/quest list` → text version
- [ ] Complete an easy one → coins paid (modest amounts)
- [ ] `/quest reroll` (admin) → board refreshes
- [ ] Mystery rewards: should NEVER be diamond/emerald/golden apple/ender pearl

## 13. MAVOChunkPrices (1.0.1) + ClaimChunk
- [ ] `/chunkprice` → tier table + your progress
- [ ] `/chunk claim` on fresh account = FREE first chunk; on yours = next tier price deducted
- [ ] Claim until a tier boundary → price steps up correctly
- [ ] `/chunk unclaim` → chunk released
- [ ] `/chunk access <someone>` → they can build in your claim

## 14. MAVOChunkBorders (1.1.0)
- [ ] Stand in/near a claim → block-level borders visible (red/blue)
- [ ] `/borders` → toggles display off/on
- [ ] Non-owner tries to build in the 1-chunk buffer ring around your claim → blocked; you (owner/bypass) can build

## 15. MAVOCommunityGoals (1.1.1)
- [ ] `/goal` → 3 goals listed with progress
- [ ] `/donate <goal> 10` → balance -10, goal progress +10
- [ ] `/goal donate <goal> 10` → same via long form

## 16. MAVOShopNPC
- [ ] `/shopnpc spawn Legendary_Trader shop` → NPC appears
- [ ] Right-click NPC → shop GUI opens
- [ ] `/shopnpc list` → shows it; hit it → invulnerable
- [ ] (Log said "Re-applied protection to 0 shop NPC(s)" — correct for a fresh/NPC-less world)

## 17. EconomyShopGUI
- [ ] `/shop` → opens; **spot-check villager-economy prices**: Diamond Chestplate ≈ ⛃28,224 · Bread ≈ ⛃6,300 · Emerald ≈ ⛃3,540 (if you see cheap prices, the tarball isn't extracted — `/sreload` after extracting)
- [ ] Buy screen → qty defaults to 1, buttons −All/−16/−8/−4/−2/−1 and +1…+All
- [ ] `/sell hand` with a stack of cobble → paid ~20% rates

## 18. EssentialsX
- [ ] `/bal` → shows ⛃ symbol
- [ ] `/pay <player> 1` → transfers
- [ ] `/sethome` → `/home` returns you
- [ ] `/spawn` works
- [ ] `/tpa <player>` → they get accept/deny prompt
- [ ] Balance sidebar shows coins + amount on same line

## 19. LuckPerms + TAB
- [ ] `/lp info` → responds
- [ ] Tab list: red-blue MAVOcraft gradient header, you show **[OWNER]** (dark red/blue), sorted properly
- [ ] `/lp group flex info` etc. → prestige groups exist with prefixes priority 2–5

## 20. BlueMap / Geyser / CoreProtect
- [ ] Browser: `http://mavocraft.my.pebble.host:8156` → 3D map loads
- [ ] `/geyser version` → responds (Bedrock join test needs the UDP port set up)
- [ ] `/co inspect` → toggle inspector, place/break a block → shows who/when (CoreProtect actually enabled on 26.2 now!)

---

## Before you start: 2 jar swaps
1. Delete `MAVOChunkPrices-1.0.0.jar` → upload **MAVOChunkPrices-1.0.1.jar**
2. Delete `MAVOCommunityGoals-1.1.0.jar` → upload **MAVOCommunityGoals-1.1.1.jar**
3. Restart. (No config deletion needed for these two.)

## Remember
- Re-inserting a jar does **not** reset its config — plugin folders survive. Fresh defaults = delete that plugin's `config.yml` too (keep `data.yml` unless you want progress wiped).
- When all boxes tick ✅ → say the word and we do the **world-reset checklist**.
