# MAVOcraft — full personal progress reset (play fresh, no cheats)

Goal: wipe ALL progress for **MAVOmusicYT** (coins, professions, achievements,
quests, museum, vault room, streaks, pets, homes, claims, lucky coins, casino,
portal-jump history, inventory, position) while keeping the SERVER (rooms,
portals, shop, plugins) exactly as built. You already de-opped yourself — good.

**Order matters: do all file deletions WHILE THE SERVER IS STOPPED.**

## 0. Stop the server

## 1. Essentials (money, homes, last-location, playtime)
Delete only YOUR userdata file (NOT the whole folder — never folder-delete Essentials):
```
plugins/Essentials/userdata/53322438-a7a2-4eb2-bb2b-1c648a43dccf.yml
```
(That's your UUID from the logs. NecroCaticGames' file stays.)

## 2. Player data (inventory, XP, position, advancements, stats)
In the world folder delete YOUR entries only:
```
world/playerdata/53322438-a7a2-4eb2-bb2b-1c648a43dccf.dat
world/playerdata/53322438-a7a2-4eb2-bb2b-1c648a43dccf.dat_old
world/advancements/53322438-a7a2-4eb2-bb2b-1c648a43dccf.json
world/stats/53322438-a7a2-4eb2-bb2b-1c648a43dccf.json
```
Next login you spawn at world spawn as a brand-new player.

## 3. MAVO plugin data — per-player wipes
These store per-player progress under your UUID or name. For each, EITHER
delete the single data/players file (if only you have progress it's simplest)
OR edit your UUID section out. Since only you and NecroCaticGames exist and a
fresh start for both is fine, deleting the whole DATA FILE (not the folder,
not config.yml!) is safe:

```
plugins/MAVOProfessions/data.yml        (profession XP/levels/prestige)
plugins/MAVOAchievements/data.yml       (achievement progress)
plugins/MAVOQuests/data.yml             (quest board progress/claims)
plugins/MAVOCurator/data.yml            (museum collection)
plugins/MAVOStreaks/data.yml            (login streaks)
plugins/MAVOPets/data.yml               (pets)
plugins/MAVOLuckyCoins/data.yml         (coin collect cooldowns/wishes)
plugins/MAVOCasino/data.yml             (attempts, lucky sticks)
plugins/MAVOHomes/data.yml              (bed-bound homes)
plugins/MAVODeathChest/data.yml         (open graves, if any)
plugins/MAVOVault/data.yml              (vault gate access + room claims)
plugins/MAVOPortalRoom/data.yml         (used-zone blacklists - optional:
                                         keep it if you want old jump zones
                                         to stay blacklisted; delete for
                                         fully fresh)
plugins/MAVOChunkPrices/data.yml        (chunks purchased counter)
```
If a file doesn't exist, skip it. **Do NOT touch any config.yml.**

## 4. Chunk claims
```
plugins/ClaimChunk/data/claimedChunks.json   (or the /data folder contents)
```
This wipes claim records (yours + Necro's). If Necro has claims to keep, ask
me instead and I'll give a per-player edit.

## 5. LuckPerms (prestige ranks/prefixes you earned in testing)
Start the server AFTER the file deletions, then from CONSOLE:
```
lp user MAVOmusicYT clear
lp user MAVOmusicYT parent set default
```
(Console keeps working even though you de-opped in game.)

## 6. TAB / HUD / Guide
No per-player progress worth keeping — but the Guide remembers you saw v5.
Delete:
```
plugins/MAVOGuide/data.yml
```
so the v6 guide auto-opens on your first fresh login (nice for stream).

## 7. What NOT to touch
- Any config.yml anywhere
- plugins/EconomyShopGUI / LuckPerms / TAB / MAVOWild folders (never folder-delete)
- world region files (the rooms/plaza stay)
- MAVOVault config.yml (portal + gate regions live there, NOT in data.yml)
- MAVOShopNPC (NPCs are world entities + its data holds their protection)
- MAVOCommunityGoals data (server-wide, not personal - keep or reset, your call)

## 8. Start the server, log in
You should see: 0 coins... actually 50 ⛃ if Essentials gives a starting
balance (that's the configured start for everyone - fair), empty professions
sidebar, guide v6 auto-opens, no vault room, no access to Vault/Portal Room
gates. Play exactly like any new community member. Have a great stream!
