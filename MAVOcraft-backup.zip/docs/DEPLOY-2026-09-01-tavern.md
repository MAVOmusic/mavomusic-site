# Deploy — MAVOTavern 1.0.0 (spawn night skip)

## Log check
Boot log is CLEAN. No action needed on Essentials/BlueMap/TAB/ESGUI cosmetic lines.

## Upload
- `plugins/MAVOTavern-1.0.0.jar` (new)
- `plugins/MAVOGuide-2.5.2.jar` (replace 2.5.1)

Restart (or load + ensure soft depends). Then in-game **creative** at plaza:

```
/tavern build
```

Stand on empty plaza floor facing the doorway direction you want. Builds a 5×5
spruce hut with red bed + holo. Or place any bed and:

```
/tavern setbed
```

Test at night (survival, 100+ coins): right-click bed → pay → dawn.
Second click same night → locked until noon.

```
/tavern info
/tavern unlock
```

## Files of note
- `plugins/MAVOTavern/config.yml` — price 100, wake-time 1000, bed coords
- `plugins/MAVOTavern/data.yml` — per-player last sleep day
