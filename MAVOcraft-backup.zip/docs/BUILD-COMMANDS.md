# MAVOcraft builder v3 - rooms + 26 jump-portal frames

New in v3: `/function mavocraft:portal_frames` builds 26 portal frames in the Portal Room (13 biome portals on the NORTH wall, 13 danger portals on the SOUTH wall). Rooms already built? Just run portal_frames alone.

## Portal lineup (west->east)
NORTH (biomes): Desert Dunes (1000⛃), Savanna Plains (1200⛃), Murky Swamp (1500⛃), Dark Forest (2000⛃), Giant Taiga (2500⛃), Flower Fields (3000⛃), Jagged Peaks (3500⛃), Deep Jungle (4000⛃), Bamboo Grove (4500⛃), Ice Spikes (6000⛃), Cherry Blossom (7000⛃), Badlands Mesa (8000⛃), Mushroom Isle (10000⛃)

SOUTH (danger): Shipwreck Waters (1500⛃), Lost Mineshaft (3000⛃), Dripstone Caverns (3500⛃), Lush Caves (4000⛃), Desert Tomb (4500⛃), Witch Hut (5000⛃), Jungle Temple (5500⛃), Deep Caves (6000⛃), Pillager Outpost (7000⛃), Ocean Monument (9000⛃), Stronghold (11000⛃), Trial Chambers (13000⛃), THE DEEP DARK (15000⛃)

## `/function mavocraft:build_all`
```
say [MAVO builder] Forceloading build areas...
forceload add -2810 -1715 -2690 -1655
forceload add -2460 -1710 -2340 -1660
function mavocraft:portal_room
function mavocraft:portal_frames
function mavocraft:vault_shell
function mavocraft:vault_rooms
function mavocraft:vault_chests
function mavocraft:purge_mobs
forceload remove -2810 -1715 -2690 -1655
forceload remove -2460 -1710 -2340 -1660
say [MAVO builder] ALL DONE!
```

## `/function mavocraft:portal_room`
```
say [MAVO builder] Portal Room: clearing interior...
fill -2449 199 -1699 -2351 209 -1671 minecraft:air
fill -2449 210 -1699 -2351 220 -1671 minecraft:air
fill -2449 221 -1699 -2351 227 -1671 minecraft:air
say [MAVO builder] Portal Room: bedrock shell...
fill -2450 198 -1700 -2350 198 -1670 minecraft:bedrock
fill -2450 228 -1700 -2350 228 -1670 minecraft:bedrock
fill -2450 199 -1700 -2350 227 -1700 minecraft:bedrock
fill -2450 199 -1670 -2350 227 -1670 minecraft:bedrock
fill -2450 199 -1699 -2450 227 -1671 minecraft:bedrock
fill -2350 199 -1699 -2350 227 -1671 minecraft:bedrock
say [MAVO builder] Portal Room: lining...
fill -2449 199 -1699 -2351 199 -1671 minecraft:polished_deepslate
fill -2449 227 -1699 -2351 227 -1671 minecraft:polished_deepslate
fill -2449 200 -1699 -2351 226 -1699 minecraft:deepslate_tiles
fill -2449 200 -1671 -2351 226 -1671 minecraft:deepslate_tiles
fill -2449 200 -1698 -2449 226 -1672 minecraft:deepslate_tiles
fill -2351 200 -1698 -2351 226 -1672 minecraft:deepslate_tiles
say [MAVO builder] Portal Room: accents...
fill -2444 200 -1699 -2444 226 -1699 minecraft:red_nether_bricks
fill -2444 200 -1671 -2444 226 -1671 minecraft:red_nether_bricks
fill -2432 200 -1699 -2432 226 -1699 minecraft:red_nether_bricks
fill -2432 200 -1671 -2432 226 -1671 minecraft:red_nether_bricks
fill -2420 200 -1699 -2420 226 -1699 minecraft:red_nether_bricks
fill -2420 200 -1671 -2420 226 -1671 minecraft:red_nether_bricks
fill -2408 200 -1699 -2408 226 -1699 minecraft:red_nether_bricks
fill -2408 200 -1671 -2408 226 -1671 minecraft:red_nether_bricks
fill -2396 200 -1699 -2396 226 -1699 minecraft:red_nether_bricks
fill -2396 200 -1671 -2396 226 -1671 minecraft:red_nether_bricks
fill -2384 200 -1699 -2384 226 -1699 minecraft:red_nether_bricks
fill -2384 200 -1671 -2384 226 -1671 minecraft:red_nether_bricks
fill -2372 200 -1699 -2372 226 -1699 minecraft:red_nether_bricks
fill -2372 200 -1671 -2372 226 -1671 minecraft:red_nether_bricks
fill -2360 200 -1699 -2360 226 -1699 minecraft:red_nether_bricks
fill -2360 200 -1671 -2360 226 -1671 minecraft:red_nether_bricks
fill -2448 199 -1686 -2352 199 -1684 minecraft:nether_bricks
say [MAVO builder] Portal Room: HEAVY lighting...
fill -2449 199 -1697 -2351 199 -1697 minecraft:ochre_froglight
fill -2449 199 -1691 -2351 199 -1691 minecraft:ochre_froglight
fill -2449 199 -1679 -2351 199 -1679 minecraft:ochre_froglight
fill -2449 199 -1673 -2351 199 -1673 minecraft:ochre_froglight
fill -2446 199 -1699 -2446 199 -1671 minecraft:ochre_froglight
fill -2438 199 -1699 -2438 199 -1671 minecraft:ochre_froglight
fill -2430 199 -1699 -2430 199 -1671 minecraft:ochre_froglight
fill -2422 199 -1699 -2422 199 -1671 minecraft:ochre_froglight
fill -2414 199 -1699 -2414 199 -1671 minecraft:ochre_froglight
fill -2406 199 -1699 -2406 199 -1671 minecraft:ochre_froglight
fill -2398 199 -1699 -2398 199 -1671 minecraft:ochre_froglight
fill -2390 199 -1699 -2390 199 -1671 minecraft:ochre_froglight
fill -2382 199 -1699 -2382 199 -1671 minecraft:ochre_froglight
fill -2374 199 -1699 -2374 199 -1671 minecraft:ochre_froglight
fill -2366 199 -1699 -2366 199 -1671 minecraft:ochre_froglight
fill -2358 199 -1699 -2358 199 -1671 minecraft:ochre_froglight
fill -2449 227 -1693 -2351 227 -1693 minecraft:ochre_froglight
fill -2449 227 -1685 -2351 227 -1685 minecraft:ochre_froglight
fill -2449 227 -1677 -2351 227 -1677 minecraft:ochre_froglight
fill -2449 205 -1699 -2351 205 -1699 minecraft:sea_lantern
fill -2449 205 -1671 -2351 205 -1671 minecraft:sea_lantern
fill -2450 200 -1686 -2449 203 -1684 minecraft:air
say [MAVO builder] PORTAL ROOM DONE.
```

## `/function mavocraft:portal_frames`
```
say [MAVO builder] Building 26 jump-portal frames (13 biomes N / 13 danger S)...
fill -2446 200 -1699 -2442 204 -1699 minecraft:smooth_sandstone
fill -2445 200 -1699 -2443 203 -1699 minecraft:black_concrete
fill -2445 199 -1698 -2443 199 -1697 minecraft:smooth_sandstone
setblock -2444 199 -1698 minecraft:glowstone
fill -2439 200 -1699 -2435 204 -1699 minecraft:acacia_planks
fill -2438 200 -1699 -2436 203 -1699 minecraft:black_concrete
fill -2438 199 -1698 -2436 199 -1697 minecraft:acacia_planks
setblock -2437 199 -1698 minecraft:glowstone
fill -2432 200 -1699 -2428 204 -1699 minecraft:green_terracotta
fill -2431 200 -1699 -2429 203 -1699 minecraft:black_concrete
fill -2431 199 -1698 -2429 199 -1697 minecraft:green_terracotta
setblock -2430 199 -1698 minecraft:glowstone
fill -2425 200 -1699 -2421 204 -1699 minecraft:dark_oak_planks
fill -2424 200 -1699 -2422 203 -1699 minecraft:black_concrete
fill -2424 199 -1698 -2422 199 -1697 minecraft:dark_oak_planks
setblock -2423 199 -1698 minecraft:glowstone
fill -2418 200 -1699 -2414 204 -1699 minecraft:spruce_planks
fill -2417 200 -1699 -2415 203 -1699 minecraft:black_concrete
fill -2417 199 -1698 -2415 199 -1697 minecraft:spruce_planks
setblock -2416 199 -1698 minecraft:glowstone
fill -2411 200 -1699 -2407 204 -1699 minecraft:lime_concrete
fill -2410 200 -1699 -2408 203 -1699 minecraft:black_concrete
fill -2410 199 -1698 -2408 199 -1697 minecraft:lime_concrete
setblock -2409 199 -1698 minecraft:glowstone
fill -2404 200 -1699 -2400 204 -1699 minecraft:snow_block
fill -2403 200 -1699 -2401 203 -1699 minecraft:black_concrete
fill -2403 199 -1698 -2401 199 -1697 minecraft:snow_block
setblock -2402 199 -1698 minecraft:glowstone
fill -2397 200 -1699 -2393 204 -1699 minecraft:green_concrete
fill -2396 200 -1699 -2394 203 -1699 minecraft:black_concrete
fill -2396 199 -1698 -2394 199 -1697 minecraft:green_concrete
setblock -2395 199 -1698 minecraft:glowstone
fill -2390 200 -1699 -2386 204 -1699 minecraft:bamboo_planks
fill -2389 200 -1699 -2387 203 -1699 minecraft:black_concrete
fill -2389 199 -1698 -2387 199 -1697 minecraft:bamboo_planks
setblock -2388 199 -1698 minecraft:glowstone
fill -2383 200 -1699 -2379 204 -1699 minecraft:packed_ice
fill -2382 200 -1699 -2380 203 -1699 minecraft:black_concrete
fill -2382 199 -1698 -2380 199 -1697 minecraft:packed_ice
setblock -2381 199 -1698 minecraft:glowstone
fill -2376 200 -1699 -2372 204 -1699 minecraft:cherry_planks
fill -2375 200 -1699 -2373 203 -1699 minecraft:black_concrete
fill -2375 199 -1698 -2373 199 -1697 minecraft:cherry_planks
setblock -2374 199 -1698 minecraft:glowstone
fill -2369 200 -1699 -2365 204 -1699 minecraft:red_terracotta
fill -2368 200 -1699 -2366 203 -1699 minecraft:black_concrete
fill -2368 199 -1698 -2366 199 -1697 minecraft:red_terracotta
setblock -2367 199 -1698 minecraft:glowstone
fill -2362 200 -1699 -2358 204 -1699 minecraft:red_mushroom_block
fill -2361 200 -1699 -2359 203 -1699 minecraft:black_concrete
fill -2361 199 -1698 -2359 199 -1697 minecraft:red_mushroom_block
setblock -2360 199 -1698 minecraft:glowstone
fill -2446 200 -1671 -2442 204 -1671 minecraft:blue_terracotta
fill -2445 200 -1671 -2443 203 -1671 minecraft:black_concrete
fill -2445 199 -1673 -2443 199 -1672 minecraft:blue_terracotta
setblock -2444 199 -1672 minecraft:glowstone
fill -2439 200 -1671 -2435 204 -1671 minecraft:oak_planks
fill -2438 200 -1671 -2436 203 -1671 minecraft:black_concrete
fill -2438 199 -1673 -2436 199 -1672 minecraft:oak_planks
setblock -2437 199 -1672 minecraft:glowstone
fill -2432 200 -1671 -2428 204 -1671 minecraft:dripstone_block
fill -2431 200 -1671 -2429 203 -1671 minecraft:black_concrete
fill -2431 199 -1673 -2429 199 -1672 minecraft:dripstone_block
setblock -2430 199 -1672 minecraft:glowstone
fill -2425 200 -1671 -2421 204 -1671 minecraft:moss_block
fill -2424 200 -1671 -2422 203 -1671 minecraft:black_concrete
fill -2424 199 -1673 -2422 199 -1672 minecraft:moss_block
setblock -2423 199 -1672 minecraft:glowstone
fill -2418 200 -1671 -2414 204 -1671 minecraft:chiseled_sandstone
fill -2417 200 -1671 -2415 203 -1671 minecraft:black_concrete
fill -2417 199 -1673 -2415 199 -1672 minecraft:chiseled_sandstone
setblock -2416 199 -1672 minecraft:glowstone
fill -2411 200 -1671 -2407 204 -1671 minecraft:mossy_cobblestone
fill -2410 200 -1671 -2408 203 -1671 minecraft:black_concrete
fill -2410 199 -1673 -2408 199 -1672 minecraft:mossy_cobblestone
setblock -2409 199 -1672 minecraft:glowstone
fill -2404 200 -1671 -2400 204 -1671 minecraft:mossy_stone_bricks
fill -2403 200 -1671 -2401 203 -1671 minecraft:black_concrete
fill -2403 199 -1673 -2401 199 -1672 minecraft:mossy_stone_bricks
setblock -2402 199 -1672 minecraft:glowstone
fill -2397 200 -1671 -2393 204 -1671 minecraft:cobbled_deepslate
fill -2396 200 -1671 -2394 203 -1671 minecraft:black_concrete
fill -2396 199 -1673 -2394 199 -1672 minecraft:cobbled_deepslate
setblock -2395 199 -1672 minecraft:glowstone
fill -2390 200 -1671 -2386 204 -1671 minecraft:dark_oak_log
fill -2389 200 -1671 -2387 203 -1671 minecraft:black_concrete
fill -2389 199 -1673 -2387 199 -1672 minecraft:dark_oak_log
setblock -2388 199 -1672 minecraft:glowstone
fill -2383 200 -1671 -2379 204 -1671 minecraft:prismarine_bricks
fill -2382 200 -1671 -2380 203 -1671 minecraft:black_concrete
fill -2382 199 -1673 -2380 199 -1672 minecraft:prismarine_bricks
setblock -2381 199 -1672 minecraft:glowstone
fill -2376 200 -1671 -2372 204 -1671 minecraft:stone_bricks
fill -2375 200 -1671 -2373 203 -1671 minecraft:black_concrete
fill -2375 199 -1673 -2373 199 -1672 minecraft:stone_bricks
setblock -2374 199 -1672 minecraft:glowstone
fill -2369 200 -1671 -2365 204 -1671 minecraft:waxed_copper_block
fill -2368 200 -1671 -2366 203 -1671 minecraft:black_concrete
fill -2368 199 -1673 -2366 199 -1672 minecraft:waxed_copper_block
setblock -2367 199 -1672 minecraft:glowstone
fill -2362 200 -1671 -2358 204 -1671 minecraft:sculk
fill -2361 200 -1671 -2359 203 -1671 minecraft:black_concrete
fill -2361 199 -1673 -2359 199 -1672 minecraft:sculk
setblock -2360 199 -1672 minecraft:glowstone
say [MAVO builder] PORTAL FRAMES DONE. Drop in MAVOPortalRoom jar for FX/holos/jumps.
```

## `/function mavocraft:vault_shell`
```
say [MAVO builder] Vault: clearing interior...
fill -2799 199 -1704 -2701 206 -1666 minecraft:air
fill -2799 207 -1704 -2701 214 -1666 minecraft:air
fill -2799 215 -1704 -2701 222 -1666 minecraft:air
fill -2799 223 -1704 -2701 230 -1666 minecraft:air
fill -2799 231 -1704 -2701 237 -1666 minecraft:air
say [MAVO builder] Vault: bedrock shell...
fill -2800 198 -1705 -2700 198 -1665 minecraft:bedrock
fill -2800 238 -1705 -2700 238 -1665 minecraft:bedrock
fill -2800 199 -1705 -2700 237 -1705 minecraft:bedrock
fill -2800 199 -1665 -2700 237 -1665 minecraft:bedrock
fill -2800 199 -1704 -2800 237 -1666 minecraft:bedrock
fill -2700 199 -1704 -2700 237 -1666 minecraft:bedrock
say [MAVO builder] Vault: lining...
fill -2799 199 -1704 -2701 199 -1666 minecraft:polished_deepslate
fill -2799 237 -1704 -2701 237 -1666 minecraft:polished_blackstone
fill -2799 200 -1704 -2701 236 -1704 minecraft:polished_blackstone
fill -2799 200 -1666 -2701 236 -1666 minecraft:polished_blackstone
fill -2799 200 -1703 -2799 236 -1667 minecraft:polished_blackstone
fill -2701 200 -1703 -2701 236 -1667 minecraft:polished_blackstone
fill -2792 200 -1704 -2792 236 -1704 minecraft:gilded_blackstone
fill -2792 200 -1666 -2792 236 -1666 minecraft:gilded_blackstone
fill -2776 200 -1704 -2776 236 -1704 minecraft:gilded_blackstone
fill -2776 200 -1666 -2776 236 -1666 minecraft:gilded_blackstone
fill -2760 200 -1704 -2760 236 -1704 minecraft:gilded_blackstone
fill -2760 200 -1666 -2760 236 -1666 minecraft:gilded_blackstone
fill -2744 200 -1704 -2744 236 -1704 minecraft:gilded_blackstone
fill -2744 200 -1666 -2744 236 -1666 minecraft:gilded_blackstone
fill -2728 200 -1704 -2728 236 -1704 minecraft:gilded_blackstone
fill -2728 200 -1666 -2728 236 -1666 minecraft:gilded_blackstone
fill -2712 200 -1704 -2712 236 -1704 minecraft:gilded_blackstone
fill -2712 200 -1666 -2712 236 -1666 minecraft:gilded_blackstone
say [MAVO builder] Vault: HEAVY lighting...
fill -2796 199 -1704 -2796 199 -1666 minecraft:glowstone
fill -2788 199 -1704 -2788 199 -1666 minecraft:glowstone
fill -2780 199 -1704 -2780 199 -1666 minecraft:glowstone
fill -2772 199 -1704 -2772 199 -1666 minecraft:glowstone
fill -2764 199 -1704 -2764 199 -1666 minecraft:glowstone
fill -2756 199 -1704 -2756 199 -1666 minecraft:glowstone
fill -2748 199 -1704 -2748 199 -1666 minecraft:glowstone
fill -2740 199 -1704 -2740 199 -1666 minecraft:glowstone
fill -2732 199 -1704 -2732 199 -1666 minecraft:glowstone
fill -2724 199 -1704 -2724 199 -1666 minecraft:glowstone
fill -2716 199 -1704 -2716 199 -1666 minecraft:glowstone
fill -2708 199 -1704 -2708 199 -1666 minecraft:glowstone
fill -2799 199 -1701 -2701 199 -1701 minecraft:glowstone
fill -2799 199 -1693 -2701 199 -1693 minecraft:glowstone
fill -2799 199 -1677 -2701 199 -1677 minecraft:glowstone
fill -2799 199 -1669 -2701 199 -1669 minecraft:glowstone
fill -2799 205 -1704 -2701 205 -1704 minecraft:sea_lantern
fill -2799 205 -1666 -2701 205 -1666 minecraft:sea_lantern
fill -2799 237 -1695 -2701 237 -1695 minecraft:glowstone
fill -2799 237 -1685 -2701 237 -1685 minecraft:glowstone
fill -2799 237 -1675 -2701 237 -1675 minecraft:glowstone
fill -2701 200 -1686 -2700 203 -1684 minecraft:air
say [MAVO builder] VAULT SHELL DONE.
```

## `/function mavocraft:vault_rooms`
```
say [MAVO builder] Vault: corridor + dividers...
fill -2798 199 -1688 -2702 199 -1682 minecraft:polished_blackstone_bricks
fill -2798 199 -1685 -2702 199 -1685 minecraft:gold_block
fill -2798 199 -1687 -2702 199 -1687 minecraft:glowstone
fill -2798 199 -1683 -2702 199 -1683 minecraft:glowstone
fill -2779 200 -1703 -2779 236 -1689 minecraft:polished_blackstone
fill -2779 200 -1681 -2779 236 -1667 minecraft:polished_blackstone
fill -2779 200 -1696 -2779 206 -1696 minecraft:sea_lantern
fill -2779 200 -1674 -2779 206 -1674 minecraft:sea_lantern
fill -2760 200 -1703 -2760 236 -1689 minecraft:polished_blackstone
fill -2760 200 -1681 -2760 236 -1667 minecraft:polished_blackstone
fill -2760 200 -1696 -2760 206 -1696 minecraft:sea_lantern
fill -2760 200 -1674 -2760 206 -1674 minecraft:sea_lantern
fill -2740 200 -1703 -2740 236 -1689 minecraft:polished_blackstone
fill -2740 200 -1681 -2740 236 -1667 minecraft:polished_blackstone
fill -2740 200 -1696 -2740 206 -1696 minecraft:sea_lantern
fill -2740 200 -1674 -2740 206 -1674 minecraft:sea_lantern
fill -2721 200 -1703 -2721 236 -1689 minecraft:polished_blackstone
fill -2721 200 -1681 -2721 236 -1667 minecraft:polished_blackstone
fill -2721 200 -1696 -2721 206 -1696 minecraft:sea_lantern
fill -2721 200 -1674 -2721 206 -1674 minecraft:sea_lantern
fill -2798 237 -1685 -2702 237 -1685 minecraft:glowstone
fill -2789 237 -1697 -2788 237 -1696 minecraft:glowstone
fill -2789 237 -1674 -2788 237 -1673 minecraft:glowstone
fill -2770 237 -1697 -2769 237 -1696 minecraft:glowstone
fill -2770 237 -1674 -2769 237 -1673 minecraft:glowstone
fill -2750 237 -1697 -2749 237 -1696 minecraft:glowstone
fill -2750 237 -1674 -2749 237 -1673 minecraft:glowstone
fill -2731 237 -1697 -2730 237 -1696 minecraft:glowstone
fill -2731 237 -1674 -2730 237 -1673 minecraft:glowstone
fill -2711 237 -1697 -2710 237 -1696 minecraft:glowstone
fill -2711 237 -1674 -2710 237 -1673 minecraft:glowstone
say [MAVO builder] VAULT ROOMS DONE.
```

## `/function mavocraft:vault_chests`
```
say [MAVO builder] Vault: placing 150 double chests...
setblock -2796 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2795 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2794 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2793 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2792 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2791 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2790 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2789 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2788 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2787 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2786 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2785 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2784 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2783 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2796 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2795 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2794 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2793 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2792 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2791 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2790 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2789 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2788 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2787 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2786 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2785 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2784 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2783 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2776 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2775 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2774 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2773 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2772 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2771 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2770 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2769 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2768 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2767 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2766 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2765 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2764 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2763 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2776 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2775 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2774 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2773 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2772 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2771 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2770 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2769 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2768 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2767 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2766 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2765 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2764 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2763 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2757 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2756 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2755 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2754 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2753 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2752 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2751 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2750 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2749 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2748 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2747 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2746 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2745 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2744 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2757 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2756 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2755 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2754 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2753 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2752 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2751 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2750 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2749 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2748 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2747 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2746 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2745 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2744 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2737 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2736 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2735 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2734 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2733 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2732 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2731 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2730 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2729 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2728 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2727 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2726 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2725 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2724 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2737 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2736 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2735 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2734 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2733 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2732 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2731 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2730 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2729 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2728 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2727 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2726 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2725 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2724 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2718 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2717 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2716 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2715 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2714 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2713 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2712 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2711 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2710 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2709 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2708 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2707 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2706 200 -1703 minecraft:chest[facing=south,type=right]
setblock -2705 200 -1703 minecraft:chest[facing=south,type=left]
setblock -2718 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2717 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2716 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2715 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2714 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2713 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2712 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2711 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2710 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2709 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2708 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2707 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2706 200 -1667 minecraft:chest[facing=north,type=left]
setblock -2705 200 -1667 minecraft:chest[facing=north,type=right]
setblock -2798 200 -1702 minecraft:chest[facing=east,type=left]
setblock -2798 200 -1701 minecraft:chest[facing=east,type=right]
setblock -2780 200 -1702 minecraft:chest[facing=west,type=right]
setblock -2780 200 -1701 minecraft:chest[facing=west,type=left]
setblock -2798 200 -1700 minecraft:chest[facing=east,type=left]
setblock -2798 200 -1699 minecraft:chest[facing=east,type=right]
setblock -2780 200 -1700 minecraft:chest[facing=west,type=right]
setblock -2780 200 -1699 minecraft:chest[facing=west,type=left]
setblock -2798 200 -1698 minecraft:chest[facing=east,type=left]
setblock -2798 200 -1697 minecraft:chest[facing=east,type=right]
setblock -2780 200 -1698 minecraft:chest[facing=west,type=right]
setblock -2780 200 -1697 minecraft:chest[facing=west,type=left]
setblock -2798 200 -1696 minecraft:chest[facing=east,type=left]
setblock -2798 200 -1695 minecraft:chest[facing=east,type=right]
setblock -2780 200 -1696 minecraft:chest[facing=west,type=right]
setblock -2780 200 -1695 minecraft:chest[facing=west,type=left]
setblock -2798 200 -1675 minecraft:chest[facing=east,type=left]
setblock -2798 200 -1674 minecraft:chest[facing=east,type=right]
setblock -2780 200 -1675 minecraft:chest[facing=west,type=right]
setblock -2780 200 -1674 minecraft:chest[facing=west,type=left]
setblock -2798 200 -1673 minecraft:chest[facing=east,type=left]
setblock -2798 200 -1672 minecraft:chest[facing=east,type=right]
setblock -2780 200 -1673 minecraft:chest[facing=west,type=right]
setblock -2780 200 -1672 minecraft:chest[facing=west,type=left]
setblock -2798 200 -1671 minecraft:chest[facing=east,type=left]
setblock -2798 200 -1670 minecraft:chest[facing=east,type=right]
setblock -2780 200 -1671 minecraft:chest[facing=west,type=right]
setblock -2780 200 -1670 minecraft:chest[facing=west,type=left]
setblock -2798 200 -1669 minecraft:chest[facing=east,type=left]
setblock -2798 200 -1668 minecraft:chest[facing=east,type=right]
setblock -2780 200 -1669 minecraft:chest[facing=west,type=right]
setblock -2780 200 -1668 minecraft:chest[facing=west,type=left]
setblock -2778 200 -1702 minecraft:chest[facing=east,type=left]
setblock -2778 200 -1701 minecraft:chest[facing=east,type=right]
setblock -2761 200 -1702 minecraft:chest[facing=west,type=right]
setblock -2761 200 -1701 minecraft:chest[facing=west,type=left]
setblock -2778 200 -1700 minecraft:chest[facing=east,type=left]
setblock -2778 200 -1699 minecraft:chest[facing=east,type=right]
setblock -2761 200 -1700 minecraft:chest[facing=west,type=right]
setblock -2761 200 -1699 minecraft:chest[facing=west,type=left]
setblock -2778 200 -1698 minecraft:chest[facing=east,type=left]
setblock -2778 200 -1697 minecraft:chest[facing=east,type=right]
setblock -2761 200 -1698 minecraft:chest[facing=west,type=right]
setblock -2761 200 -1697 minecraft:chest[facing=west,type=left]
setblock -2778 200 -1696 minecraft:chest[facing=east,type=left]
setblock -2778 200 -1695 minecraft:chest[facing=east,type=right]
setblock -2761 200 -1696 minecraft:chest[facing=west,type=right]
setblock -2761 200 -1695 minecraft:chest[facing=west,type=left]
setblock -2778 200 -1675 minecraft:chest[facing=east,type=left]
setblock -2778 200 -1674 minecraft:chest[facing=east,type=right]
setblock -2761 200 -1675 minecraft:chest[facing=west,type=right]
setblock -2761 200 -1674 minecraft:chest[facing=west,type=left]
setblock -2778 200 -1673 minecraft:chest[facing=east,type=left]
setblock -2778 200 -1672 minecraft:chest[facing=east,type=right]
setblock -2761 200 -1673 minecraft:chest[facing=west,type=right]
setblock -2761 200 -1672 minecraft:chest[facing=west,type=left]
setblock -2778 200 -1671 minecraft:chest[facing=east,type=left]
setblock -2778 200 -1670 minecraft:chest[facing=east,type=right]
setblock -2761 200 -1671 minecraft:chest[facing=west,type=right]
setblock -2761 200 -1670 minecraft:chest[facing=west,type=left]
setblock -2778 200 -1669 minecraft:chest[facing=east,type=left]
setblock -2778 200 -1668 minecraft:chest[facing=east,type=right]
setblock -2761 200 -1669 minecraft:chest[facing=west,type=right]
setblock -2761 200 -1668 minecraft:chest[facing=west,type=left]
setblock -2759 200 -1702 minecraft:chest[facing=east,type=left]
setblock -2759 200 -1701 minecraft:chest[facing=east,type=right]
setblock -2741 200 -1702 minecraft:chest[facing=west,type=right]
setblock -2741 200 -1701 minecraft:chest[facing=west,type=left]
setblock -2759 200 -1700 minecraft:chest[facing=east,type=left]
setblock -2759 200 -1699 minecraft:chest[facing=east,type=right]
setblock -2741 200 -1700 minecraft:chest[facing=west,type=right]
setblock -2741 200 -1699 minecraft:chest[facing=west,type=left]
setblock -2759 200 -1698 minecraft:chest[facing=east,type=left]
setblock -2759 200 -1697 minecraft:chest[facing=east,type=right]
setblock -2741 200 -1698 minecraft:chest[facing=west,type=right]
setblock -2741 200 -1697 minecraft:chest[facing=west,type=left]
setblock -2759 200 -1696 minecraft:chest[facing=east,type=left]
setblock -2759 200 -1695 minecraft:chest[facing=east,type=right]
setblock -2741 200 -1696 minecraft:chest[facing=west,type=right]
setblock -2741 200 -1695 minecraft:chest[facing=west,type=left]
setblock -2759 200 -1675 minecraft:chest[facing=east,type=left]
setblock -2759 200 -1674 minecraft:chest[facing=east,type=right]
setblock -2741 200 -1675 minecraft:chest[facing=west,type=right]
setblock -2741 200 -1674 minecraft:chest[facing=west,type=left]
setblock -2759 200 -1673 minecraft:chest[facing=east,type=left]
setblock -2759 200 -1672 minecraft:chest[facing=east,type=right]
setblock -2741 200 -1673 minecraft:chest[facing=west,type=right]
setblock -2741 200 -1672 minecraft:chest[facing=west,type=left]
setblock -2759 200 -1671 minecraft:chest[facing=east,type=left]
setblock -2759 200 -1670 minecraft:chest[facing=east,type=right]
setblock -2741 200 -1671 minecraft:chest[facing=west,type=right]
setblock -2741 200 -1670 minecraft:chest[facing=west,type=left]
setblock -2759 200 -1669 minecraft:chest[facing=east,type=left]
setblock -2759 200 -1668 minecraft:chest[facing=east,type=right]
setblock -2741 200 -1669 minecraft:chest[facing=west,type=right]
setblock -2741 200 -1668 minecraft:chest[facing=west,type=left]
setblock -2739 200 -1702 minecraft:chest[facing=east,type=left]
setblock -2739 200 -1701 minecraft:chest[facing=east,type=right]
setblock -2722 200 -1702 minecraft:chest[facing=west,type=right]
setblock -2722 200 -1701 minecraft:chest[facing=west,type=left]
setblock -2739 200 -1700 minecraft:chest[facing=east,type=left]
setblock -2739 200 -1699 minecraft:chest[facing=east,type=right]
setblock -2722 200 -1700 minecraft:chest[facing=west,type=right]
setblock -2722 200 -1699 minecraft:chest[facing=west,type=left]
setblock -2739 200 -1698 minecraft:chest[facing=east,type=left]
setblock -2739 200 -1697 minecraft:chest[facing=east,type=right]
setblock -2722 200 -1698 minecraft:chest[facing=west,type=right]
setblock -2722 200 -1697 minecraft:chest[facing=west,type=left]
setblock -2739 200 -1696 minecraft:chest[facing=east,type=left]
setblock -2739 200 -1695 minecraft:chest[facing=east,type=right]
setblock -2722 200 -1696 minecraft:chest[facing=west,type=right]
setblock -2722 200 -1695 minecraft:chest[facing=west,type=left]
setblock -2739 200 -1675 minecraft:chest[facing=east,type=left]
setblock -2739 200 -1674 minecraft:chest[facing=east,type=right]
setblock -2722 200 -1675 minecraft:chest[facing=west,type=right]
setblock -2722 200 -1674 minecraft:chest[facing=west,type=left]
setblock -2739 200 -1673 minecraft:chest[facing=east,type=left]
setblock -2739 200 -1672 minecraft:chest[facing=east,type=right]
setblock -2722 200 -1673 minecraft:chest[facing=west,type=right]
setblock -2722 200 -1672 minecraft:chest[facing=west,type=left]
setblock -2739 200 -1671 minecraft:chest[facing=east,type=left]
setblock -2739 200 -1670 minecraft:chest[facing=east,type=right]
setblock -2722 200 -1671 minecraft:chest[facing=west,type=right]
setblock -2722 200 -1670 minecraft:chest[facing=west,type=left]
setblock -2739 200 -1669 minecraft:chest[facing=east,type=left]
setblock -2739 200 -1668 minecraft:chest[facing=east,type=right]
setblock -2722 200 -1669 minecraft:chest[facing=west,type=right]
setblock -2722 200 -1668 minecraft:chest[facing=west,type=left]
setblock -2720 200 -1702 minecraft:chest[facing=east,type=left]
setblock -2720 200 -1701 minecraft:chest[facing=east,type=right]
setblock -2702 200 -1702 minecraft:chest[facing=west,type=right]
setblock -2702 200 -1701 minecraft:chest[facing=west,type=left]
setblock -2720 200 -1700 minecraft:chest[facing=east,type=left]
setblock -2720 200 -1699 minecraft:chest[facing=east,type=right]
setblock -2702 200 -1700 minecraft:chest[facing=west,type=right]
setblock -2702 200 -1699 minecraft:chest[facing=west,type=left]
setblock -2720 200 -1698 minecraft:chest[facing=east,type=left]
setblock -2720 200 -1697 minecraft:chest[facing=east,type=right]
setblock -2702 200 -1698 minecraft:chest[facing=west,type=right]
setblock -2702 200 -1697 minecraft:chest[facing=west,type=left]
setblock -2720 200 -1696 minecraft:chest[facing=east,type=left]
setblock -2720 200 -1695 minecraft:chest[facing=east,type=right]
setblock -2702 200 -1696 minecraft:chest[facing=west,type=right]
setblock -2702 200 -1695 minecraft:chest[facing=west,type=left]
setblock -2720 200 -1675 minecraft:chest[facing=east,type=left]
setblock -2720 200 -1674 minecraft:chest[facing=east,type=right]
setblock -2702 200 -1675 minecraft:chest[facing=west,type=right]
setblock -2702 200 -1674 minecraft:chest[facing=west,type=left]
setblock -2720 200 -1673 minecraft:chest[facing=east,type=left]
setblock -2720 200 -1672 minecraft:chest[facing=east,type=right]
setblock -2702 200 -1673 minecraft:chest[facing=west,type=right]
setblock -2702 200 -1672 minecraft:chest[facing=west,type=left]
setblock -2720 200 -1671 minecraft:chest[facing=east,type=left]
setblock -2720 200 -1670 minecraft:chest[facing=east,type=right]
setblock -2702 200 -1671 minecraft:chest[facing=west,type=right]
setblock -2702 200 -1670 minecraft:chest[facing=west,type=left]
setblock -2720 200 -1669 minecraft:chest[facing=east,type=left]
setblock -2720 200 -1668 minecraft:chest[facing=east,type=right]
setblock -2702 200 -1669 minecraft:chest[facing=west,type=right]
setblock -2702 200 -1668 minecraft:chest[facing=west,type=left]
say [MAVO builder] VAULT CHESTS DONE.
```

## `/function mavocraft:purge_mobs`
```
say [MAVO builder] Removing mobs inside rooms...
kill @e[type=minecraft:zombie,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:zombie,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:skeleton,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:skeleton,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:creeper,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:creeper,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:spider,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:spider,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:cave_spider,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:cave_spider,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:enderman,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:enderman,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:witch,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:witch,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:drowned,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:drowned,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:husk,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:husk,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:stray,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:stray,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:zombie_villager,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:zombie_villager,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:phantom,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:phantom,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
kill @e[type=minecraft:slime,x=-2801,y=197,z=-1706,dx=102,dy=42,dz=42]
kill @e[type=minecraft:slime,x=-2451,y=197,z=-1701,dx=102,dy=32,dz=32]
say [MAVO builder] Mob purge done.
```

## `/function mavocraft:demolish_all`
```
say [MAVO builder] Demolishing both rooms...
forceload add -2810 -1715 -2690 -1655
forceload add -2460 -1710 -2340 -1660
fill -2800 198 -1705 -2700 204 -1665 minecraft:air
fill -2800 205 -1705 -2700 211 -1665 minecraft:air
fill -2800 212 -1705 -2700 218 -1665 minecraft:air
fill -2800 219 -1705 -2700 225 -1665 minecraft:air
fill -2800 226 -1705 -2700 232 -1665 minecraft:air
fill -2800 233 -1705 -2700 238 -1665 minecraft:air
fill -2450 198 -1700 -2350 207 -1670 minecraft:air
fill -2450 208 -1700 -2350 217 -1670 minecraft:air
fill -2450 218 -1700 -2350 227 -1670 minecraft:air
fill -2450 228 -1700 -2350 228 -1670 minecraft:air
forceload remove -2810 -1715 -2690 -1655
forceload remove -2460 -1710 -2340 -1660
say [MAVO builder] Demolished.
```

