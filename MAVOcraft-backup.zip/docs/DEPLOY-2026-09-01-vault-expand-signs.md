# Deploy — Vault expand + chest signs (1.6.2)

## Upload
- plugins/MAVOVault-1.6.2.jar  (remove 1.6.1 / 1.6.0)
- plugins/MAVOWild-1.7.3.jar   (optional; safer /holoreset)

## After restart
Chest signs auto-refresh ~6s after enable. Or force:
```
/vaultroom chestsigns
```
You should see oak standing signs **on top of every unlocked chest**.

## Expand upward (your L1S8 is 15/15)
1. Stand outside, **right-click YOUR door** (no sneak needed)
2. Menu:
   - **Enter room** — opens the door
   - **Expand Upward** — only when 15/15 and floor above free
3. Click Expand → pays **2× what you paid for this room** (if claim was 5k → 10k)
4. Ladder shaft punched through ceiling between centre chests
5. Upper room claimed, 1st chest free
6. Fill upper 15, right-click **upper door** → next expand = **2× upper paid** (4× base), then 8×, 16×…

## holoreset (Wild 1.7.3)
```
/holoreset          → Wild/Home portals ONLY (safe)
/holoreset all      → full plaza (only if you really want it)
```
Do NOT use `all` unless shopnpc resholo is also ready.

## return spawn (tree fix — still needed if not done)
Stand on plaza pad:
```
/vaultroom returnspawn
```
