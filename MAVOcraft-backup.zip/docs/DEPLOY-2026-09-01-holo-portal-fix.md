# Deploy — Fix holos + portal FX (2026-09-01)

## Cause
`/holoreset` (Wild 1.7.1) wiped **all** floating TextDisplays matching shop/tutorial/museum
text, but ShopNPC had **no restore path** (holo text not saved, holos untagged).
NPC signs (Tutorial Guide, Lucky Louie, The Curator, shopkeepers) stayed gone.

Portal sparkle/countdown are separate (Vault + PortalRoom repeating tasks). If those
died after a bad tick, 1.6.1 / 1.0.2 now catch errors so the loop keeps running.

## Upload (remove older versions)
```
plugins/MAVOWild-1.7.2.jar
plugins/MAVOShopNPC-1.3.2.jar
plugins/MAVOVault-1.6.1.jar
plugins/MAVOPortalRoom-1.0.2.jar
```

## After restart — restore NPC holos
Stand at plaza (chunks loaded), then either:

```
/shopnpc resholo
```

or full plaza refresh:

```
/holoreset
```

`/holoreset` now:
1. Removes only **restorable** MAVO holos
2. Respawns Wild/Home portals
3. Reloads PortalRoom + Vault holos
4. Runs **`shopnpc resholo`** (Tutorial / Louie / Curator / shopkeepers)
5. Tavern reload + wish well if nearby

Built-in default texts for: Tutorial_Guide, Lucky_Louie, The_Curator,
Update_Crier, Achievement_Keeper, Profession_Master.
Other shopkeepers restore if `holo-text` is already in ShopNPC config; after you
re-set a holo once with `/shopnpc holo <name> ...`, text is saved for next time.

## Portal FX / countdown still dead?
In-game (OP):
```
/vaultroom reload
/portalroom reload
```
Check console for `vault fxLoop` / `portalroom fxLoop` warnings.

If still no particles when standing in the portal opening, the portal **region
may be missing** from `plugins/MAVOVault/config.yml` (`portals.vault` etc.).
Re-set:
```
/vaultroom pos1   (bottom corner of opening)
/vaultroom pos2   (opposite top corner)
/vaultroom portal vault
# same for portalroom, vault_return, portalroom_return
```

Inside Portal Room, jumps use fixed coords in the jar — only need the plugin
enabled + you standing in the stand-in box. `/portalroom list` should show 26.

## ShopNPC new commands
- `/shopnpc resholo` — restore all NPC floating signs (console OK too)
- Holos are PDC-tagged + `holo-text` stored in config
