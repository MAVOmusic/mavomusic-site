# Deploy — Netherite shop + Wishing Well rebalance (2026-09-01)

## Upload to PebbleHost

### 1. Plugins (replace jars)
- `plugins/MAVOLuckyCoins-1.5.0.jar`  (delete old 1.4.0)
- `plugins/MAVOGuide-2.5.0.jar`        (delete old 2.4.0)

### 2. EconomyShopGUI shops (do NOT folder-delete the plugin)
Replace these two files under `plugins/EconomyShopGUI/shops/`:
- `resources.yml`  (netherite = 8× diamond)
- `Z_EverythingElse.yml`  (netherite_scrap reprice)

Or extract `configs/MAVOcraft-shops-villager-economy-v5.tar.gz` over `plugins/EconomyShopGUI/`
(it contains a `shops/` folder).

Then from console: `/sreload`

### 3. Optional well holo refresh
Stand on the wishing well (OP briefly or console):
- `/wish well`   (re-places holo with new text)
Or just leave it — prizes are server-side regardless of holo text.

### 4. /spawn fix (if still broken for non-OP)
```
lp group default permission set essentials.spawn true
```

## Expected prices after /sreload
| item | buy | sell |
|---|---:|---:|
| diamond | 2360 | 94.5 |
| netherite_ingot | 18880 | 756 |
| diamond_block | 21240 | 850.5 |
| netherite_block | 169920 | 6804 |
| diamond_ore | 7790 | 200 |
| ancient_debris | 62320 | 1600 |
| netherite_scrap | 4350 | 174 |

24× netherite block sell was ~920k — now 24×6804 ≈ 163k, and the well can no longer drop netherite blocks/ingots at all.

## Backup
`MAVOcraft-backup.zip` SHA-256 is printed next to the file; upload to GitHub
(mavomusic-site) as the disaster-recovery source together with EconomyShopGUI.tar.



SHA-256 MAVOcraft-backup.zip:
875001b9330ea77541f99378d13d2f307a71c701e793353098fda0efb99569e9  MAVOcraft-backup.zip

## Follow-up — shop-sellable well (same day)
Also upload:
- `plugins/MAVOLuckyCoins-1.5.1.jar` (replaces 1.5.0)
- `plugins/MAVOGuide-2.5.1.jar` (replaces 2.5.0)
- Full `plugins/EconomyShopGUI/shops/` from backup `configs/shops/` (or re-extract v5 tarball)
  Includes Z_EverythingElse page9 (shelves, firefly bush, mangrove PP, clock, etc.)
  and sell prices on heads/god apples/wet sponge.
Then `/sreload`. Well prizes are now ONLY materials with sell>0 in the shop.
