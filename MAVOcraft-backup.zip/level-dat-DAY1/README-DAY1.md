# Reset world day counter → Day 1

## What MAVOHud uses
```
Day = world.getFullTime() / 24000 + 1
```
Your export had `Time: 2614913` ≈ day 109.

## SAFE method (recommended)

1. **Stop** the Paper server.
2. Copy `world/level.dat` somewhere safe.
3. On any PC with Python:
```bash
pip install nbtlib
python3 patch-level-dat-day1.py world/level.dat
```
4. Start server. HUD / `%mavohud_day%` → **1**.

The script sets:
- `Data.Time = 0` (day counter)
- `Data.DayTime = 1000` (morning)
and writes `level.dat.bak`.

## SNBT edit (NBT editor / MCA Selector / web NBT)

Change only:
```
Time: 2614913L  →  Time: 0L
```
Optionally add/set:
```
DayTime: 1000L
```

See `level.dat.DAY1.snbt` for the edited fragment.

## WARNING
`level.dat.FRAGMENT-ONLY-DO-NOT-USE-AS-FULL-WORLD.dat` is built from the **partial** export you pasted. It is **not** a complete world level.dat (missing generator, gamerules, border, …). **Do not** drop it in as `world/level.dat` or you can break the world. Use the patch script on the real file.

## In-game alternative (no file edit)
If you can run code/console with a plugin:
`Bukkit.getWorld("world").setFullTime(0L);`
Vanilla `/time set day` only changes time-of-day, **not** the Day N counter.
