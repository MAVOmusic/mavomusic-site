package mavo.tavern;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.Bed;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.entity.Villager;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.attribute.Attribute;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

/**
 * Spawn tavern: right-click the marked bed, pay coins, skip the night.
 * One paid skip per player per MC day; lock resets at noon (time 6000).
 */
public final class Tavern extends JavaPlugin implements Listener, TabCompleter {

    private Economy econ;
    private NamespacedKey holoKey;
    private File dataFile;
    private YamlConfiguration data;
    private boolean dirty;

    private boolean bedEnabled;
    private String bedWorld;
    private int bedX, bedY, bedZ;
    private final java.util.List<int[]> extraBeds = new java.util.ArrayList<>();
    private final Map<UUID, Map<String, Long>> barDay = new HashMap<>();
    private NamespacedKey boundKey;
    private double price;
    private long wakeTime;
    private boolean nightOnly;
    private String currency;
    private String prefix;

    // uuid -> world fullTime when their lock expires (next noon after a rest)
    private final Map<UUID, Long> unlockAtFull = new HashMap<>();
    // players currently in the short sleep FX
    private final Set<UUID> sleeping = new HashSet<>();
    private BukkitTask noonTask;
    private UUID holoUuid;

    @Override
    public void onEnable() {
        holoKey = new NamespacedKey(this, "tavernholo");
        boundKey = new NamespacedKey(this, "tavernbound");
        saveDefaultConfig();
        reloadLocal();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        loadUsage();
        barDay.clear();
        if (data.getConfigurationSection("bar") != null) {
            for (String us : data.getConfigurationSection("bar").getKeys(false)) {
                try {
                    UUID u = UUID.fromString(us);
                    Map<String, Long> mm = new HashMap<>();
                    if (data.getConfigurationSection("bar." + us) != null) {
                        for (String k : data.getConfigurationSection("bar." + us).getKeys(false)) {
                            mm.put(k, data.getLong("bar." + us + "." + k));
                        }
                    }
                    barDay.put(u, mm);
                } catch (Exception ignored) {}
            }
        }

        RegisteredServiceProvider<Economy> rsp =
                getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider();
        else getLogger().warning("Vault economy missing - tavern sleeps will be free until Vault hooks.");

        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("tavern") != null) getCommand("tavern").setTabCompleter(this);

        // autosave + noon unlock broadcast check every 5s
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (dirty) { try { data.save(dataFile); } catch (Exception ignored) {} dirty = false; }
        }, 200L, 200L);

        noonTask = Bukkit.getScheduler().runTaskTimer(this, this::tickNoon, 40L, 40L);

        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (bedEnabled && getConfig().getBoolean("holo.enabled", true)) spawnHolo();
        }, 40L);

        getLogger().info("MAVOTavern 1.1 enabled - price " + (long) price + " " + strip(currency)
                + ", lock-until-next-noon, bed "
                + (bedEnabled ? (bedWorld + " " + bedX + "," + bedY + "," + bedZ) : "NOT SET (/tavern setbed)"));
    }

    @Override
    public void onDisable() {
        if (noonTask != null) noonTask.cancel();
        try { data.save(dataFile); } catch (Exception ignored) {}
        removeHolo();
    }

    private void reloadLocal() {
        reloadConfig();
        price = getConfig().getDouble("price", 100);
        wakeTime = getConfig().getLong("wake-time", 1000);
        nightOnly = getConfig().getBoolean("night-only", true);
        currency = color(getConfig().getString("currency-symbol", "\u26C3"));
        prefix = color(getConfig().getString("messages.prefix", "&c&lTAVERN &r&8» &r"));
        bedEnabled = getConfig().getBoolean("bed.enabled", false);
        bedWorld = getConfig().getString("bed.world", "world");
        bedX = getConfig().getInt("bed.x", 0);
        bedY = getConfig().getInt("bed.y", 64);
        bedZ = getConfig().getInt("bed.z", 0);
    }

    private void loadUsage() {
        unlockAtFull.clear();
        // new format
        if (data.isConfigurationSection("unlock-at")) {
            for (String k : data.getConfigurationSection("unlock-at").getKeys(false)) {
                try {
                    unlockAtFull.put(UUID.fromString(k), data.getLong("unlock-at." + k));
                } catch (Exception ignored) {}
            }
        }
        // migrate legacy day-index locks (used.<uuid> = small day number)
        if (data.isConfigurationSection("used")) {
            for (String k : data.getConfigurationSection("used").getKeys(false)) {
                try {
                    UUID id = UUID.fromString(k);
                    if (unlockAtFull.containsKey(id)) continue;
                    long v = data.getLong("used." + k);
                    // old: day index. Convert to noon of the following day (best-effort).
                    // If value looks like fullTime already (> 100000), keep as unlock time.
                    long unlock = v > 100_000L ? v : (v + 1L) * 24000L + 6000L;
                    unlockAtFull.put(id, unlock);
                    data.set("unlock-at." + k, unlock);
                } catch (Exception ignored) {}
            }
            data.set("used", null);
            dirty = true;
        }
    }

    /** After a rest: lock until the next noon on the world clock. */
    private void saveLockUntilNextNoon(UUID id, World w) {
        long unlock = nextNoonFullTime(w);
        unlockAtFull.put(id, unlock);
        data.set("unlock-at." + id, unlock);
        dirty = true;
    }

    private void clearLock(UUID id) {
        unlockAtFull.remove(id);
        data.set("unlock-at." + id, null);
        data.set("used." + id, null);
        dirty = true;
    }

    /* ================= time helpers ================= */

    /** Absolute fullTime of the next noon (time-of-day 6000). If already past noon, tomorrow noon. */
    private long nextNoonFullTime(World w) {
        long full = w.getFullTime();
        long tod = w.getTime(); // 0..23999
        long dayBase = full - tod;
        if (tod < 6000L) return dayBase + 6000L;          // later today
        return dayBase + 24000L + 6000L;                  // tomorrow noon
    }

    /** true if player may rent the tavern bed right now. */
    private boolean isUnlocked(Player pl, World w) {
        Long until = unlockAtFull.get(pl.getUniqueId());
        if (until == null) return true;
        if (w.getFullTime() >= until) {
            // expired — drop stale entry
            clearLock(pl.getUniqueId());
            return true;
        }
        return false;
    }

    private long secondsUntilUnlock(Player pl, World w) {
        Long until = unlockAtFull.get(pl.getUniqueId());
        if (until == null) return 0;
        long left = until - w.getFullTime();
        return Math.max(0L, left / 20L);
    }

    private boolean isNightish(World w) {
        if (w.hasStorm() && w.isThundering()) return true;
        long t = w.getTime();
        // vanilla beds work ~12542..23460; keep a similar window
        return t >= 12542L && t <= 23460L;
    }

    private void tickNoon() {
        // no-op heavy work; lock state is computed live. Holo text refresh occasionally.
        if (!bedEnabled) return;
        World w = Bukkit.getWorld(bedWorld);
        if (w == null) return;
        long t = w.getTime();
        // refresh holo near noon / dusk so status stays accurate
        if (t >= 5980 && t <= 6060 || t >= 12500 && t <= 12600) {
            if (getConfig().getBoolean("holo.enabled", true)) spawnHolo();
        }
    }

    /* ================= bed match ================= */

    private boolean isTavernBed(Block b) {
        if (!bedEnabled || b == null) return false;
        if (!b.getWorld().getName().equals(bedWorld)) return false;
        Material mat = b.getType();
        if (!mat.name().endsWith("_BED")) return false;
        int x = b.getX(), y = b.getY(), z = b.getZ();
        if (matchesBedPair(b, bedX, bedY, bedZ)) return true;
        for (int[] off : extraBeds) {
            if (matchesBedPair(b, bedX + off[0], bedY + off[1], bedZ + off[2])) return true;
        }
        return false;
    }

    private boolean matchesBedPair(Block b, int bx, int by, int bz) {
        int x = b.getX(), y = b.getY(), z = b.getZ();
        if (x == bx && y == by && z == bz) return true;
        if (b.getBlockData() instanceof Bed bed) {
            if (bed.getPart() == Bed.Part.FOOT) {
                Block head = b.getRelative(bed.getFacing());
                return head.getX() == bx && head.getY() == by && head.getZ() == bz;
            } else {
                Block foot = b.getRelative(bed.getFacing().getOppositeFace());
                return (x == bx && y == by && z == bz)
                        || (foot.getX() == bx && foot.getY() == by && foot.getZ() == bz);
            }
        }
        return false;
    }

    /* ================= interact ================= */

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onBedClick(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block b = e.getClickedBlock();
        if (!isTavernBed(b)) return;

        Player pl = e.getPlayer();
        // cancel vanilla sleep / MAVOHomes bind attempts on THIS bed
        e.setCancelled(true);

        if (!pl.hasPermission("mavotavern.use") && !pl.hasPermission("mavotavern.admin")) {
            msg(pl, ChatColor.RED + "You can't use the tavern bed.");
            return;
        }
        if (pl.getGameMode() == GameMode.SPECTATOR) return;
        if (sleeping.contains(pl.getUniqueId())) return;

        World w = pl.getWorld();
        if (!w.getName().equals(bedWorld)) {
            msg(pl, ChatColor.RED + "The tavern bed only works in the overworld plaza.");
            return;
        }

        if (!isUnlocked(pl, w)) {
            long sec = secondsUntilUnlock(pl, w);
            long mins = sec / 60L;
            String eta = mins >= 1
                    ? (mins + " min")
                    : (sec + "s");
            msg(pl, ChatColor.RED + "You've already rested. "
                    + ChatColor.GRAY + "Tavern bed unlocks at "
                    + ChatColor.YELLOW + "noon"
                    + ChatColor.GRAY + " (~" + eta + " of world-time left).");
            pl.playSound(pl.getLocation(), Sound.BLOCK_WOODEN_DOOR_CLOSE, 0.7f, 0.8f);
            return;
        }

        if (nightOnly && !isNightish(w)) {
            msg(pl, ChatColor.GRAY + "The tavern bed is for "
                    + ChatColor.BLUE + "night" + ChatColor.GRAY + " (and thunderstorms). "
                    + ChatColor.YELLOW + "Come back after dusk.");
            pl.playSound(pl.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.6f, 0.7f);
            return;
        }

        // Creative only is free (owner tag has no elevated perms in survival).
        boolean free = pl.getGameMode() == GameMode.CREATIVE;

        if (!free) {
            if (econ == null) {
                msg(pl, ChatColor.RED + "Economy is offline - try again in a moment.");
                return;
            }
            if (econ.getBalance(pl) < price) {
                msg(pl, ChatColor.RED + "You need " + ChatColor.GOLD + (long) price + " " + currency
                        + ChatColor.RED + " to rent a night. "
                        + ChatColor.GRAY + "(balance: " + (long) econ.getBalance(pl) + ")");
                pl.playSound(pl.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1f);
                return;
            }
        }

        // charge up-front
        if (!free) {
            econ.withdrawPlayer(pl, price);
            msg(pl, ChatColor.GRAY + "Paid " + ChatColor.GOLD + (long) price + " " + currency
                    + ChatColor.GRAY + " for a safe night.");
        } else {
            msg(pl, ChatColor.DARK_GRAY + "Creative free rest.");
        }

        startSleep(pl, w, free);
    }

    private void startSleep(Player pl, World w, boolean free) {
        sleeping.add(pl.getUniqueId());
        pl.setVelocity(pl.getVelocity().zero());
        Location bed = new Location(w, bedX + 0.5, bedY + 0.5, bedZ + 0.5);
        pl.playSound(bed, Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 0.6f);
        pl.sendTitle(ChatColor.DARK_AQUA + "" + ChatColor.BOLD + "zZz",
                ChatColor.GRAY + "Resting at the tavern...", 5, 40, 5);

        // short 2s "sleep" then skip night for the whole world
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!pl.isOnline()) { sleeping.remove(pl.getUniqueId()); return; }
            // skip night
            w.setTime(wakeTime);
            if (w.hasStorm()) w.setStorm(false);
            if (w.isThundering()) w.setThundering(false);

            // Lock until NEXT noon after waking (so tonight is free again after noon).
            // Bug fix: old day-index lock kept you blocked through the following night
            // of the same MC day after setTime(morning).
            saveLockUntilNextNoon(pl.getUniqueId(), w);

            sleeping.remove(pl.getUniqueId());
            pl.sendTitle(ChatColor.GOLD + "" + ChatColor.BOLD + "Good morning!",
                    ChatColor.GRAY + "The plaza wakes with you.", 5, 40, 10);
            pl.playSound(pl.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.4f);
            pl.playSound(pl.getLocation(), Sound.BLOCK_BELL_USE, 0.4f, 1.2f);
            msg(pl, ChatColor.GREEN + "You wake refreshed. "
                    + ChatColor.GRAY + "Bed locks until "
                    + ChatColor.YELLOW + "noon"
                    + ChatColor.GRAY + " — then you can rest again tonight.");
            if (!free) {
                Bukkit.broadcastMessage(ChatColor.DARK_GRAY + pl.getName()
                        + ChatColor.GRAY + " rented a night at the "
                        + ChatColor.RED + "Tavern" + ChatColor.GRAY + ".");
            }
            if (getConfig().getBoolean("holo.enabled", true)) spawnHolo();
        }, 40L);
    }

    /* ================= protect bed ================= */

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (!isTavernBed(e.getBlock())) return;
        if (e.getPlayer().hasPermission("mavotavern.admin")
                && e.getPlayer().getGameMode() == GameMode.CREATIVE) return;
        e.setCancelled(true);
        msg(e.getPlayer(), ChatColor.RED + "That's the tavern bed - hands off.");
    }

    /* ================= holo ================= */

    private void removeHolo() {
        if (holoUuid != null) {
            try {
                var e = Bukkit.getEntity(holoUuid);
                if (e != null) e.remove();
            } catch (Exception ignored) {}
            holoUuid = null;
        }
        // sweep by PDC near bed
        World w = Bukkit.getWorld(bedWorld);
        if (w == null) return;
        Location c = new Location(w, bedX + 0.5, bedY + 2.0, bedZ + 0.5);
        if (!c.getChunk().isLoaded()) c.getChunk().load();
        for (var e : w.getNearbyEntities(c, 4, 4, 4)) {
            if (e instanceof TextDisplay td
                    && td.getPersistentDataContainer().has(holoKey, PersistentDataType.BYTE)) {
                td.remove();
            }
        }
        String old = getConfig().getString("holo.uuid");
        if (old != null) {
            try {
                var e = Bukkit.getEntity(UUID.fromString(old));
                if (e != null) e.remove();
            } catch (Exception ignored) {}
        }
    }

    private void spawnHolo() {
        if (!bedEnabled) return;
        World w = Bukkit.getWorld(bedWorld);
        if (w == null) return;
        removeHolo();
        double yo = getConfig().getDouble("holo.y-offset", 2.4);
        Location loc = new Location(w, bedX + 0.5, bedY + yo, bedZ + 0.5);
        loc.getChunk().load();
        boolean night = isNightish(w);
        boolean noonPassed = w.getTime() >= 6000L;
        String status = night
                ? ChatColor.GREEN + "OPEN" + ChatColor.GRAY + " - right-click to rest"
                : ChatColor.YELLOW + "Opens at dusk";
        String line = ChatColor.RED + "" + ChatColor.BOLD + "\u2616 TAVERN BED \u2616"
                + "\n" + ChatColor.WHITE + "Skip the night for "
                + ChatColor.GOLD + (long) price + " " + currency
                + "\n" + status
                + "\n" + ChatColor.DARK_GRAY + "1 rest / night \u00B7 free again after noon";
        float scale = (float) getConfig().getDouble("holo.scale", 1.4);
        TextDisplay td = w.spawn(loc, TextDisplay.class, d -> {
            d.setText(line);
            d.setBillboard(Display.Billboard.CENTER);
            d.setShadowed(true);
            d.setSeeThrough(true);
            try {
                d.setDefaultBackground(false);
                d.setBackgroundColor(org.bukkit.Color.fromARGB(180, 40, 10, 10));
            } catch (Throwable ignored) {}
            d.setAlignment(TextDisplay.TextAlignment.CENTER);
            d.setLineWidth(240);
            var tr = d.getTransformation();
            tr.getScale().set(scale);
            d.setTransformation(tr);
            d.setViewRange(1.2f);
            try { d.setBrightness(new Display.Brightness(15, 15)); } catch (Throwable ignored) {}
            d.setPersistent(true);
            d.getPersistentDataContainer().set(holoKey, PersistentDataType.BYTE, (byte) 1);
        });
        holoUuid = td.getUniqueId();
        getConfig().set("holo.uuid", holoUuid.toString());
        saveConfig();
    }

    /* ================= build hut ================= */

    /** Small spruce hut with a red bed, door, lantern. Built relative to player facing. */
    private void buildHut(Player pl) {
        Location base = pl.getLocation().getBlock().getLocation();
        World w = base.getWorld();
        BlockFace face = yawToFace(pl.getLocation().getYaw());
        BlockFace left = rotateLeft(face);
        BlockFace right = rotateRight(face);

        int ox = base.getBlockX();
        int oy = base.getBlockY();
        int oz = base.getBlockZ();

        // clear 5x5x4 and floor
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                for (int dy = 0; dy <= 4; dy++) {
                    Block bl = w.getBlockAt(ox + dx, oy + dy, oz + dz);
                    if (dy == 0) bl.setType(Material.SPRUCE_PLANKS, false);
                    else bl.setType(Material.AIR, false);
                }
            }
        }
        // walls
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                boolean edge = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                if (!edge) continue;
                for (int dy = 1; dy <= 2; dy++) {
                    w.getBlockAt(ox + dx, oy + dy, oz + dz).setType(Material.SPRUCE_LOG, false);
                }
                w.getBlockAt(ox + dx, oy + 3, oz + dz).setType(Material.SPRUCE_STAIRS, false);
            }
        }
        // roof fill
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                w.getBlockAt(ox + dx, oy + 3, oz + dz).setType(Material.SPRUCE_PLANKS, false);
            }
        }
        w.getBlockAt(ox, oy + 4, oz).setType(Material.SPRUCE_SLAB, false);

        // doorway on facing side
        int doorX = ox + face.getModX() * 2;
        int doorZ = oz + face.getModZ() * 2;
        w.getBlockAt(doorX, oy + 1, doorZ).setType(Material.AIR, false);
        w.getBlockAt(doorX, oy + 2, doorZ).setType(Material.AIR, false);
        // spruce door
        Block doorBottom = w.getBlockAt(doorX, oy + 1, doorZ);
        doorBottom.setType(Material.SPRUCE_DOOR, false);
        try {
            org.bukkit.block.data.type.Door door = (org.bukkit.block.data.type.Door) doorBottom.getBlockData();
            door.setFacing(face);
            door.setHalf(org.bukkit.block.data.Bisected.Half.BOTTOM);
            doorBottom.setBlockData(door, false);
            Block doorTop = doorBottom.getRelative(BlockFace.UP);
            doorTop.setType(Material.SPRUCE_DOOR, false);
            org.bukkit.block.data.type.Door door2 = (org.bukkit.block.data.type.Door) doorTop.getBlockData();
            door2.setFacing(face);
            door2.setHalf(org.bukkit.block.data.Bisected.Half.TOP);
            doorTop.setBlockData(door2, false);
        } catch (Throwable ignored) {}

        // bed opposite door (toward -face), head toward door so foot is back wall
        int bedX = ox - face.getModX();
        int bedZ = oz - face.getModZ();
        placeBed(w, bedX, oy + 1, bedZ, face); // head faces door (=face)

        // lantern + carpet + barrel flavour
        w.getBlockAt(ox + left.getModX(), oy + 2, oz + left.getModZ()).setType(Material.LANTERN, false);
        w.getBlockAt(ox + right.getModX(), oy + 1, oz + right.getModZ()).setType(Material.BARREL, false);
        w.getBlockAt(ox, oy + 1, oz).setType(Material.RED_CARPET, false);

        // register bed foot/head: store HEAD position as configured bed
        // placeBed puts head at (bedX,bedY,bedZ)
        getConfig().set("bed.enabled", true);
        getConfig().set("bed.world", w.getName());
        getConfig().set("bed.x", bedX);
        getConfig().set("bed.y", oy + 1);
        getConfig().set("bed.z", bedZ);
        saveConfig();
        reloadLocal();
        spawnHolo();

        pl.sendMessage(prefix + ChatColor.GREEN + "Tavern hut built. "
                + ChatColor.GRAY + "Bed at " + bedX + "," + (oy + 1) + "," + bedZ
                + ChatColor.DARK_GRAY + " \u00B7 right-click at night to test.");
        pl.playSound(pl.getLocation(), Sound.BLOCK_ANVIL_USE, 0.5f, 1.2f);
    }

    private void placeBed(World w, int x, int y, int z, BlockFace headFacing) {
        // head at (x,y,z), foot opposite facing
        Block head = w.getBlockAt(x, y, z);
        Block foot = head.getRelative(headFacing.getOppositeFace());
        head.setType(Material.RED_BED, false);
        foot.setType(Material.RED_BED, false);
        try {
            Bed headData = (Bed) head.getBlockData();
            headData.setPart(Bed.Part.HEAD);
            headData.setFacing(headFacing);
            head.setBlockData(headData, false);
            Bed footData = (Bed) foot.getBlockData();
            footData.setPart(Bed.Part.FOOT);
            footData.setFacing(headFacing);
            foot.setBlockData(footData, false);
        } catch (Throwable ex) {
            getLogger().warning("Bed blockdata failed: " + ex.getMessage());
        }
    }

    private static BlockFace yawToFace(float yaw) {
        yaw = (yaw % 360 + 360) % 360;
        if (yaw >= 315 || yaw < 45) return BlockFace.SOUTH;
        if (yaw < 135) return BlockFace.WEST;
        if (yaw < 225) return BlockFace.NORTH;
        return BlockFace.EAST;
    }
    private static BlockFace rotateLeft(BlockFace f) {
        return switch (f) {
            case NORTH -> BlockFace.WEST;
            case WEST -> BlockFace.SOUTH;
            case SOUTH -> BlockFace.EAST;
            default -> BlockFace.NORTH;
        };
    }
    private static BlockFace rotateRight(BlockFace f) {
        return switch (f) {
            case NORTH -> BlockFace.EAST;
            case EAST -> BlockFace.SOUTH;
            case SOUTH -> BlockFace.WEST;
            default -> BlockFace.NORTH;
        };
    }

    /* ================= commands ================= */

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player pl)) {
            sender.sendMessage("In-game only.");
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("info")) {
            msg(pl, ChatColor.GRAY + "Price: " + ChatColor.GOLD + (long) price + " " + currency
                    + ChatColor.GRAY + " \u00B7 Night only: " + nightOnly
                    + ChatColor.GRAY + " \u00B7 Bed: " + (bedEnabled
                    ? (bedWorld + " " + bedX + "," + bedY + "," + bedZ) : ChatColor.RED + "not set"));
            boolean unlocked = bedEnabled && isUnlocked(pl, pl.getWorld());
            if (unlocked) {
                msg(pl, ChatColor.GREEN + "Your tavern rest is available.");
            } else {
                long sec = secondsUntilUnlock(pl, pl.getWorld());
                msg(pl, ChatColor.RED + "Locked until noon "
                        + ChatColor.GRAY + "(~" + (sec / 60L) + " min world-time).");
            }
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (!pl.hasPermission("mavotavern.admin") && !sub.equals("info")) {
            msg(pl, ChatColor.RED + "No permission.");
            return true;
        }
        switch (sub) {
            case "setbed" -> {
                Block b = pl.getLocation().getBlock().getRelative(BlockFace.DOWN);
                // prefer target bed
                Block target = pl.getTargetBlockExact(6);
                if (target != null && target.getType().name().endsWith("_BED")) b = target;
                else if (!pl.getLocation().getBlock().getType().name().endsWith("_BED")
                        && !b.getType().name().endsWith("_BED")) {
                    // use block under feet if standing on bed, else require looking at bed
                    Block at = pl.getLocation().getBlock();
                    if (at.getType().name().endsWith("_BED")) b = at;
                    else {
                        msg(pl, ChatColor.RED + "Look at a bed (or stand on one) and run /tavern setbed.");
                        return true;
                    }
                }
                if (b.getBlockData() instanceof Bed bed && bed.getPart() == Bed.Part.FOOT) {
                    b = b.getRelative(bed.getFacing()); // store HEAD
                }
                getConfig().set("bed.enabled", true);
                getConfig().set("bed.world", b.getWorld().getName());
                getConfig().set("bed.x", b.getX());
                getConfig().set("bed.y", b.getY());
                getConfig().set("bed.z", b.getZ());
                saveConfig();
                reloadLocal();
                spawnHolo();
                msg(pl, ChatColor.GREEN + "Tavern bed set at "
                        + b.getX() + "," + b.getY() + "," + b.getZ()
                        + ChatColor.GRAY + " in " + b.getWorld().getName() + ".");
            }
            case "build20" -> {
                if (!pl.isOp() && !pl.hasPermission("mavotavern.admin")) {
                    msg(pl, ChatColor.RED + "No permission.");
                    return true;
                }
                buildInn(pl);
            }
            case "bar" -> openBar(pl);
            case "build" -> {
                if (pl.getGameMode() != GameMode.CREATIVE && !pl.isOp()) {
                    msg(pl, ChatColor.RED + "Build the hut in creative (or from console-op).");
                    return true;
                }
                buildHut(pl);
            }
            case "clear" -> {
                getConfig().set("bed.enabled", false);
                saveConfig();
                reloadLocal();
                removeHolo();
                msg(pl, ChatColor.GRAY + "Tavern bed cleared.");
            }
            case "reload" -> {
                reloadLocal();
                loadUsage();
        barDay.clear();
        if (data.getConfigurationSection("bar") != null) {
            for (String us : data.getConfigurationSection("bar").getKeys(false)) {
                try {
                    UUID u = UUID.fromString(us);
                    Map<String, Long> mm = new HashMap<>();
                    if (data.getConfigurationSection("bar." + us) != null) {
                        for (String k : data.getConfigurationSection("bar." + us).getKeys(false)) {
                            mm.put(k, data.getLong("bar." + us + "." + k));
                        }
                    }
                    barDay.put(u, mm);
                } catch (Exception ignored) {}
            }
        }
                if (bedEnabled) spawnHolo();
                msg(pl, ChatColor.GREEN + "Tavern reloaded. Price=" + (long) price);
            }
            case "unlock" -> {
                if (args.length < 2) {
                    clearLock(pl.getUniqueId());
                    msg(pl, ChatColor.GREEN + "Your tavern lock cleared — bed free now.");
                } else {
                    // online or offline by name
                    Player t = Bukkit.getPlayerExact(args[1]);
                    UUID id = t != null ? t.getUniqueId() : Bukkit.getOfflinePlayer(args[1]).getUniqueId();
                    clearLock(id);
                    msg(pl, ChatColor.GREEN + "Cleared tavern lock for " + args[1] + ".");
                }
            }
            default -> msg(pl, ChatColor.GRAY + "/tavern info | setbed | build | build20 | bar | clear | reload | unlock [player]");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) {
            String p = args[0].toLowerCase(Locale.ROOT);
            return List.of("info", "setbed", "build", "build20", "bar", "clear", "reload", "unlock").stream()
                    .filter(x -> x.startsWith(p)).toList();
        }
        return List.of();
    }

    private void msg(Player pl, String m) {
        pl.sendMessage(prefix + m);
    }
    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }
    private static String strip(String s) {
        return ChatColor.stripColor(s);
    }

    /* ================= 20x20 rebuild + bar ================= */

    private void buildInn(Player p) {
        World w = p.getWorld();
        Location loc = p.getLocation().getBlock().getLocation();
        int ox = loc.getBlockX();
        int oy = loc.getBlockY();
        int oz = loc.getBlockZ();
        // 20x20 footprint, interior 18
        for (int x = 0; x < 20; x++) {
            for (int z = 0; z < 20; z++) {
                w.getBlockAt(ox + x, oy - 1, oz + z).setType(Material.SPRUCE_PLANKS);
                boolean edge = x == 0 || z == 0 || x == 19 || z == 19;
                if (edge) {
                    for (int y = 0; y <= 4; y++) {
                        Material m = (y == 4) ? Material.DARK_OAK_SLAB : Material.SPRUCE_LOG;
                        if (y > 0 && y < 4 && !((x == 10 || x == 9) && z == 0 && y <= 2))
                            w.getBlockAt(ox + x, oy + y, oz + z).setType(y == 0 ? Material.SPRUCE_LOG : Material.SPRUCE_PLANKS);
                    }
                    w.getBlockAt(ox + x, oy + 4, oz + z).setType(Material.DARK_OAK_SLAB);
                } else {
                    w.getBlockAt(ox + x, oy + 4, oz + z).setType(Material.SPRUCE_SLAB);
                    if ((x + z) % 6 == 0) w.getBlockAt(ox + x, oy + 3, oz + z).setType(Material.LANTERN);
                }
            }
        }
        // door gap
        for (int y = 0; y <= 2; y++) {
            w.getBlockAt(ox + 9, oy + y, oz).setType(Material.AIR);
            w.getBlockAt(ox + 10, oy + y, oz).setType(Material.AIR);
        }
        // 4 beds in corners of room
        int[][] beds = {{3, 3}, {15, 3}, {3, 15}, {15, 15}};
        for (int[] b : beds) placeBed(w, ox + b[0], oy, oz + b[1], BlockFace.SOUTH);
        // bar counter
        for (int x = 6; x <= 13; x++) {
            w.getBlockAt(ox + x, oy, oz + 10).setType(Material.SPRUCE_STAIRS);
            w.getBlockAt(ox + x, oy + 1, oz + 10).setType(Material.AIR);
        }
        // bar villager
        Location vl = new Location(w, ox + 10.5, oy, oz + 11.5);
        for (Villager old : w.getEntitiesByClass(Villager.class)) {
            if (old.getLocation().distanceSquared(vl) < 4) old.remove();
        }
        Villager v = w.spawn(vl, Villager.class, vill -> {
            vill.setCustomName(ChatColor.GOLD + "Innkeeper");
            vill.setCustomNameVisible(true);
            vill.setAI(false);
            vill.setInvulnerable(true);
            vill.setProfession(Villager.Profession.NITWIT);
            vill.setRemoveWhenFarAway(false);
            vill.getPersistentDataContainer().set(boundKey, PersistentDataType.BYTE, (byte) 1);
        });
        // set primary bed + extras in config
        getConfig().set("bed.enabled", true);
        getConfig().set("bed.world", w.getName());
        getConfig().set("bed.x", ox + 3);
        getConfig().set("bed.y", oy);
        getConfig().set("bed.z", oz + 3);
        java.util.List<java.util.Map<String, Object>> extras = new java.util.ArrayList<>();
        extras.add(java.util.Map.of("x", 12, "y", 0, "z", 0));
        extras.add(java.util.Map.of("x", 0, "y", 0, "z", 12));
        extras.add(java.util.Map.of("x", 12, "y", 0, "z", 12));
        getConfig().set("extra-beds", extras);
        saveConfig();
        reloadLocal();
        spawnHolo();
        p.sendMessage(prefix + ChatColor.GREEN + "20x20 tavern built with 4 beds + innkeeper bar.");
        p.sendMessage(ChatColor.GRAY + "Right-click innkeeper for soulbound food/drink (1 each per MC day).");
    }

    private long mcDay(World w) { return w.getFullTime() / 24000L; }

    private boolean barUsed(UUID u, String kind, long day) {
        return barDay.computeIfAbsent(u, k -> new HashMap<>()).getOrDefault(kind, -1L) == day;
    }
    private void markBar(UUID u, String kind, long day) {
        barDay.computeIfAbsent(u, k -> new HashMap<>()).put(kind, day);
        data.set("bar." + u + "." + kind, day);
        dirty = true;
    }

    private void openBar(Player p) {
        if (!getConfig().getBoolean("bar.enabled", true)) {
            msg(p, ChatColor.GRAY + "Bar closed.");
            return;
        }
        long day = mcDay(p.getWorld());
        org.bukkit.inventory.Inventory inv = Bukkit.createInventory(null, 9, ChatColor.GOLD + "Tavern Bar");
        boolean foodUsed = barUsed(p.getUniqueId(), "food", day);
        boolean drinkUsed = barUsed(p.getUniqueId(), "drink", day);
        int fp = getConfig().getInt("bar.food-price", 50);
        int dp = getConfig().getInt("bar.drink-price", 75);
        inv.setItem(3, boundIcon(Material.COOKED_BEEF, ChatColor.RED + "Hearty Stew",
                List.of(ChatColor.GRAY + "Heal + food, soulbound",
                        ChatColor.YELLOW + "Price: " + fp + " " + strip(currency),
                        foodUsed ? ChatColor.RED + "Already eaten today" : ChatColor.GREEN + "Click to buy"), "food"));
        inv.setItem(5, boundIcon(Material.HONEY_BOTTLE, ChatColor.AQUA + "House Ale",
                List.of(ChatColor.GRAY + "Refresh + short regen, soulbound",
                        ChatColor.YELLOW + "Price: " + dp + " " + strip(currency),
                        drinkUsed ? ChatColor.RED + "Already drunk today" : ChatColor.GREEN + "Click to buy"), "drink"));
        p.openInventory(inv);
    }

    private ItemStack boundIcon(Material mat, String name, List<String> lore, String tag) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(name);
        m.setLore(lore);
        m.getPersistentDataContainer().set(boundKey, PersistentDataType.STRING, tag);
        it.setItemMeta(m);
        return it;
    }

    private ItemStack makeSoulbound(Material mat, String name, String kind) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(name);
        m.setLore(List.of(ChatColor.DARK_PURPLE + "Soulbound", ChatColor.GRAY + "Tavern only — cannot be sold"));
        m.getPersistentDataContainer().set(boundKey, PersistentDataType.STRING, kind);
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onBarClick(org.bukkit.event.inventory.InventoryClickEvent e) {
        if (e.getView().getTitle() == null) return;
        if (!ChatColor.stripColor(e.getView().getTitle()).equals("Tavern Bar")) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack cur = e.getCurrentItem();
        if (cur == null || !cur.hasItemMeta()) return;
        String tag = cur.getItemMeta().getPersistentDataContainer().get(boundKey, PersistentDataType.STRING);
        if (tag == null) return;
        long day = mcDay(p.getWorld());
        if (barUsed(p.getUniqueId(), tag, day)) {
            msg(p, ChatColor.RED + "Already had your " + tag + " today. Come back next MC day.");
            return;
        }
        int price = tag.equals("food") ? getConfig().getInt("bar.food-price", 50) : getConfig().getInt("bar.drink-price", 75);
        if (econ == null || !econ.has(p, price)) {
            msg(p, ChatColor.RED + "Need " + price + " coins.");
            return;
        }
        econ.withdrawPlayer(p, price);
        markBar(p.getUniqueId(), tag, day);
        if (tag.equals("food")) {
            ItemStack food = makeSoulbound(Material.COOKED_BEEF, ChatColor.RED + "Hearty Stew", "food");
            food.setAmount(1);
            p.getInventory().addItem(food);
            // instant heal sip
            try {
                var attr = p.getAttribute(Attribute.MAX_HEALTH);
                double max = attr != null ? attr.getValue() : 20;
                p.setHealth(Math.min(max, p.getHealth() + getConfig().getInt("bar.food-heal", 8)));
            } catch (Throwable t) {
                p.setFoodLevel(Math.min(20, p.getFoodLevel() + 8));
            }
            p.setFoodLevel(Math.min(20, p.getFoodLevel() + 8));
            msg(p, ChatColor.GREEN + "Hearty stew served (soulbound). Feel better!");
        } else {
            ItemStack drink = makeSoulbound(Material.HONEY_BOTTLE, ChatColor.AQUA + "House Ale", "drink");
            p.getInventory().addItem(drink);
            int sec = getConfig().getInt("bar.drink-effects-seconds", 120);
            p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, sec * 20, 0));
            p.addPotionEffect(new PotionEffect(PotionEffectType.SATURATION, 20 * 5, 0));
            msg(p, ChatColor.GREEN + "House ale served (soulbound). Cheers!");
        }
        p.closeInventory();
    }

    @EventHandler
    public void onInnkeeper(org.bukkit.event.player.PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (!(e.getRightClicked() instanceof Villager v)) return;
        if (!v.getPersistentDataContainer().has(boundKey, PersistentDataType.BYTE)) return;
        e.setCancelled(true);
        openBar(e.getPlayer());
    }

    /** Prevent selling soulbound tavern items via any inventory named Shop if present - mark lore only; ESGUI sell filter may need material blacklist. */
    @EventHandler
    public void onDropBound(org.bukkit.event.player.PlayerDropItemEvent e) {
        ItemStack it = e.getItemDrop().getItemStack();
        if (it.hasItemMeta() && it.getItemMeta().getPersistentDataContainer().has(boundKey, PersistentDataType.STRING)) {
            // allow drop but item stays soulbound; shops should refuse via lore/name - optional cancel:
            // e.setCancelled(true);
        }
    }

}
