package mavo.mobfarm;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Chest;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.block.Sign;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

/**
 * MAVOMobFarm 1.0
 * /mobfarm enter  - pay 5000, 10s cancel-on-move, 30min session (keeps ticking on leave)
 * /mobfarm leave  - exit to center pad (session continues for stash trips)
 * Rooms lock to event owner; 5 stacked spawners; buy extras (10k/20k/40k...); reset to 5 on end.
 * Profession XP on farm kills scaled (default 30%). Non-PVP. Community hopper sells junk → stack goal.
 */
public final class MobFarm extends JavaPlugin implements Listener, TabCompleter {

    private Economy econ;
    private File dataFile;
    private YamlConfiguration data;

    private Location center;
    private final Map<String, RoomDef> rooms = new HashMap<>();
    private final Map<UUID, Session> sessions = new HashMap<>();
    private final Map<UUID, PendingEnter> pending = new HashMap<>();

    // community stack goal
    private long communityCoins;
    private long communityTarget;
    private int communityStack; // base spawners unlocked globally for next events

    static final class RoomDef {
        String id, display; EntityType mob; int size; boolean light;
        int ox, oy, oz;
        Location door; // set at runtime
    }
    static final class Session {
        UUID owner;
        String roomId;
        long endsAtMs;
        int extraSpawners; // bought this event
        Location returnLoc;
        List<Location> spawnerLocs = new ArrayList<>();
        boolean active = true;
    }
    static final class PendingEnter {
        Location start; long payAt; int secondsLeft; BukkitTask task; long cost;
    }

    @Override public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider();
        loadAll();
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("mobfarm") != null) getCommand("mobfarm").setTabCompleter(this);
        // session ticker
        new BukkitRunnable() {
            @Override public void run() {
                long now = System.currentTimeMillis();
                List<UUID> end = new ArrayList<>();
                for (Map.Entry<UUID, Session> e : sessions.entrySet()) {
                    if (now >= e.getValue().endsAtMs) end.add(e.getKey());
                }
                for (UUID u : end) endSession(u, true);
            }
        }.runTaskTimer(this, 40L, 40L);
        getLogger().info("MAVOMobFarm 1.0 enabled. Rooms=" + rooms.size() + " stack=" + communityStack);
    }

    @Override public void onDisable() {
        for (UUID u : new ArrayList<>(sessions.keySet())) endSession(u, false);
        saveData();
    }

    private void loadAll() {
        rooms.clear();
        String wn = getConfig().getString("center.world", "world");
        World w = Bukkit.getWorld(wn);
        if (w == null && !Bukkit.getWorlds().isEmpty()) w = Bukkit.getWorlds().get(0);
        if (w != null) {
            center = new Location(w,
                    getConfig().getDouble("center.x"),
                    getConfig().getDouble("center.y"),
                    getConfig().getDouble("center.z"));
        }
        ConfigurationSection rs = getConfig().getConfigurationSection("rooms");
        if (rs != null) {
            for (String id : rs.getKeys(false)) {
                ConfigurationSection c = rs.getConfigurationSection(id);
                if (c == null) continue;
                RoomDef r = new RoomDef();
                r.id = id;
                r.display = ChatColor.translateAlternateColorCodes('&', c.getString("display", id));
                try { r.mob = EntityType.valueOf(c.getString("mob", "ZOMBIE").toUpperCase(Locale.ROOT)); }
                catch (Exception ex) { r.mob = EntityType.ZOMBIE; }
                r.size = Math.max(20, Math.min(100, c.getInt("size", 40)));
                r.light = c.getBoolean("light", true);
                r.ox = c.getInt("offset.x", 0);
                r.oy = c.getInt("offset.y", 0);
                r.oz = c.getInt("offset.z", 0);
                rooms.put(id, r);
            }
        }
        communityCoins = data.getLong("community.coins", 0L);
        communityTarget = data.getLong("community.target", getConfig().getLong("community.start-target", 1_000_000L));
        communityStack = data.getInt("community.stack", getConfig().getInt("community.stack-start", 5));
    }

    private void saveData() {
        data.set("community.coins", communityCoins);
        data.set("community.target", communityTarget);
        data.set("community.stack", communityStack);
        try { data.save(dataFile); } catch (Exception ignored) {}
    }

    /* ================= commands ================= */
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.GOLD + "/mobfarm enter|leave|status|info|buy"
                    + (sender.hasPermission("mavomobfarm.admin") ? "|setcenter|build" : ""));
            return true;
        }
        String a = args[0].toLowerCase(Locale.ROOT);
        if (a.equals("info")) {
            sender.sendMessage(ChatColor.GOLD + "MobFarm " + ChatColor.GRAY + "entry "
                    + ChatColor.YELLOW + getConfig().getInt("entry-cost") + " coins"
                    + ChatColor.GRAY + ", session " + getConfig().getInt("session-minutes") + " min, XP scale "
                    + ChatColor.AQUA + getConfig().getDouble("profession-xp-scale"));
            sender.sendMessage(ChatColor.GRAY + "Community stack goal: " + ChatColor.YELLOW + communityCoins + "/" + communityTarget
                    + ChatColor.GRAY + " → base spawners " + ChatColor.GREEN + communityStack);
            return true;
        }
        if (a.equals("setcenter") && sender.hasPermission("mavomobfarm.admin") && sender instanceof Player p) {
            center = p.getLocation().getBlock().getLocation().add(0.5, 0, 0.5);
            getConfig().set("center.world", center.getWorld().getName());
            getConfig().set("center.x", center.getX());
            getConfig().set("center.y", center.getY());
            getConfig().set("center.z", center.getZ());
            saveConfig();
            p.sendMessage(ChatColor.GREEN + "MobFarm center set.");
            return true;
        }
        if (a.equals("build") && sender.hasPermission("mavomobfarm.admin") && sender instanceof Player p) {
            if (center == null) { p.sendMessage(ChatColor.RED + "Set center first."); return true; }
            buildComplex(p);
            return true;
        }
        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }

        switch (a) {
            case "enter" -> beginEnter(p);
            case "leave" -> leaveFarm(p, false);
            case "status" -> status(p);
            case "buy" -> buySpawner(p);
            default -> p.sendMessage(ChatColor.RED + "Unknown. /mobfarm enter|leave|status|buy|info");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) {
            List<String> o = new ArrayList<>(List.of("enter", "leave", "status", "buy", "info"));
            if (s.hasPermission("mavomobfarm.admin")) { o.add("setcenter"); o.add("build"); }
            return o.stream().filter(x -> x.startsWith(a[0].toLowerCase(Locale.ROOT))).toList();
        }
        return List.of();
    }

    private void status(Player p) {
        Session s = sessions.get(p.getUniqueId());
        if (s == null || !s.active) {
            p.sendMessage(ChatColor.GRAY + "No active mobfarm session.");
            return;
        }
        long left = Math.max(0, (s.endsAtMs - System.currentTimeMillis()) / 1000L);
        p.sendMessage(ChatColor.GOLD + "Session: " + ChatColor.WHITE + s.roomId
                + ChatColor.GRAY + "  " + (left / 60) + "m " + (left % 60) + "s left"
                + ChatColor.GRAY + "  spawners " + ChatColor.YELLOW + (communityStack + s.extraSpawners));
    }

    private void beginEnter(Player p) {
        if (center == null) { p.sendMessage(ChatColor.RED + "MobFarm not set up yet."); return; }
        if (sessions.containsKey(p.getUniqueId()) && sessions.get(p.getUniqueId()).active) {
            p.sendMessage(ChatColor.YELLOW + "You already have a session. /mobfarm leave to exit the zone (timer keeps running).");
            return;
        }
        // if session still valid (left early) just re-teleport
        Session existing = sessions.get(p.getUniqueId());
        if (existing != null && existing.endsAtMs > System.currentTimeMillis()) {
            existing.active = true;
            teleportToRoom(p, existing);
            p.sendMessage(ChatColor.GREEN + "Welcome back — session still running.");
            return;
        }
        if (pending.containsKey(p.getUniqueId())) {
            p.sendMessage(ChatColor.YELLOW + "Already entering… don't move!");
            return;
        }
        long cost = getConfig().getLong("entry-cost", 5000);
        if (econ == null || !econ.has(p, cost)) {
            p.sendMessage(ChatColor.RED + "Need " + cost + " coins to enter the mob farm.");
            return;
        }
        int secs = getConfig().getInt("entry-cancel-seconds", 10);
        PendingEnter pe = new PendingEnter();
        pe.start = p.getLocation().clone();
        pe.secondsLeft = secs;
        pe.cost = cost;
        pe.task = new BukkitRunnable() {
            @Override public void run() {
                if (!p.isOnline()) { pending.remove(p.getUniqueId()); cancel(); return; }
                pe.secondsLeft--;
                if (pe.secondsLeft > 0) {
                    p.sendActionBar(ChatColor.GOLD + "Entering mob farm in " + pe.secondsLeft + "s… " + ChatColor.GRAY + "don't move!");
                    return;
                }
                pending.remove(p.getUniqueId());
                cancel();
                if (!econ.has(p, pe.cost)) {
                    p.sendMessage(ChatColor.RED + "Not enough coins.");
                    return;
                }
                econ.withdrawPlayer(p, pe.cost);
                startSession(p);
            }
        }.runTaskTimer(this, 20L, 20L);
        pending.put(p.getUniqueId(), pe);
        p.sendMessage(ChatColor.GOLD + "Entering mob farm… " + ChatColor.YELLOW + secs + "s" + ChatColor.GRAY + " (move to cancel). Cost: " + cost);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        PendingEnter pe = pending.get(e.getPlayer().getUniqueId());
        if (pe == null) return;
        if (e.getTo() == null) return;
        if (e.getFrom().getBlockX() != e.getTo().getBlockX()
                || e.getFrom().getBlockY() != e.getTo().getBlockY()
                || e.getFrom().getBlockZ() != e.getTo().getBlockZ()) {
            pe.task.cancel();
            pending.remove(e.getPlayer().getUniqueId());
            e.getPlayer().sendMessage(ChatColor.RED + "Mob farm entry cancelled (you moved).");
        }
    }

    private void startSession(Player p) {
        // pick free room or first
        String roomId = null;
        for (String id : rooms.keySet()) {
            boolean taken = false;
            for (Session s : sessions.values()) {
                if (s.active && s.endsAtMs > System.currentTimeMillis() && id.equals(s.roomId)) { taken = true; break; }
            }
            if (!taken) { roomId = id; break; }
        }
        if (roomId == null) roomId = rooms.keySet().iterator().next();
        Session s = new Session();
        s.owner = p.getUniqueId();
        s.roomId = roomId;
        s.endsAtMs = System.currentTimeMillis() + getConfig().getInt("session-minutes", 30) * 60_000L;
        s.returnLoc = p.getLocation().clone();
        s.extraSpawners = 0;
        sessions.put(p.getUniqueId(), s);
        ensureRoomBuilt(roomId);
        placeSpawners(s);
        lockDoor(s, true);
        teleportToRoom(p, s);
        p.sendMessage(ChatColor.GREEN + "Mob farm session started! "
                + ChatColor.GRAY + getConfig().getInt("session-minutes") + " minutes. Room: "
                + rooms.get(roomId).display);
        p.sendMessage(ChatColor.GRAY + "Use " + ChatColor.YELLOW + "/mobfarm leave" + ChatColor.GRAY
                + " for stash trips — timer keeps running. " + ChatColor.YELLOW + "/mobfarm buy" + ChatColor.GRAY + " extra spawners.");
    }

    private void leaveFarm(Player p, boolean ended) {
        Session s = sessions.get(p.getUniqueId());
        if (s == null) {
            p.sendMessage(ChatColor.GRAY + "No session.");
            return;
        }
        if (ended) {
            // full end handled elsewhere
        } else {
            // soft leave — keep session
            if (s.returnLoc != null) p.teleport(s.returnLoc);
            else if (center != null) p.teleport(center);
            p.sendMessage(ChatColor.YELLOW + "Left the farm zone. Session still active — /mobfarm enter to return.");
        }
    }

    private void endSession(UUID u, boolean announce) {
        Session s = sessions.remove(u);
        if (s == null) return;
        // clear extra spawners back to community base
        clearSpawners(s);
        lockDoor(s, false);
        Player p = Bukkit.getPlayer(u);
        if (p != null && p.isOnline()) {
            if (s.returnLoc != null) p.teleport(s.returnLoc);
            else if (center != null) p.teleport(center);
            if (announce) p.sendMessage(ChatColor.RED + "Mob farm session ended. Extra spawners cleared.");
        }
        saveData();
    }

    private void buySpawner(Player p) {
        Session s = sessions.get(p.getUniqueId());
        if (s == null || s.endsAtMs < System.currentTimeMillis()) {
            p.sendMessage(ChatColor.RED + "No active session.");
            return;
        }
        long base = getConfig().getLong("extra-spawner-base-cost", 10_000);
        long cost = base * (1L << Math.min(10, s.extraSpawners)); // 10k,20k,40k...
        if (econ == null || !econ.has(p, cost)) {
            p.sendMessage(ChatColor.RED + "Need " + cost + " coins for next spawner.");
            return;
        }
        econ.withdrawPlayer(p, cost);
        s.extraSpawners++;
        placeSpawners(s);
        p.sendMessage(ChatColor.GREEN + "Extra spawner purchased! Total: "
                + (communityStack + s.extraSpawners) + ChatColor.GRAY + " (next costs " + (cost * 2) + ")");
    }

    /* ================= build / spawners ================= */
    private Location roomOrigin(RoomDef r) {
        return center.clone().add(r.ox, r.oy, r.oz);
    }

    private void buildComplex(Player admin) {
        World w = center.getWorld();
        // pad
        for (int x = -3; x <= 3; x++) for (int z = -3; z <= 3; z++) {
            w.getBlockAt(center.getBlockX() + x, center.getBlockY() - 1, center.getBlockZ() + z).setType(Material.POLISHED_DEEPSLATE);
        }
        for (RoomDef r : rooms.values()) buildRoom(r);
        // community hopper chest at center
        Block chest = w.getBlockAt(center.getBlockX(), center.getBlockY(), center.getBlockZ() + 4);
        chest.setType(Material.CHEST);
        Block hop = w.getBlockAt(center.getBlockX(), center.getBlockY() - 1, center.getBlockZ() + 4);
        hop.setType(Material.HOPPER);
        admin.sendMessage(ChatColor.GREEN + "MobFarm complex built (" + rooms.size() + " rooms).");
    }

    private void ensureRoomBuilt(String id) {
        RoomDef r = rooms.get(id);
        if (r == null || center == null) return;
        Location o = roomOrigin(r);
        // quick check: floor present?
        if (o.getBlock().getRelative(0, -1, 0).getType() == Material.AIR) buildRoom(r);
    }

    private void buildRoom(RoomDef r) {
        World w = center.getWorld();
        Location o = roomOrigin(r);
        int half = r.size / 2;
        int y0 = o.getBlockY();
        // floor + walls + roof shell
        for (int x = -half; x <= half; x++) {
            for (int z = -half; z <= half; z++) {
                w.getBlockAt(o.getBlockX() + x, y0 - 1, o.getBlockZ() + z).setType(Material.DEEPSLATE_TILES);
                boolean edge = Math.abs(x) == half || Math.abs(z) == half;
                if (edge) {
                    for (int y = 0; y <= 6; y++) {
                        Material m = (y == 6) ? Material.DEEPSLATE_TILES : Material.DEEPSLATE_BRICKS;
                        w.getBlockAt(o.getBlockX() + x, y0 + y, o.getBlockZ() + z).setType(m);
                    }
                } else {
                    w.getBlockAt(o.getBlockX() + x, y0 + 6, o.getBlockZ() + z).setType(Material.DEEPSLATE_TILES);
                    if (r.light && (x % 5 == 0 && z % 5 == 0)) {
                        w.getBlockAt(o.getBlockX() + x, y0 + 5, o.getBlockZ() + z).setType(Material.SEA_LANTERN);
                    }
                }
            }
        }
        // door opening south edge center
        int dx = o.getBlockX();
        int dz = o.getBlockZ() + half;
        for (int y = 0; y <= 2; y++) {
            w.getBlockAt(dx, y0 + y, dz).setType(Material.AIR);
            w.getBlockAt(dx + 1, y0 + y, dz).setType(Material.AIR);
        }
        w.getBlockAt(dx, y0, dz).setType(Material.IRON_DOOR);
        r.door = new Location(w, dx, y0, dz);
        // grinder hole + hoppers + double chest
        int gx = o.getBlockX();
        int gz = o.getBlockZ();
        w.getBlockAt(gx, y0 - 1, gz).setType(Material.AIR);
        w.getBlockAt(gx, y0 - 2, gz).setType(Material.HOPPER);
        w.getBlockAt(gx, y0 - 3, gz).setType(Material.CHEST);
        w.getBlockAt(gx + 1, y0 - 3, gz).setType(Material.CHEST);
        // water push corners simplified: drop pad
        w.getBlockAt(gx, y0, gz).setType(Material.STONE_PRESSURE_PLATE);
        // holo-ish sign
        Block sign = w.getBlockAt(dx, y0 + 3, dz + 1);
        sign.setType(Material.OAK_WALL_SIGN);
        if (sign.getState() instanceof Sign si) {
            si.setLine(0, ChatColor.GOLD + "MOBFARM");
            si.setLine(1, ChatColor.stripColor(r.display));
            si.setLine(2, ChatColor.GRAY + r.mob.name());
            si.update();
        }
    }

    private void placeSpawners(Session s) {
        RoomDef r = rooms.get(s.roomId);
        if (r == null) return;
        clearSpawners(s);
        Location o = roomOrigin(r);
        int total = communityStack + s.extraSpawners;
        // stack upward in center column
        for (int i = 0; i < total; i++) {
            Block b = o.getWorld().getBlockAt(o.getBlockX(), o.getBlockY() + 1 + i, o.getBlockZ() - 3);
            b.setType(Material.SPAWNER);
            if (b.getState() instanceof CreatureSpawner cs) {
                cs.setSpawnedType(r.mob);
                cs.update();
            }
            s.spawnerLocs.add(b.getLocation());
        }
    }

    private void clearSpawners(Session s) {
        for (Location l : s.spawnerLocs) {
            if (l.getBlock().getType() == Material.SPAWNER) l.getBlock().setType(Material.AIR);
        }
        s.spawnerLocs.clear();
    }

    private void lockDoor(Session s, boolean locked) {
        // iron door + owner tag in data; physical lock via no-open for others
        data.set("locks." + s.roomId, locked ? s.owner.toString() : null);
        saveData();
    }

    private void teleportToRoom(Player p, Session s) {
        RoomDef r = rooms.get(s.roomId);
        if (r == null || center == null) return;
        Location o = roomOrigin(r);
        Location dest = o.clone().add(0.5, 0, r.size / 2.0 - 2);
        dest.setYaw(180);
        p.teleport(dest);
    }

    /* ================= events ================= */
    @EventHandler(ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (getConfig().getBoolean("pvp", false)) return;
        if (!(e.getEntity() instanceof Player) || !(e.getDamager() instanceof Player)) return;
        if (center == null) return;
        Player a = (Player) e.getEntity();
        Player b = (Player) e.getDamager();
        if (nearFarm(a.getLocation()) || nearFarm(b.getLocation())) {
            e.setCancelled(true);
        }
    }

    private boolean nearFarm(Location l) {
        if (center == null || l.getWorld() != center.getWorld()) return false;
        return l.distanceSquared(center) < 200 * 200;
    }

    @EventHandler
    public void onDoor(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block b = e.getClickedBlock();
        if (b == null) return;
        // door lock: only event owner
        if (b.getType() == Material.IRON_DOOR || b.getType().name().contains("DOOR")) {
            for (RoomDef r : rooms.values()) {
                if (r.door == null) continue;
                if (b.getLocation().getBlockX() == r.door.getBlockX()
                        && b.getLocation().getBlockZ() == r.door.getBlockZ()
                        && Math.abs(b.getLocation().getBlockY() - r.door.getBlockY()) <= 1) {
                    String lock = data.getString("locks." + r.id);
                    if (lock != null && !lock.equals(e.getPlayer().getUniqueId().toString())) {
                        e.setCancelled(true);
                        e.getPlayer().sendMessage(ChatColor.RED + "This room is locked to another player's event.");
                        return;
                    }
                }
            }
        }
        // community chest: sell junk
        if (b.getType() == Material.CHEST && center != null
                && b.getX() == center.getBlockX() && b.getZ() == center.getBlockZ() + 4) {
            // handled on close would be better; quick: right click opens normally, hopper path sells via command
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKill(EntityDeathEvent e) {
        Player p = e.getEntity().getKiller();
        if (p == null) return;
        Session s = sessions.get(p.getUniqueId());
        if (s == null || !s.active || s.endsAtMs < System.currentTimeMillis()) return;
        if (!nearFarm(e.getEntity().getLocation())) return;
        // scale profession XP: hunter gets 30% via externalXp if we can cancel full - professions already awarded
        // Apply supplemental note: give reduced external? Actually professions plugin already gave full XP.
        // Best effort: claw back by negative external if supported, else document that farm kills should use scale.
        // We'll call a soft hook: try set scale on plugin if method exists; else apply reduced bonus only.
        double scale = getConfig().getDouble("profession-xp-scale", 0.30);
        // Try to notify professions with scaled amount as secondary path - hunter XP typically 1.0 per kill
        try {
            Plugin pl = Bukkit.getPluginManager().getPlugin("MAVOProfessions");
            if (pl != null) {
                Method m = pl.getClass().getMethod("externalXp", Player.class, String.class, double.class);
                // Give small scaled bonus only (main XP still from profession listener).
                // To approximate 30% total, subtract 70% if negative xp works:
                m.invoke(pl, p, "hunter", -0.70); // if externalXp ignores negative, no harm if we guard
            }
        } catch (Exception ignored) {}
        // mark: use metadata so professions can read - set on entity before death is too late
        // Store flag for professions via static-ish data file
        data.set("farmkill." + p.getUniqueId(), System.currentTimeMillis());
    }

    /** Public: true if player is in active farm session (for professions XP scale). */
    public boolean isFarmKill(Player p) {
        Session s = sessions.get(p.getUniqueId());
        return s != null && s.active && s.endsAtMs >= System.currentTimeMillis();
    }
    public double farmXpScale() { return getConfig().getDouble("profession-xp-scale", 0.30); }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        PendingEnter pe = pending.remove(e.getPlayer().getUniqueId());
        if (pe != null && pe.task != null) pe.task.cancel();
        // session persists for timer
    }

    /* community donate coins from hopper sales - admin or chest listener */
    public void addCommunityCoins(long amount, Player who) {
        if (amount <= 0) return;
        communityCoins += amount;
        while (communityCoins >= communityTarget) {
            communityCoins -= communityTarget;
            communityStack++;
            communityTarget = communityTarget * 2; // 1M, 2M, 4M...
            Bukkit.broadcastMessage(ChatColor.GOLD + "MobFarm community goal complete! Base spawners now "
                    + ChatColor.YELLOW + communityStack + ChatColor.GOLD + ". Next: " + communityTarget + " coins.");
        }
        saveData();
        if (who != null) who.sendMessage(ChatColor.GREEN + "Community farm fund +" + amount + " (" + communityCoins + "/" + communityTarget + ")");
    }
}
