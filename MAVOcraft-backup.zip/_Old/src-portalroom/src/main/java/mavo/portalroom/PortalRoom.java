package mavo.portalroom;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.generator.structure.Structure;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.BiomeSearchResult;
import org.bukkit.util.StructureSearchResult;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapCursor;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Sign;
import org.bukkit.block.sign.Side;
import org.bukkit.generator.structure.StructureType;
import org.bukkit.util.Vector;

import java.io.File;
import java.util.*;

/**
 * MAVOPortalRoom - 26 paid jump portals inside the Portal Room.
 * NORTH wall: 13 biome portals. SOUTH wall: 13 danger portals (structures/caves).
 * Frames are placed by the builder datapack (mavocraft:portal_frames); the regions
 * here are derived from the exact same geometry, so there is NO in-game setup.
 *
 * Every jump: random far coordinate (min..max distance from the room), never within
 * blacklist-radius of this portal's last blacklist-size landings. 7s countdown,
 * step-out cancels instantly, monsters block, creative = instant + free.
 * Balance is checked up front; coins are withdrawn ONLY after a successful jump.
 */
public final class PortalRoom extends JavaPlugin {

    // side|slot|id|kind|key|landing|ymin|ymax|price|r|g|b|colorcode|name|desc
    private static final String[] TABLE = {
        "N|0|desert|BIOME|desert|SURFACE|0|0|1000|237|201|95|e|Desert Dunes|Endless sands & temples",
        "N|1|savanna|BIOME|savanna|SURFACE|0|0|1200|214|120|54|6|Savanna Plains|Acacia flats & villages",
        "N|2|swamp|BIOME|swamp|SURFACE|0|0|1500|90|130|60|2|Murky Swamp|Slime, frogs & mystery",
        "N|3|darkforest|BIOME|dark_forest|SURFACE|0|0|2000|46|72|34|2|Dark Forest|Giant mushrooms, dark canopy",
        "N|4|taiga|BIOME|old_growth_pine_taiga|SURFACE|0|0|2500|112|78|44|6|Giant Taiga|Mega pines & podzol",
        "N|5|flower|BIOME|flower_forest|SURFACE|0|0|3000|150|210|70|a|Flower Fields|Every flower, every bee",
        "N|6|peaks|BIOME|jagged_peaks|SURFACE|0|0|3500|235|245|255|f|Jagged Peaks|Snowy summits & goats",
        "N|7|jungle|BIOME|jungle|SURFACE|0|0|4000|25|140|45|2|Deep Jungle|Vines, parrots, temples",
        "N|8|bamboo|BIOME|bamboo_jungle|SURFACE|0|0|4500|140|200|80|a|Bamboo Grove|Panda country",
        "N|9|ice|BIOME|ice_spikes|SURFACE|0|0|6000|150|215|255|b|Ice Spikes|Frozen spire fields",
        "N|10|cherry|BIOME|cherry_grove|SURFACE|0|0|7000|255|150|170|c|Cherry Blossom|Pink petals in the wind",
        "N|11|badlands|BIOME|badlands|SURFACE|0|0|8000|210|90|35|c|Badlands Mesa|Layered red canyons & gold",
        "N|12|mushroom|BIOME|mushroom_fields|SURFACE|0|0|10000|230|70|70|c|Mushroom Isle|Rarest land - no monsters ever",
        "S|0|shipwreck|STRUCTURE|shipwreck|STRUCTURE_NEAR|0|0|1500|70|130|220|9|Shipwreck Waters|Sunken loot + buried treasure map!",
        "S|1|mineshaft|STRUCTURE|mineshaft|MINESHAFT|-10|40|3000|150|110|60|6|Lost Mineshaft|Rails nearby - follow the signs!",
        "S|2|dripstone|BIOME|dripstone_caves|CAVE|-30|40|3500|170|120|85|6|Dripstone Caverns|Spikes above & below",
        "S|3|lush|BIOME|lush_caves|CAVE|-20|40|4000|95|180|95|a|Lush Caves|Glow berries & axolotls",
        "S|4|pyramid|STRUCTURE|desert_pyramid|SURFACE|0|0|4500|220|195|130|e|Desert Tomb|TNT trap & treasure below",
        "S|5|witchhut|STRUCTURE|swamp_hut|SURFACE|0|0|5000|80|100|60|2|Witch Hut|She is probably home...",
        "S|6|jungletemple|STRUCTURE|jungle_pyramid|SURFACE|0|0|5500|70|120|50|2|Jungle Temple|Dispenser traps & puzzles",
        "S|7|deepcaves|CAVE|-|CAVE|-55|-15|6000|70|80|100|7|Deep Caves|Pitch black at diamond level",
        "S|8|outpost|STRUCTURE|pillager_outpost|SURFACE|0|0|7000|90|100|110|7|Pillager Outpost|Crossbows everywhere",
        "S|9|monument|STRUCTURE|monument|SURFACE|0|0|9000|0|190|180|3|Ocean Monument|Guardians & gold - bring potions",
        "S|10|stronghold|STRUCTURE|stronghold|CAVE|-10|30|11000|170|170|180|7|Stronghold|Silverfish & the End awaits",
        "S|11|trial|STRUCTURE|trial_chambers|CAVE|-35|-5|13000|215|130|60|6|Trial Chambers|Wave combat - copper halls",
        "S|12|deepdark|STRUCTURE|ancient_city|CAVE|-58|-40|15000|0|160|180|3|THE DEEP DARK|Ancient City. Do NOT wake it."
    };

    static final class Portal {
        String id, kind, key, landing, name, desc;
        char color;
        boolean north;
        int slot, yMin, yMax;
        long price;
        Color dust;
        double minX, maxX, minZ, maxZ; // stand-in detection box (y 200..204)
        double holoX, holoY, holoZ;
        double fxZ;
    }

    private final List<Portal> portals = new ArrayList<>();
    private final Map<UUID, String> inPortal = new HashMap<>();
    private final Map<UUID, Integer> countdown = new HashMap<>();
    private final Map<String, Long> nagCooldown = new HashMap<>(); // uuid+portal -> last nag
    private final Random rng = new Random();
    private Economy econ;
    private File dataFile;
    private YamlConfiguration data;
    private NamespacedKey holoKey;
    private int fxTick = 0;

    // Room geometry (must match the builder datapack)
    private static final double ROOM_CX = -2400.5, ROOM_CZ = -1684.5;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        holoKey = new NamespacedKey(this, "jumpholo");
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider();
        for (String row : TABLE) portals.add(parse(row));
        Bukkit.getScheduler().runTaskLater(this, () -> { try { spawnAllHolos(); } catch (Throwable ex) {
            getLogger().warning("portalroom holos: " + ex.getMessage()); } }, 80L);
        Bukkit.getScheduler().runTaskTimer(this, () -> { try { fxLoop(); } catch (Throwable ex) {
            getLogger().warning("portalroom fxLoop: " + ex.getMessage()); } }, 40L, 2L);
        Bukkit.getScheduler().runTaskTimer(this, () -> { try { tickLoop(); } catch (Throwable ex) {
            getLogger().warning("portalroom tickLoop: " + ex.getMessage()); } }, 40L, 10L);
        getLogger().info("MAVOPortalRoom enabled - " + portals.size() + " jump portals (prices "
                + portals.stream().mapToLong(p -> p.price).min().orElse(0) + ".."
                + portals.stream().mapToLong(p -> p.price).max().orElse(0) + " coins).");
    }

    private Portal parse(String row) {
        String[] f = row.split("\\|");
        Portal p = new Portal();
        p.north = f[0].equals("N");
        p.slot = Integer.parseInt(f[1]);
        p.id = f[2]; p.kind = f[3]; p.key = f[4]; p.landing = f[5];
        p.yMin = Integer.parseInt(f[6]); p.yMax = Integer.parseInt(f[7]);
        p.price = Long.parseLong(f[8]);
        p.dust = Color.fromRGB(Integer.parseInt(f[9]), Integer.parseInt(f[10]), Integer.parseInt(f[11]));
        p.color = f[12].charAt(0);
        p.name = f[13]; p.desc = f[14];
        int L = -2446 + 7 * p.slot;
        p.minX = L + 1; p.maxX = L + 4;
        // stand-in zone: ~1.2 blocks deep in front of the frame (so browsing players don't trigger it)
        if (p.north) { p.minZ = -1698.0; p.maxZ = -1696.8; }
        else { p.minZ = -1672.2; p.maxZ = -1671.0; }
        p.holoX = L + 2.5; p.holoY = 205.9;
        return p;
    }

    private World world() { return Bukkit.getWorld(getConfig().getString("world", "world")); }

    /* ---------------- FX ---------------- */

    private void fxLoop() {
        fxTick += 2;
        World w = world();
        if (w == null) return;
        boolean near = false;
        for (Player pl : w.getPlayers())
            if (Math.abs(pl.getLocation().getX() - ROOM_CX) < 70 && Math.abs(pl.getLocation().getZ() - ROOM_CZ) < 40) { near = true; break; }
        if (!near) return;
        for (Portal p : portals) {
            if (fxTick % 4 != 0) continue;
            // just in front of the frame face, on the room side (north frame block spans z -1699..-1698,
            // south frame spans -1671..-1670 -> render at -1697.55 / -1671.45)
            double wallZ = p.north ? -1697.55 : -1671.45;
            for (int i = 0; i < 9; i++) {
                double px = p.minX + rng.nextDouble() * 3.0;
                double py = 200 + rng.nextDouble() * 4.0;
                w.spawnParticle(Particle.DUST, px, py, wallZ, 1, 0.03, 0.03, 0.02, 0,
                        new Particle.DustOptions(p.dust, 1.5f));
            }
            if (fxTick % 12 == 0)
                w.spawnParticle(Particle.END_ROD, p.minX + 1.5, 200.4 + rng.nextDouble() * 3.2, wallZ, 1, 0.25, 0.4, 0.02, 0.01);
        }
        if (fxTick % 160 == 0) {
            Location c = new Location(w, ROOM_CX, 202, ROOM_CZ);
            for (Player pl : w.getPlayers())
                if (pl.getLocation().distanceSquared(c) < 2500)
                    pl.playSound(pl.getLocation(), Sound.BLOCK_PORTAL_AMBIENT, 0.2f, 1.3f);
        }
    }

    /* ---------------- countdown + jump ---------------- */

    private void tickLoop() {
        World w = world();
        if (w == null) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getWorld() != w) { countdown.remove(p.getUniqueId()); continue; }
            Location l = p.getLocation();
            Portal in = null;
            if (Math.abs(l.getX() - ROOM_CX) < 60 && Math.abs(l.getZ() - ROOM_CZ) < 30 && l.getY() >= 199 && l.getY() <= 205)
                for (Portal pt : portals)
                    if (l.getX() >= pt.minX && l.getX() < pt.maxX && l.getZ() >= pt.minZ && l.getZ() < pt.maxZ) { in = pt; break; }
            UUID u = p.getUniqueId();
            if (in == null) {
                inPortal.remove(u);
                if (countdown.remove(u) != null) {
                    p.sendTitle(" ", "", 0, 1, 0); // step-out = instant cancel, no charge
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.6f);
                }
                continue;
            }
            inPortal.put(u, in.id);
            // creative admins: free, monsters ignored, but still a short 3s countdown
            // (instant-jump made browsing the room hazardous)
            if (p.getGameMode() == GameMode.CREATIVE) {
                int ct = countdown.merge(u, 10, Integer::sum);
                int cLeft = 3 - (ct / 20);
                if (ct % 20 == 0 && cLeft > 0) {
                    p.sendTitle(color(in) + "" + ChatColor.BOLD + in.name,
                            ChatColor.GRAY + "Creative jump in " + ChatColor.WHITE + cLeft + "s"
                                    + ChatColor.GRAY + " \u00B7 free \u00B7 step out to cancel", 0, 25, 5);
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1.2f);
                }
                if (ct >= 60) { countdown.remove(u); doJump(p, in, true); }
                continue;
            }
            long bal = econ == null ? 0 : (long) econ.getBalance(p);
            if (bal < in.price) {
                countdown.remove(u);
                String nk = u + ":" + in.id;
                long now = System.currentTimeMillis();
                Long last = nagCooldown.get(nk);
                if (last == null || now - last > 5000) {
                    nagCooldown.put(nk, now);
                    p.sendTitle(ChatColor.RED + "" + ChatColor.BOLD + "\u2716 Not enough coins",
                            ChatColor.GRAY + "Costs " + ChatColor.YELLOW + fmt(in.price) + " \u26C3"
                                    + ChatColor.GRAY + " - you have " + ChatColor.RED + fmt(bal) + " \u26C3", 0, 40, 10);
                    p.sendMessage(color(in) + in.name + ChatColor.RED + " costs " + ChatColor.YELLOW + fmt(in.price)
                            + " \u26C3" + ChatColor.RED + " - you only have " + fmt(bal) + " \u26C3.");
                    p.playSound(p.getLocation(), Sound.BLOCK_CHEST_LOCKED, 1f, 0.7f);
                }
                continue;
            }
            boolean danger = w.getNearbyEntities(l, 12, 12, 12).stream().anyMatch(en -> en instanceof Monster);
            if (danger) {
                countdown.remove(u);
                p.sendTitle(ChatColor.RED + "" + ChatColor.BOLD + "\u2716",
                        ChatColor.RED + "Monsters nearby - clear them first!", 0, 15, 5);
                continue;
            }
            int total = Math.max(3, getConfig().getInt("countdown-seconds", 7));
            int t = countdown.merge(u, 10, Integer::sum);
            int secLeft = total - (t / 20);
            if (t % 20 == 0 && secLeft > 0) {
                p.sendTitle(color(in) + "" + ChatColor.BOLD + in.name,
                        ChatColor.GRAY + "Jumping in " + ChatColor.WHITE + secLeft + "s"
                                + ChatColor.GRAY + " \u00B7 " + ChatColor.YELLOW + fmt(in.price) + " \u26C3"
                                + ChatColor.GRAY + " \u00B7 step out to cancel", 0, 25, 5);
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 0.8f + (total - secLeft) * 0.08f);
            }
            if (t >= total * 20) {
                countdown.remove(u);
                doJump(p, in, false);
            }
        }
    }

    private void doJump(Player p, Portal pt, boolean free) {
        World w = world();
        if (w == null) return;
        // final balance re-check (may have spent during countdown); charge AFTER success only
        if (!free && (econ == null || econ.getBalance(p) < pt.price)) {
            p.sendMessage(ChatColor.RED + "Not enough coins any more - jump cancelled, nothing charged.");
            return;
        }
        p.sendActionBar(net.kyori.adventure.text.Component.text("Locating your destination..."));
        Location dest = resolveDestination(pt);
        if (dest == null) {
            p.sendMessage(ChatColor.RED + "The portal fizzles... couldn't find a destination. Nothing charged, try again.");
            p.playSound(p.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 1f, 0.8f);
            return;
        }
        dest.setYaw(rng.nextFloat() * 360f);
        p.playSound(p.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 0.6f, 1.0f + rng.nextFloat() * 0.4f);
        p.teleport(dest);
        if (!free) econ.withdrawPlayer(p, pt.price);
        recordZone(pt, dest.getBlockX(), dest.getBlockZ());
        p.sendTitle(color(pt) + "" + ChatColor.BOLD + pt.name,
                ChatColor.GRAY + pt.desc, 5, 50, 15);
        p.sendMessage(color(pt) + "\u27A5 " + pt.name + ChatColor.GRAY + " - "
                + (free ? "free (creative)" : ChatColor.YELLOW + "-" + fmt(pt.price) + " \u26C3")
                + ChatColor.GRAY + " \u00B7 " + ChatColor.WHITE + dest.getBlockX() + " " + dest.getBlockY() + " " + dest.getBlockZ());
        p.sendMessage(ChatColor.GRAY + "No way back but the hard way - beds, /spawn or death. Good luck.");
        // Shipwreck / treasure: give a real buried-treasure explorer map that points the way
        if (pt.id.equals("shipwreck") || pt.id.equals("treasure") || pt.key.equals("buried_treasure")) {
            try {
                ItemStack map = makeBuriedTreasureMap(w, dest);
                if (map != null) {
                    var leftover = p.getInventory().addItem(map);
                    if (!leftover.isEmpty())
                        w.dropItemNaturally(dest, leftover.values().iterator().next());
                    p.sendMessage(ChatColor.AQUA + "\u25CE Buried Treasure Map " + ChatColor.GRAY
                            + "- white marker shows the dig site. Hold the map and walk toward it!");
                    p.playSound(dest, Sound.UI_CARTOGRAPHY_TABLE_TAKE_RESULT, 1f, 1.1f);
                }
            } catch (Throwable ex) {
                getLogger().warning("treasure map: " + ex.getMessage());
            }
        }
        p.playSound(dest, Sound.ENTITY_PLAYER_TELEPORT, 1f, 1f);
        w.spawnParticle(Particle.PORTAL, dest.clone().add(0, 1, 0), 60, 0.5, 1, 0.5, 0.5);
    }

    /* ---------------- destination resolution ---------------- */


    private Location resolveDestination(Portal pt) {
        World w = world();
        if (w == null) return null;
        long min = getConfig().getLong("min-distance", 25000);
        long max = getConfig().getLong("max-distance", 400000);
        int blR = getConfig().getInt("blacklist-radius", 100);
        List<String> zones = data.getStringList("zones." + pt.id);

        int X = 0, Z = 0;
        Location structureAt = null;

        // STRUCTURE: try several far origins until locate succeeds (old code often missed)
        if (pt.kind.equals("STRUCTURE")) {
            Structure st = resolveStructure(pt.key);
            if (st == null) {
                getLogger().warning("Unknown structure key: " + pt.key);
                return null;
            }
            int locateRadius = getConfig().getInt("structure-locate-radius", 6400);
            for (int attempt = 0; attempt < 12 && structureAt == null; attempt++) {
                int[] xz = randomFarXZ(min, max, blR, zones);
                X = xz[0]; Z = xz[1];
                Location origin = new Location(w, X, 64, Z);
                try {
                    StructureSearchResult r = w.locateNearestStructure(origin, st, locateRadius, true);
                    if (r == null) r = w.locateNearestStructure(origin, st, locateRadius, false);
                    if (r != null) {
                        structureAt = r.getLocation().clone();
                        X = structureAt.getBlockX();
                        Z = structureAt.getBlockZ();
                    }
                } catch (Throwable ex) {
                    getLogger().warning("locate " + pt.id + ": " + ex.getMessage());
                }
            }
            if (structureAt == null) return null;
        } else {
            int[] xz = randomFarXZ(min, max, blR, zones);
            X = xz[0]; Z = xz[1];
            Location origin = new Location(w, X, 100, Z);
            try {
                if (pt.kind.equals("BIOME")) {
                    org.bukkit.block.Biome biome = Registry.BIOME.get(NamespacedKey.minecraft(pt.key));
                    if (biome != null) {
                        int radius = pt.id.equals("mushroom") ? 12000 : 6400;
                        int step = pt.id.equals("mushroom") ? 256 : 128;
                        BiomeSearchResult r = w.locateNearestBiome(origin, radius, step, 64, biome);
                        if (r != null) { X = r.getLocation().getBlockX(); Z = r.getLocation().getBlockZ(); }
                        else if (!pt.landing.equals("SURFACE")) return null;
                    }
                }
            } catch (Throwable ex) {
                getLogger().warning("locate failed for " + pt.id + ": " + ex.getMessage());
            }
        }

        // ensure region loaded (3x3 chunks around target)
        for (int cx = (X >> 4) - 1; cx <= (X >> 4) + 1; cx++)
            for (int cz = (Z >> 4) - 1; cz <= (Z >> 4) + 1; cz++)
                w.getChunkAt(cx, cz).load(true);

        if (pt.landing.equals("STRUCTURE_NEAR") || pt.id.equals("shipwreck")) {
            return landAtShipwreck(w, X, Z);
        }
        if (pt.landing.equals("MINESHAFT") || pt.id.equals("mineshaft")) {
            return landAtMineshaft(w, X, Z, pt);
        }
        if (pt.landing.equals("SURFACE")) {
            // For ocean structures still using SURFACE, prefer water-surface safe spot near XZ
            if (pt.id.equals("monument") || pt.key.contains("monument")) {
                return landNearOceanStructure(w, X, Z);
            }
            int y = w.getHighestBlockYAt(X, Z);
            Block top = w.getBlockAt(X, y, Z);
            if (top.getType() == Material.LAVA) top.setType(Material.OBSIDIAN);
            // pyramid / outpost / hut: nudge onto solid structure blocks nearby
            Location snug = findNearbyStructureSurface(w, X, Z, 24);
            if (snug != null) return snug;
            return new Location(w, X + 0.5, y + 1, Z + 0.5);
        }

        // CAVE landing: prefer natural air, else platform WITH directional markers
        Location cave = findCaveAir(w, X, Z, pt.yMin, pt.yMax);
        if (cave != null) return cave;
        return carveMarkedPlatform(w, X, (pt.yMin + pt.yMax) / 2, Z, pt);
    }

    private int[] randomFarXZ(long min, long max, int blR, List<String> zones) {
        int X = 0, Z = 0;
        for (int i = 0; i < 80; i++) {
            double ang = rng.nextDouble() * Math.PI * 2;
            double dist = min + rng.nextDouble() * (max - min);
            X = (int) Math.round(ROOM_CX + Math.cos(ang) * dist);
            Z = (int) Math.round(ROOM_CZ + Math.sin(ang) * dist);
            boolean ok = true;
            for (String z : zones) {
                String[] s = z.split(",");
                if (s.length < 2) continue;
                long dx = X - Long.parseLong(s[0]), dz = Z - Long.parseLong(s[1]);
                if (dx * dx + dz * dz < (long) blR * blR * 4L) { ok = false; break; }
            }
            if (ok) break;
        }
        return new int[]{X, Z};
    }

    private Structure resolveStructure(String key) {
        Structure st = Registry.STRUCTURE.get(NamespacedKey.minecraft(key));
        if (st != null) return st;
        // aliases
        String[] alts = switch (key) {
            case "mineshaft" -> new String[]{"mineshaft", "mineshaft_all"};
            case "shipwreck" -> new String[]{"shipwreck", "shipwreck_beached"};
            case "monument" -> new String[]{"monument", "ocean_monument"};
            case "jungle_pyramid" -> new String[]{"jungle_pyramid", "jungle_temple"};
            case "desert_pyramid" -> new String[]{"desert_pyramid", "desert_temple"};
            case "buried_treasure" -> new String[]{"buried_treasure"};
            default -> new String[]{key};
        };
        for (String a : alts) {
            st = Registry.STRUCTURE.get(NamespacedKey.minecraft(a));
            if (st != null) return st;
        }
        return null;
    }

    /** Shipwreck: stand on/near the wreck in water, not a random inland surface. */
    private Location landAtShipwreck(World w, int sx, int sz) {
        // Scan for ship-like blocks around structure origin
        Material[] shipMats = {
                Material.OAK_PLANKS, Material.OAK_LOG, Material.OAK_FENCE, Material.OAK_SLAB,
                Material.DARK_OAK_PLANKS, Material.DARK_OAK_LOG, Material.DARK_OAK_FENCE,
                Material.SPRUCE_PLANKS, Material.SPRUCE_LOG, Material.SPRUCE_FENCE,
                Material.JUNGLE_PLANKS, Material.MANGROVE_PLANKS, Material.CHEST
        };
        int bestX = sx, bestY = -1, bestZ = sz;
        int r = 48;
        for (int dx = -r; dx <= r; dx += 2)
            for (int dz = -r; dz <= r; dz += 2)
                for (int y = 30; y <= 90; y++) {
                    Block b = w.getBlockAt(sx + dx, y, sz + dz);
                    Material m = b.getType();
                    boolean ship = false;
                    for (Material sm : shipMats) if (m == sm) { ship = true; break; }
                    if (!ship) continue;
                    // prefer a standable spot above this block
                    Block up1 = b.getRelative(BlockFace.UP);
                    Block up2 = up1.getRelative(BlockFace.UP);
                    if (up1.getType().isAir() || up1.isLiquid()) {
                        // water column ok - stand on ship deck or glass platform
                        if (bestY < 0 || Math.abs(y - 62) < Math.abs(bestY - 62)) {
                            bestX = b.getX(); bestY = y; bestZ = b.getZ();
                        }
                    }
                }

        if (bestY < 0) {
            // fallback: ocean surface near structure
            int y = w.getHighestBlockYAt(sx, sz);
            bestX = sx; bestY = Math.max(y, 62); bestZ = sz;
        }

        // Build a small dry platform if underwater so player doesn't drown instantly
        int px = bestX, py = bestY, pz = bestZ;
        boolean wet = w.getBlockAt(px, py + 1, pz).isLiquid() || w.getBlockAt(px, py + 1, pz).getType() == Material.WATER;
        if (wet || !w.getBlockAt(px, py, pz).getType().isSolid()) {
            // platform just under water surface near wreck
            int surface = 62;
            for (int y = 70; y >= 40; y--) {
                if (w.getBlockAt(px, y, pz).getType() == Material.WATER
                        && w.getBlockAt(px, y + 1, pz).getType() == Material.AIR) {
                    surface = y; break;
                }
            }
            py = surface;
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++) {
                    w.getBlockAt(px + dx, py, pz + dz).setType(Material.PRISMARINE_BRICKS, false);
                    w.getBlockAt(px + dx, py + 1, pz + dz).setType(Material.AIR, false);
                    w.getBlockAt(px + dx, py + 2, pz + dz).setType(Material.AIR, false);
                }
            w.getBlockAt(px, py + 1, pz).setType(Material.SEA_LANTERN, false);
            // sign pointing to wreck core
            placeGuideSign(w, px, py + 1, pz + 2, BlockFace.SOUTH,
                    ChatColor.AQUA + "SHIPWRECK",
                    ChatColor.WHITE + "Loot is near!",
                    ChatColor.GRAY + "Look for wood",
                    ChatColor.DARK_AQUA + "x" + sx + " z" + sz);
            placeGuideSign(w, px, py + 1, pz - 2, BlockFace.NORTH,
                    ChatColor.AQUA + "SHIPWRECK",
                    ChatColor.YELLOW + "Map in inventory",
                    ChatColor.GRAY + "Buried treasure",
                    ChatColor.GRAY + "marker = dig!");
            py = py + 1;
            return new Location(w, px + 0.5, py + 1, pz + 0.5);
        }
        // dry deck
        placeGuideSign(w, px, py + 1, pz + 1, BlockFace.SOUTH,
                ChatColor.AQUA + "SHIPWRECK",
                ChatColor.WHITE + "You're on it!",
                ChatColor.YELLOW + "Map = treasure",
                ChatColor.GRAY + "dig the X");
        return new Location(w, px + 0.5, py + 1, pz + 0.5);
    }

    /** Mineshaft: find rails/planks/fence, land next to them with arrow signs. */
    private Location landAtMineshaft(World w, int sx, int sz, Portal pt) {
        Material[] marks = {
                Material.RAIL, Material.POWERED_RAIL, Material.DETECTOR_RAIL, Material.ACTIVATOR_RAIL,
                Material.OAK_FENCE, Material.DARK_OAK_FENCE, Material.SPRUCE_FENCE,
                Material.OAK_PLANKS, Material.DARK_OAK_PLANKS, Material.COBWEB,
                Material.MINECART, Material.CHEST_MINECART, Material.TORCH, Material.WALL_TORCH
        };
        int yMin = Math.min(pt.yMin, -10), yMax = Math.max(pt.yMax, 48);
        int bestX = sx, bestY = -999, bestZ = sz;
        int r = 40;
        for (int dx = -r; dx <= r; dx += 2)
            for (int dz = -r; dz <= r; dz += 2)
                for (int y = yMax; y >= yMin; y--) {
                    Block b = w.getBlockAt(sx + dx, y, sz + dz);
                    Material m = b.getType();
                    boolean hit = false;
                    for (Material mm : marks) if (m == mm) { hit = true; break; }
                    if (!hit) continue;
                    // need air for player 2 blocks beside the mark
                    for (BlockFace f : new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
                        Block floor = b.getRelative(f).getRelative(BlockFace.DOWN);
                        Block feet = b.getRelative(f);
                        Block head = feet.getRelative(BlockFace.UP);
                        if (floor.getType().isSolid() && !floor.getType().name().contains("LAVA")
                                && (feet.getType().isAir() || feet.getType() == Material.CAVE_AIR)
                                && (head.getType().isAir() || head.getType() == Material.CAVE_AIR)) {
                            bestX = feet.getX(); bestY = feet.getY(); bestZ = feet.getZ();
                            // build marked platform + signs pointing at shaft mark
                            return finishMineshaftLanding(w, bestX, bestY, bestZ, b.getX(), b.getY(), b.getZ());
                        }
                    }
                    // remember mark even without perfect air
                    if (bestY < -500) { bestX = b.getX(); bestY = b.getY(); bestZ = b.getZ(); }
                }

        if (bestY < -500) {
            // no rails found - carve marked platform at structure origin
            int mid = (yMin + yMax) / 2;
            return carveMarkedPlatform(w, sx, mid, sz, pt);
        }
        // carve beside found mark
        return finishMineshaftLanding(w, bestX, Math.max(bestY, yMin), bestZ, bestX, bestY, bestZ);
    }

    private Location finishMineshaftLanding(World w, int lx, int ly, int lz, int mx, int my, int mz) {
        // clear 3x3x3 and floor with glowstone + sea lantern arrow
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++) {
                w.getBlockAt(lx + dx, ly - 1, lz + dz).setType(Material.GLOWSTONE, false);
                for (int dy = 0; dy <= 2; dy++) {
                    Block b = w.getBlockAt(lx + dx, ly + dy, lz + dz);
                    if (!b.getType().name().contains("CHEST")) b.setType(Material.AIR, false);
                }
            }
        w.getBlockAt(lx, ly - 1, lz).setType(Material.SEA_LANTERN, false);

        // Direction from landing to mineshaft mark
        int ddx = Integer.compare(mx, lx);
        int ddz = Integer.compare(mz, lz);
        BlockFace face = Math.abs(mx - lx) >= Math.abs(mz - lz)
                ? (ddx >= 0 ? BlockFace.EAST : BlockFace.WEST)
                : (ddz >= 0 ? BlockFace.SOUTH : BlockFace.NORTH);
        String arrow = switch (face) {
            case NORTH -> "↑ NORTH";
            case SOUTH -> "↓ SOUTH";
            case EAST -> "→ EAST";
            case WEST -> "← WEST";
            default -> "THIS WAY";
        };
        int dist = (int) Math.round(Math.sqrt((mx - lx) * 1.0 * (mx - lx) + (mz - lz) * 1.0 * (mz - lz) + (my - ly) * 1.0 * (my - ly)));
        String vert = my > ly + 2 ? "UP ↑" : (my < ly - 2 ? "DOWN ↓" : "same level");

        // signs on all 4 sides of platform
        placeGuideSign(w, lx, ly, lz + 2, BlockFace.SOUTH, ChatColor.GOLD + "MINESHAFT", ChatColor.YELLOW + arrow,
                ChatColor.WHITE + vert + " · " + dist + "m", ChatColor.GRAY + "rails/cobwebs");
        placeGuideSign(w, lx, ly, lz - 2, BlockFace.NORTH, ChatColor.GOLD + "MINESHAFT", ChatColor.YELLOW + arrow,
                ChatColor.WHITE + vert + " · " + dist + "m", ChatColor.GRAY + "follow rails");
        placeGuideSign(w, lx + 2, ly, lz, BlockFace.EAST, ChatColor.GOLD + "SHAFT", ChatColor.YELLOW + arrow,
                ChatColor.GRAY + "x" + mx + " y" + my, ChatColor.GRAY + "z" + mz);
        placeGuideSign(w, lx - 2, ly, lz, BlockFace.WEST, ChatColor.GOLD + "SHAFT", ChatColor.YELLOW + arrow,
                ChatColor.GRAY + "x" + mx + " y" + my, ChatColor.GRAY + "z" + mz);

        // torch path 6 blocks toward mark
        for (int i = 1; i <= 6; i++) {
            int tx = lx + ddx * i;
            int tz = lz + ddz * i;
            int ty = ly;
            Block floor = w.getBlockAt(tx, ty - 1, tz);
            if (!floor.getType().isSolid()) floor.setType(Material.COBBLESTONE, false);
            Block air = w.getBlockAt(tx, ty, tz);
            if (air.getType().isAir() || air.getType() == Material.CAVE_AIR)
                w.getBlockAt(tx, ty, tz).setType(Material.TORCH, false);
        }
        return new Location(w, lx + 0.5, ly, lz + 0.5);
    }

    private Location carveMarkedPlatform(World w, int X, int midY, int Z, Portal pt) {
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++) {
                w.getBlockAt(X + dx, midY - 1, Z + dz).setType(Material.GLOWSTONE, false);
                for (int dy = 0; dy <= 2; dy++) w.getBlockAt(X + dx, midY + dy, Z + dz).setType(Material.AIR, false);
            }
        w.getBlockAt(X, midY - 1, Z).setType(Material.SEA_LANTERN, false);
        placeGuideSign(w, X, midY, Z + 2, BlockFace.SOUTH,
                ChatColor.RED + pt.name,
                ChatColor.WHITE + "No shaft in range",
                ChatColor.GRAY + "Tunnel outward",
                ChatColor.DARK_GRAY + "y " + midY);
        placeGuideSign(w, X, midY, Z - 2, BlockFace.NORTH,
                ChatColor.YELLOW + "TIP",
                ChatColor.GRAY + "Listen for spiders",
                ChatColor.GRAY + "look for rails",
                ChatColor.GRAY + "cobwebs = close");
        // four torch tunnels
        for (BlockFace f : new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
            for (int i = 1; i <= 8; i++) {
                int tx = X + f.getModX() * i, tz = Z + f.getModZ() * i;
                w.getBlockAt(tx, midY - 1, tz).setType(Material.COBBLESTONE, false);
                w.getBlockAt(tx, midY, tz).setType(Material.AIR, false);
                w.getBlockAt(tx, midY + 1, tz).setType(Material.AIR, false);
                if (i % 2 == 0) w.getBlockAt(tx, midY, tz).setType(Material.TORCH, false);
            }
        }
        return new Location(w, X + 0.5, midY, Z + 0.5);
    }

    private Location findCaveAir(World w, int X, int Z, int yMin, int yMax) {
        for (int y = yMax; y >= yMin; y--) {
            Block floor = w.getBlockAt(X, y, Z);
            if (floor.getType().isSolid() && floor.getType() != Material.LAVA
                    && isAirish(w.getBlockAt(X, y + 1, Z))
                    && isAirish(w.getBlockAt(X, y + 2, Z)))
                return new Location(w, X + 0.5, y + 1, Z + 0.5);
        }
        return null;
    }

    private boolean isAirish(Block b) {
        Material m = b.getType();
        return m.isAir() || m == Material.CAVE_AIR || m == Material.VOID_AIR;
    }

    private Location findNearbyStructureSurface(World w, int X, int Z, int r) {
        for (int dx = -r; dx <= r; dx += 2)
            for (int dz = -r; dz <= r; dz += 2) {
                int x = X + dx, z = Z + dz;
                int y = w.getHighestBlockYAt(x, z);
                Block top = w.getBlockAt(x, y, z);
                String n = top.getType().name();
                if (n.contains("SANDSTONE") || n.contains("TERRACOTTA") || n.contains("COBBLE")
                        || n.contains("MOSSY") || n.contains("DARK_OAK") || n.contains("LOG")
                        || n.contains("PLANKS") || n.contains("STAIRS") || n.contains("BLACKSTONE")) {
                    return new Location(w, x + 0.5, y + 1, z + 0.5);
                }
            }
        return null;
    }

    private Location landNearOceanStructure(World w, int X, int Z) {
        int y = 62;
        for (int dx = -8; dx <= 8; dx++)
            for (int dz = -8; dz <= 8; dz++) {
                w.getBlockAt(X + dx, y, Z + dz).setType(Material.PRISMARINE_BRICKS, false);
                w.getBlockAt(X + dx, y + 1, Z + dz).setType(Material.AIR, false);
                w.getBlockAt(X + dx, y + 2, Z + dz).setType(Material.AIR, false);
            }
        w.getBlockAt(X, y + 1, Z).setType(Material.SEA_LANTERN, false);
        placeGuideSign(w, X, y + 1, Z + 3, BlockFace.SOUTH,
                ChatColor.DARK_AQUA + "MONUMENT",
                ChatColor.WHITE + "Underwater below",
                ChatColor.GRAY + "Bring potions!",
                ChatColor.DARK_GRAY + "x" + X + " z" + Z);
        return new Location(w, X + 0.5, y + 2, Z + 0.5);
    }

    private void placeGuideSign(World w, int x, int y, int z, BlockFace facing,
                                String l0, String l1, String l2, String l3) {
        Block b = w.getBlockAt(x, y, z);
        // standing sign if floor solid below, else wall on platform center offset already
        Block below = b.getRelative(BlockFace.DOWN);
        try {
            if (below.getType().isSolid()) {
                b.setType(Material.OAK_SIGN, false);
                org.bukkit.block.data.type.Sign sd = (org.bukkit.block.data.type.Sign) b.getBlockData();
                sd.setRotation(facing);
                b.setBlockData(sd, false);
            } else {
                b.setType(Material.OAK_WALL_SIGN, false);
                org.bukkit.block.data.type.WallSign ws = (org.bukkit.block.data.type.WallSign) b.getBlockData();
                ws.setFacing(facing);
                b.setBlockData(ws, false);
            }
            if (b.getState() instanceof Sign sign) {
                var side = sign.getSide(Side.FRONT);
                side.setLine(0, l0.length() > 16 ? l0.substring(0, 16) : l0);
                side.setLine(1, l1.length() > 16 ? l1.substring(0, 16) : l1);
                side.setLine(2, l2.length() > 16 ? l2.substring(0, 16) : l2);
                side.setLine(3, l3.length() > 16 ? l3.substring(0, 16) : l3);
                try { sign.setWaxed(true); } catch (Throwable ignored) {}
                sign.update(true, false);
            }
        } catch (Throwable ex) {
            getLogger().warning("sign place: " + ex.getMessage());
        }
    }

    /**
     * Real explorer map for buried treasure. Cursor points to dig site.
     * Uses Paper/Bukkit createExplorerMap with StructureType.BURIED_TREASURE.
     */
    private ItemStack makeBuriedTreasureMap(World w, Location near) {
        try {
            // Modern API: StructureType from generator.structure
            StructureType buried = Registry.STRUCTURE_TYPE.get(NamespacedKey.minecraft("buried_treasure"));
            ItemStack map;
            if (buried != null) {
                map = Bukkit.createExplorerMap(w, near, buried, MapCursor.Type.RED_X, 50, true);
            } else {
                // legacy StructureType
                @SuppressWarnings("deprecation")
                org.bukkit.StructureType legacy = org.bukkit.StructureType.BURIED_TREASURE;
                map = Bukkit.createExplorerMap(w, near, legacy, 50, true);
            }
            if (map != null && map.getItemMeta() instanceof MapMeta meta) {
                meta.setDisplayName(ChatColor.AQUA + "" + ChatColor.BOLD + "Buried Treasure Map");
                meta.setLore(List.of(
                        ChatColor.GRAY + "White/red marker = dig here",
                        ChatColor.GRAY + "Hold map - walk until X centers",
                        ChatColor.DARK_GRAY + "From the Shipwreck portal"
                ));
                map.setItemMeta(meta);
            }
            return map;
        } catch (Throwable ex) {
            getLogger().warning("createExplorerMap failed: " + ex.getMessage());
            // fallback: compass pointing roughly - still better than nothing
            try {
                Structure st = resolveStructure("buried_treasure");
                if (st != null) {
                    StructureSearchResult r = w.locateNearestStructure(near, st, 6400, true);
                    if (r != null) {
                        ItemStack compass = new ItemStack(Material.COMPASS);
                        var meta = compass.getItemMeta();
                        meta.setDisplayName(ChatColor.AQUA + "Treasure Compass");
                        meta.setLore(List.of(
                                ChatColor.GRAY + "Target ~ "
                                        + r.getLocation().getBlockX() + " " + r.getLocation().getBlockZ(),
                                ChatColor.YELLOW + "Dig under beach/ocean sand"
                        ));
                        compass.setItemMeta(meta);
                        // lodestone-less: use compass target if API allows
                        try {
                            if (meta instanceof org.bukkit.inventory.meta.CompassMeta cm) {
                                cm.setLodestone(r.getLocation());
                                cm.setLodestoneTracked(false);
                                compass.setItemMeta(cm);
                            }
                        } catch (Throwable ignored) {}
                        return compass;
                    }
                }
            } catch (Throwable ignored) {}
            return null;
        }
    }


    private void recordZone(Portal pt, int x, int z) {
        List<String> zones = new ArrayList<>(data.getStringList("zones." + pt.id));
        zones.add(x + "," + z);
        int keep = getConfig().getInt("blacklist-size", 50);
        while (zones.size() > keep) zones.remove(0);
        data.set("zones." + pt.id, zones);
        try { data.save(dataFile); } catch (Exception ignored) {}
    }

    /* ---------------- holos ---------------- */

    private void spawnAllHolos() {
        World w = world();
        if (w == null) return;
        for (Portal p : portals) {
            Location loc = new Location(w, p.holoX, p.holoY, p.north ? -1697.6 : -1672.4);
            loc.getChunk().load();
            NamespacedKey idKey = new NamespacedKey(this, "jumpholo_" + p.id);
            for (Entity ent : w.getNearbyEntities(loc, 3, 3, 3))
                if (ent instanceof TextDisplay && ent.getPersistentDataContainer().has(idKey, PersistentDataType.BYTE))
                    ent.remove();
            String text = ChatColor.COLOR_CHAR + "" + p.color + ChatColor.BOLD + p.name
                    + "\n" + ChatColor.GRAY + p.desc
                    + "\n" + ChatColor.YELLOW + fmt(p.price) + " \u26C3" + ChatColor.GRAY + " per jump";
            TextDisplay td = w.spawn(loc, TextDisplay.class, d -> {
                d.setText(text);
                d.setBillboard(Display.Billboard.CENTER);
                d.setShadowed(true);
                d.setSeeThrough(false);
                try { d.setDefaultBackground(false); d.setBackgroundColor(Color.fromARGB(190, 8, 8, 14)); } catch (Throwable ignored) {}
                d.setAlignment(TextDisplay.TextAlignment.CENTER);
                d.setLineWidth(200);
                var tr = d.getTransformation();
                tr.getScale().set(0.72f);
                d.setTransformation(tr);
                d.setViewRange(0.35f);
                try { d.setBrightness(new Display.Brightness(15, 15)); } catch (Throwable ignored) {}
                d.setPersistent(true);
                d.getPersistentDataContainer().set(holoKey, PersistentDataType.BYTE, (byte) 1);
                d.getPersistentDataContainer().set(idKey, PersistentDataType.BYTE, (byte) 1);
            });
        }
        getLogger().info("Spawned " + portals.size() + " jump-portal holograms.");
    }

    /* ---------------- command ---------------- */

    @Override
    public boolean onCommand(CommandSender s, Command c, String lb, String[] a) {
        String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> {
                s.sendMessage(ChatColor.GOLD + "== Portal Room jumps ==");
                for (Portal p : portals)
                    s.sendMessage(color(p) + p.id + ChatColor.GRAY + " (" + (p.north ? "N" : "S") + ") "
                            + p.name + " - " + ChatColor.YELLOW + fmt(p.price) + " \u26C3"
                            + ChatColor.GRAY + " - zones used: " + data.getStringList("zones." + p.id).size());
            }
            case "clearzones" -> {
                if (a.length < 2) { s.sendMessage(ChatColor.RED + "/portalroom clearzones <portalId|all>"); return true; }
                if (a[1].equalsIgnoreCase("all")) { data.set("zones", null); }
                else data.set("zones." + a[1].toLowerCase(Locale.ROOT), null);
                try { data.save(dataFile); } catch (Exception ignored) {}
                s.sendMessage(ChatColor.GREEN + "Zone blacklist cleared (" + a[1] + ").");
            }
            case "reload" -> {
                reloadConfig();
                spawnAllHolos();
                s.sendMessage(ChatColor.GREEN + "MAVOPortalRoom reloaded (holos respawned).");
            }
            default -> s.sendMessage(ChatColor.RED + "/portalroom <list|clearzones|reload>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String lb, String[] a) {
        if (!s.hasPermission("mavoportalroom.admin")) return List.of();
        if (a.length == 1) {
            List<String> out = new ArrayList<>();
            for (String x : List.of("list", "clearzones", "reload"))
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
            return out;
        }
        if (a.length == 2 && a[0].equalsIgnoreCase("clearzones")) {
            List<String> out = new ArrayList<>(portals.stream().map(p -> p.id).toList());
            out.add("all");
            return out;
        }
        return List.of();
    }

    /* ---------------- utils ---------------- */

    private String color(Portal p) { return ChatColor.COLOR_CHAR + "" + p.color; }

    private static String fmt(long v) {
        return String.format(Locale.US, "%,d", v);
    }
}
