package mavo.deathchest;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public final class DeathChest extends JavaPlugin implements Listener {

    private NamespacedKey ownerKey, expireKey;

    @Override
    public void onEnable() {
        ownerKey = new NamespacedKey(this, "dcowner");
        expireKey = new NamespacedKey(this, "dcexpire");
        getConfig().addDefault("expire-minutes", 30);
        getConfig().options().copyDefaults(true);
        saveConfig();
        getServer().getPluginManager().registerEvents(this, this);
        // expiry sweep every 30s over loaded chunks' tracked chests
        Bukkit.getScheduler().runTaskTimer(this, this::sweep, 600L, 600L);
        getLogger().info("MAVODeathChest enabled - your loot is safe(ish).");
    }

    private List<String> chests() { return getConfig().getStringList("chests"); }
    private void setChests(List<String> l) { getConfig().set("chests", l); saveConfig(); }

    private String key(Location l) { return l.getWorld().getName() + ";" + l.getBlockX() + ";" + l.getBlockY() + ";" + l.getBlockZ(); }

    private Location parse(String s) {
        String[] p = s.split(";");
        var w = Bukkit.getWorld(p[0]);
        if (w == null) return null;
        return new Location(w, Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]));
    }

    // ---------------- death ----------------
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent e) {
        if (e.getKeepInventory()) return;
        List<ItemStack> drops = new ArrayList<>(e.getDrops());
        drops.removeIf(i -> i == null || i.getType() == Material.AIR);
        if (drops.isEmpty()) return;

        Player p = e.getEntity();
        Location loc = p.getLocation().clone();
        if (loc.getBlockY() < loc.getWorld().getMinHeight() + 1) loc.setY(loc.getWorld().getMinHeight() + 1);
        if (loc.getBlockY() > loc.getWorld().getMaxHeight() - 2) loc.setY(loc.getWorld().getMaxHeight() - 2);
        Block b = findSpot(loc.getBlock());
        if (b == null) return; // no safe spot: vanilla drops

        b.setType(Material.CHEST);
        if (!(b.getState() instanceof Chest chest)) { b.setType(Material.AIR); return; }
        long expireAt = System.currentTimeMillis() + getConfig().getInt("expire-minutes", 30) * 60000L;
        chest.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, p.getUniqueId().toString());
        chest.getPersistentDataContainer().set(expireKey, PersistentDataType.LONG, expireAt);
        chest.setCustomName(ChatColor.RED + p.getName() + "'s grave");
        chest.update();

        Iterator<ItemStack> it = drops.iterator();
        int slot = 0;
        List<ItemStack> overflow = new ArrayList<>();
        while (it.hasNext()) {
            ItemStack s = it.next();
            if (slot < 27) chest.getBlockInventory().setItem(slot++, s);
            else overflow.add(s);
        }
        e.getDrops().clear();
        e.getDrops().addAll(overflow); // rare: >27 stacks, remainder drops normally

        List<String> l = new ArrayList<>(chests());
        l.add(key(b.getLocation()) + ";" + p.getUniqueId());
        setChests(l);

        String where = b.getX() + ", " + b.getY() + ", " + b.getZ();
        int mins = getConfig().getInt("expire-minutes", 30);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline())
                p.sendMessage(ChatColor.RED + "\u26B0 " + ChatColor.GOLD + "Your items are in a grave at "
                        + ChatColor.WHITE + where + ChatColor.GOLD + " (" + b.getWorld().getName() + ")"
                        + ChatColor.GRAY + " - only you can open it. It bursts open in " + mins + " min!");
        }, 20L);
    }

    private Block findSpot(Block start) {
        if (replaceable(start)) return start;
        for (int dy = 0; dy <= 3; dy++)
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++) {
                    Block b = start.getRelative(dx, dy, dz);
                    if (replaceable(b)) return b;
                }
        return null;
    }

    private boolean replaceable(Block b) {
        Material m = b.getType();
        return m.isAir() || m == Material.WATER || m == Material.LAVA || m == Material.SHORT_GRASS
                || m == Material.TALL_GRASS || m == Material.SNOW || m == Material.FERN;
    }

    // ---------------- protection ----------------
    private String ownerOf(Block b) {
        if (b.getType() != Material.CHEST || !(b.getState() instanceof Chest c)) return null;
        return c.getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onOpen(InventoryOpenEvent e) {
        if (!(e.getInventory().getHolder() instanceof Chest c)) return;
        String owner = c.getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        if (owner == null) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        if (!p.getUniqueId().toString().equals(owner) && !p.hasPermission("mavodc.admin")) {
            e.setCancelled(true);
            p.sendMessage(ChatColor.RED + "That grave isn't yours.");
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof Chest c)) return;
        if (!c.getPersistentDataContainer().has(ownerKey, PersistentDataType.STRING)) return;
        if (c.getBlockInventory().isEmpty()) {
            Location loc = c.getBlock().getLocation();
            c.getBlock().setType(Material.AIR);
            List<String> l = new ArrayList<>(chests());
            String pref = key(loc);
            l.removeIf(x -> x.startsWith(pref + ";") || x.equals(pref));
            setChests(l);
            if (e.getPlayer() instanceof Player p)
                p.playSound(loc, Sound.BLOCK_WOOD_BREAK, 1f, 0.8f);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onBreak(BlockBreakEvent e) {
        String owner = ownerOf(e.getBlock());
        if (owner == null) return;
        if (!e.getPlayer().getUniqueId().toString().equals(owner) && !e.getPlayer().hasPermission("mavodc.admin")) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(ChatColor.RED + "That grave isn't yours.");
            return;
        }
        // owner breaking: pop contents + remove from tracking
        List<String> l = new ArrayList<>(chests());
        String pref = key(e.getBlock().getLocation());
        l.removeIf(x -> x.startsWith(pref + ";") || x.equals(pref));
        setChests(l);
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent e) { e.blockList().removeIf(b -> ownerOf(b) != null); }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent e) { e.blockList().removeIf(b -> ownerOf(b) != null); }

    @EventHandler
    public void onHopper(InventoryMoveItemEvent e) {
        if (e.getSource().getHolder() instanceof Chest c
                && c.getPersistentDataContainer().has(ownerKey, PersistentDataType.STRING))
            e.setCancelled(true);
    }

    // ---------------- expiry ----------------
    private void sweep() {
        List<String> l = new ArrayList<>(chests());
        boolean changed = false;
        Iterator<String> it = l.iterator();
        while (it.hasNext()) {
            String s = it.next();
            Location loc = parse(s);
            if (loc == null) { it.remove(); changed = true; continue; }
            if (!loc.getWorld().isChunkLoaded(loc.getBlockX() >> 4, loc.getBlockZ() >> 4)) continue;
            Block b = loc.getBlock();
            if (b.getType() != Material.CHEST || !(b.getState() instanceof Chest c)
                    || !c.getPersistentDataContainer().has(ownerKey, PersistentDataType.STRING)) {
                it.remove(); changed = true; continue;
            }
            Long exp = c.getPersistentDataContainer().get(expireKey, PersistentDataType.LONG);
            if (exp != null && System.currentTimeMillis() > exp) {
                for (ItemStack item : c.getBlockInventory().getContents())
                    if (item != null && item.getType() != Material.AIR)
                        loc.getWorld().dropItemNaturally(loc.clone().add(0.5, 0.5, 0.5), item);
                b.setType(Material.AIR);
                it.remove(); changed = true;
            }
        }
        if (changed) setChests(l);
    }

    // ---------------- command ----------------
    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        UUID id = p.getUniqueId();
        int n = 0;
        for (String k : chests()) {
            Location loc = parse(k);
            if (loc == null) continue;
            if (loc.getWorld().isChunkLoaded(loc.getBlockX() >> 4, loc.getBlockZ() >> 4)) {
                Block b = loc.getBlock();
                String owner = ownerOf(b);
                if (owner == null || !owner.equals(id.toString())) continue;
                Chest ch = (Chest) b.getState();
                Long exp = ch.getPersistentDataContainer().get(expireKey, PersistentDataType.LONG);
                long left = exp == null ? 0 : Math.max(0, (exp - System.currentTimeMillis()) / 60000L);
                p.sendMessage(ChatColor.RED + "\u26B0 " + ChatColor.WHITE + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ()
                        + ChatColor.GRAY + " (" + loc.getWorld().getName() + ") - ~" + left + " min left");
                n++;
            } else {
                String[] parts = k.split(";");
                if (parts.length < 5 || !parts[4].equals(id.toString())) continue;
                p.sendMessage(ChatColor.RED + "\u26B0 " + ChatColor.WHITE + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ()
                        + ChatColor.GRAY + " (" + loc.getWorld().getName() + ", unloaded - timer paused)");
                n++;
            }
        }
        if (n == 0) p.sendMessage(ChatColor.GRAY + "No active graves. Stay alive!");
        return true;
    }
}
