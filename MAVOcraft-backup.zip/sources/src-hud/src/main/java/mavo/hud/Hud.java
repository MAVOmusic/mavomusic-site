package mavo.hud;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;

/**
 * MAVOHud 2.0 - provides %mavohud_...% placeholders for the TAB sidebar:
 *   %mavohud_day%    -> 14
 *   %mavohud_time%   -> icon + hh:mm  (sun/sunset/moon, moon = sleep!)
 *   %mavohud_coords% -> -2576 200 -1685
 * Optional action bar (off by default), /hud toggles it.
 */
public final class Hud extends JavaPlugin {

    private final Set<UUID> shown = new HashSet<>();
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        for (String s : data.getStringList("shown")) {
            try { shown.add(UUID.fromString(s)); } catch (Exception ignored) {}
        }
        int period = Math.max(10, getConfig().getInt("update-ticks", 20));
        new BukkitRunnable() {
            @Override public void run() { tick(); }
        }.runTaskTimer(this, 40L, period);
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new HudExpansion(this).register();
            getLogger().info("PlaceholderAPI expansion registered (%mavohud_day/time/coords%).");
        } else {
            getLogger().warning("PlaceholderAPI not found - sidebar placeholders unavailable.");
        }
        getLogger().info("MAVOHud enabled.");
    }

    @Override
    public void onDisable() { saveShown(); }

    private void saveShown() {
        data.set("shown", shown.stream().map(UUID::toString).toList());
        try { data.save(dataFile); } catch (Exception ignored) {}
    }

    private void tick() {
        for (Player p : getServer().getOnlinePlayers()) {
            if (!shown.contains(p.getUniqueId())) continue;
            p.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                    TextComponent.fromLegacy(coords(p) + ChatColor.DARK_GRAY + "  \u2503  "
                            + ChatColor.WHITE + "Day " + ChatColor.YELLOW + day(p)
                            + ChatColor.DARK_GRAY + "  \u2503  " + time(p)));
        }
    }

    // ---------------- the three values ----------------
    long day(Player p) { return p.getWorld().getFullTime() / 24000L + 1; }

    String time(Player p) {
        long t = p.getWorld().getTime();
        String icon; ChatColor pc;
        if (t >= 23460 || t < 450)      { icon = "\u2600"; pc = ChatColor.GOLD; }    // sunrise
        else if (t < 11616)             { icon = "\u2600"; pc = ChatColor.YELLOW; }  // day
        else if (t < 12542)             { icon = "\u26C5"; pc = ChatColor.GOLD; }    // sunset
        else                            { icon = "\u263D"; pc = ChatColor.RED; }     // night (beds work)
        long mins = (t * 60L / 1000L + 6L * 60L) % (24L * 60L);
        String clock = String.format("%02d:%02d", mins / 60, mins % 60);
        String sleep = (pc == ChatColor.RED) ? ChatColor.RED + " zZ" : "";
        return pc + icon + " " + ChatColor.WHITE + clock + sleep;
    }

    String coords(Player p) {
        Location l = p.getLocation();
        return ChatColor.AQUA + "" + l.getBlockX() + " " + l.getBlockY() + " " + l.getBlockZ();
    }

    // ---------------- /hud: toggle optional action bar ----------------
    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        UUID u = p.getUniqueId();
        if (shown.remove(u)) {
            p.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacy(""));
            p.sendMessage(ChatColor.YELLOW + "Action-bar HUD OFF. " + ChatColor.GRAY + "(sidebar still shows day/time/coords)");
        } else {
            shown.add(u);
            p.sendMessage(ChatColor.GREEN + "Action-bar HUD ON (extra line above the hotbar).");
        }
        saveShown();
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) { return List.of(); }

    // ---------------- PlaceholderAPI ----------------
    public static final class HudExpansion extends me.clip.placeholderapi.expansion.PlaceholderExpansion {
        private final Hud plugin;
        public HudExpansion(Hud plugin) { this.plugin = plugin; }
        @Override public @NotNull String getIdentifier() { return "mavohud"; }
        @Override public @NotNull String getAuthor() { return "MAVO"; }
        @Override public @NotNull String getVersion() { return "2.0.0"; }
        @Override public boolean persist() { return true; }
        @Override
        public String onPlaceholderRequest(Player p, @NotNull String params) {
            if (p == null) return "";
            switch (params.toLowerCase(java.util.Locale.ROOT)) {
                case "day": return String.valueOf(plugin.day(p));
                case "time": return plugin.time(p);
                case "coords": return plugin.coords(p);
                default: return null;
            }
        }
        @Override
        public String onRequest(OfflinePlayer op, @NotNull String params) {
            return op instanceof Player p ? onPlaceholderRequest(p, params) : "";
        }
    }
}
