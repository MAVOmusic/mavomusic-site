package mavo.portalroom;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.generator.structure.Structure;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.BiomeSearchResult;
import org.bukkit.util.StructureSearchResult;

import java.io.File;
import java.util.*;

/**
 * MAVOPortalRoom - 26 paid jump portals inside the Portal Room.
 * NORTH wall: 13 biome portals. SOUTH wall: 13 danger portals (structures/caves).
 * Frames are placed by the builder datapack (mavocraft:portal_frames); the regions
 * here are derived from the exact same geometry, so there is NO in-game setup.
 *
 * Every jump: random far coordinate (min..max distance from the room), never within
 * blacklist-radius of this portal's last blacklist-size landings. 7s countdown,
 * step-out cancels instantly, monsters block, creative = instant + free.
 * Balance is checked up front; coins are withdrawn ONLY after a successful jump.
 */
public final class PortalRoom extends JavaPlugin {

    // side|slot|id|kind|key|landing|ymin|ymax|price|r|g|b|colorcode|name|desc
    private static final String[] TABLE = {
        "N|0|desert|BIOME|desert|SURFACE|0|0|1000|237|201|95|e|Desert Dunes|Endless sands & temples",
        "N|1|savanna|BIOME|savanna|SURFACE|0|0|1200|214|120|54|6|Savanna Plains|Acacia flats & villages",
        "N|2|swamp|BIOME|swamp|SURFACE|0|0|1500|90|130|60|2|Murky Swamp|Slime, frogs & mystery",
        "N|3|darkforest|BIOME|dark_forest|SURFACE|0|0|2000|46|72|34|2|Dark Forest|Giant mushrooms, dark canopy",
        "N|4|taiga|BIOME|old_growth_pine_taiga|SURFACE|0|0|2500|112|78|44|6|Giant Taiga|Mega pines & podzol",
        "N|5|flower|BIOME|flower_forest|SURFACE|0|0|3000|150|210|70|a|Flower Fields|Every flower, every bee",
        "N|6|peaks|BIOME|jagged_peaks|SURFACE|0|0|3500|235|245|255|f|Jagged Peaks|Snowy summits & goats",
        "N|7|jungle|BIOME|jungle|SURFACE|0|0|4000|25|140|45|2|Deep Jungle|Vines, parrots, temples",
        "N|8|bamboo|BIOME|bamboo_jungle|SURFACE|0|0|4500|140|200|80|a|Bamboo Grove|Panda country",
        "N|9|ice|BIOME|ice_spikes|SURFACE|0|0|6000|150|215|255|b|Ice Spikes|Frozen spire fields",
        "N|10|cherry|BIOME|cherry_grove|SURFACE|0|0|7000|255|150|170|c|Cherry Blossom|Pink petals in the wind",
        "N|11|badlands|BIOME|badlands|SURFACE|0|0|8000|210|90|35|c|Badlands Mesa|Layered red canyons & gold",
        "N|12|mushroom|BIOME|mushroom_fields|SURFACE|0|0|10000|230|70|70|c|Mushroom Isle|Rarest land - no monsters ever",
        "S|0|shipwreck|STRUCTURE|shipwreck|SURFACE|0|0|1500|70|130|220|9|Shipwreck Waters|Sunken loot - bring air!",
        "S|1|mineshaft|STRUCTURE|mineshaft|CAVE|-10|40|3000|150|110|60|6|Lost Mineshaft|Rails, cobwebs, cave spiders",
        "S|2|dripstone|BIOME|dripstone_caves|CAVE|-30|40|3500|170|120|85|6|Dripstone Caverns|Spikes above & below",
        "S|3|lush|BIOME|lush_caves|CAVE|-20|40|4000|95|180|95|a|Lush Caves|Glow berries & axolotls",
        "S|4|pyramid|STRUCTURE|desert_pyramid|SURFACE|0|0|4500|220|195|130|e|Desert Tomb|TNT trap & treasure below",
        "S|5|witchhut|STRUCTURE|swamp_hut|SURFACE|0|0|5000|80|100|60|2|Witch Hut|She is probably home...",
        "S|6|jungletemple|STRUCTURE|jungle_pyramid|SURFACE|0|0|5500|70|120|50|2|Jungle Temple|Dispenser traps & puzzles",
        "S|7|deepcaves|CAVE|-|CAVE|-55|-15|6000|70|80|100|7|Deep Caves|Pitch black at diamond level",
        "S|8|outpost|STRUCTURE|pillager_outpost|SURFACE|0|0|7000|90|100|110|7|Pillager Outpost|Crossbows everywhere",
        "S|9|monument|STRUCTURE|monument|SURFACE|0|0|9000|0|190|180|3|Ocean Monument|Guardians & gold - bring potions",
        "S|10|stronghold|STRUCTURE|stronghold|CAVE|-10|30|11000|170|170|180|7|Stronghold|Silverfish & the End awaits",
        "S|11|trial|STRUCTURE|trial_chambers|CAVE|-35|-5|13000|215|130|60|6|Trial Chambers|Wave combat - copper halls",
        "S|12|deepdark|STRUCTURE|ancient_city|CAVE|-58|-40|15000|0|160|180|3|THE DEEP DARK|Ancient City. Do NOT wake it."
    };

    static final class Portal {
        String id, kind, key, landing, name, desc;
        char color;
        boolean north;
        int slot, yMin, yMax;
        long price;
        Color dust;
        double minX, maxX, minZ, maxZ; // stand-in detection box (y 200..204)
        double holoX, holoY, holoZ;
        double fxZ;
    }

    private final List<Portal> portals = new ArrayList<>();
    private final Map<UUID, String> inPortal = new HashMap<>();
    private final Map<UUID, Integer> countdown = new HashMap<>();
    private final Map<String, Long> nagCooldown = new HashMap<>(); // uuid+portal -> last nag
    private final Random rng = new Random();
    private Economy econ;
    private File dataFile;
    private YamlConfiguration data;
    private NamespacedKey holoKey;
    private int fxTick = 0;

    // Room geometry (must match the builder datapack)
    private static final double ROOM_CX = -2400.5, ROOM_CZ = -1684.5;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        holoKey = new NamespacedKey(this, "jumpholo");
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider();
        for (String row : TABLE) portals.add(parse(row));
        Bukkit.getScheduler().runTaskLater(this, this::spawnAllHolos, 80L);
        Bukkit.getScheduler().runTaskTimer(this, this::fxLoop, 40L, 2L);
        Bukkit.getScheduler().runTaskTimer(this, this::tickLoop, 40L, 10L);
        getLogger().info("MAVOPortalRoom enabled - " + portals.size() + " jump portals (prices "
                + portals.stream().mapToLong(p -> p.price).min().orElse(0) + ".."
                + portals.stream().mapToLong(p -> p.price).max().orElse(0) + " coins).");
    }

    private Portal parse(String row) {
        String[] f = row.split("\\|");
        Portal p = new Portal();
        p.north = f[0].equals("N");
        p.slot = Integer.parseInt(f[1]);
        p.id = f[2]; p.kind = f[3]; p.key = f[4]; p.landing = f[5];
        p.yMin = Integer.parseInt(f[6]); p.yMax = Integer.parseInt(f[7]);
        p.price = Long.parseLong(f[8]);
        p.dust = Color.fromRGB(Integer.parseInt(f[9]), Integer.parseInt(f[10]), Integer.parseInt(f[11]));
        p.color = f[12].charAt(0);
        p.name = f[13]; p.desc = f[14];
        int L = -2446 + 7 * p.slot;
        p.minX = L + 1; p.maxX = L + 4;
        // stand-in zone: ~1.2 blocks deep in front of the frame (so browsing players don't trigger it)
        if (p.north) { p.minZ = -1698.0; p.maxZ = -1696.8; }
        else { p.minZ = -1672.2; p.maxZ = -1671.0; }
        p.holoX = L + 2.5; p.holoY = 205.9;
        return p;
    }

    private World world() { return Bukkit.getWorld(getConfig().getString("world", "world")); }

    /* ---------------- FX ---------------- */

    private void fxLoop() {
        fxTick += 2;
        World w = world();
        if (w == null) return;
        boolean near = false;
        for (Player pl : w.getPlayers())
            if (Math.abs(pl.getLocation().getX() - ROOM_CX) < 70 && Math.abs(pl.getLocation().getZ() - ROOM_CZ) < 40) { near = true; break; }
        if (!near) return;
        for (Portal p : portals) {
            if (fxTick % 4 != 0) continue;
            // just in front of the frame face, on the room side (north frame block spans z -1699..-1698,
            // south frame spans -1671..-1670 -> render at -1697.55 / -1671.45)
            double wallZ = p.north ? -1697.55 : -1671.45;
            for (int i = 0; i < 9; i++) {
                double px = p.minX + rng.nextDouble() * 3.0;
                double py = 200 + rng.nextDouble() * 4.0;
                w.spawnParticle(Particle.DUST, px, py, wallZ, 1, 0.03, 0.03, 0.02, 0,
                        new Particle.DustOptions(p.dust, 1.5f));
            }
            if (fxTick % 12 == 0)
                w.spawnParticle(Particle.END_ROD, p.minX + 1.5, 200.4 + rng.nextDouble() * 3.2, wallZ, 1, 0.25, 0.4, 0.02, 0.01);
        }
        if (fxTick % 160 == 0) {
            Location c = new Location(w, ROOM_CX, 202, ROOM_CZ);
            for (Player pl : w.getPlayers())
                if (pl.getLocation().distanceSquared(c) < 2500)
                    pl.playSound(pl.getLocation(), Sound.BLOCK_PORTAL_AMBIENT, 0.2f, 1.3f);
        }
    }

    /* ---------------- countdown + jump ---------------- */

    private void tickLoop() {
        World w = world();
        if (w == null) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getWorld() != w) { countdown.remove(p.getUniqueId()); continue; }
            Location l = p.getLocation();
            Portal in = null;
            if (Math.abs(l.getX() - ROOM_CX) < 60 && Math.abs(l.getZ() - ROOM_CZ) < 30 && l.getY() >= 199 && l.getY() <= 205)
                for (Portal pt : portals)
                    if (l.getX() >= pt.minX && l.getX() < pt.maxX && l.getZ() >= pt.minZ && l.getZ() < pt.maxZ) { in = pt; break; }
            UUID u = p.getUniqueId();
            if (in == null) {
                inPortal.remove(u);
                if (countdown.remove(u) != null) {
                    p.sendTitle(" ", "", 0, 1, 0); // step-out = instant cancel, no charge
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.6f);
                }
                continue;
            }
            inPortal.put(u, in.id);
            // creative admins: free, monsters ignored, but still a short 3s countdown
            // (instant-jump made browsing the room hazardous)
            if (p.getGameMode() == GameMode.CREATIVE) {
                int ct = countdown.merge(u, 10, Integer::sum);
                int cLeft = 3 - (ct / 20);
                if (ct % 20 == 0 && cLeft > 0) {
                    p.sendTitle(color(in) + "" + ChatColor.BOLD + in.name,
                            ChatColor.GRAY + "Creative jump in " + ChatColor.WHITE + cLeft + "s"
                                    + ChatColor.GRAY + " \u00B7 free \u00B7 step out to cancel", 0, 25, 5);
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1.2f);
                }
                if (ct >= 60) { countdown.remove(u); doJump(p, in, true); }
                continue;
            }
            long bal = econ == null ? 0 : (long) econ.getBalance(p);
            if (bal < in.price) {
                countdown.remove(u);
                String nk = u + ":" + in.id;
                long now = System.currentTimeMillis();
                Long last = nagCooldown.get(nk);
                if (last == null || now - last > 5000) {
                    nagCooldown.put(nk, now);
                    p.sendTitle(ChatColor.RED + "" + ChatColor.BOLD + "\u2716 Not enough coins",
                            ChatColor.GRAY + "Costs " + ChatColor.YELLOW + fmt(in.price) + " \u26C3"
                                    + ChatColor.GRAY + " - you have " + ChatColor.RED + fmt(bal) + " \u26C3", 0, 40, 10);
                    p.sendMessage(color(in) + in.name + ChatColor.RED + " costs " + ChatColor.YELLOW + fmt(in.price)
                            + " \u26C3" + ChatColor.RED + " - you only have " + fmt(bal) + " \u26C3.");
                    p.playSound(p.getLocation(), Sound.BLOCK_CHEST_LOCKED, 1f, 0.7f);
                }
                continue;
            }
            boolean danger = w.getNearbyEntities(l, 12, 12, 12).stream().anyMatch(en -> en instanceof Monster);
            if (danger) {
                countdown.remove(u);
                p.sendTitle(ChatColor.RED + "" + ChatColor.BOLD + "\u2716",
                        ChatColor.RED + "Monsters nearby - clear them first!", 0, 15, 5);
                continue;
            }
            int total = Math.max(3, getConfig().getInt("countdown-seconds", 7));
            int t = countdown.merge(u, 10, Integer::sum);
            int secLeft = total - (t / 20);
            if (t % 20 == 0 && secLeft > 0) {
                p.sendTitle(color(in) + "" + ChatColor.BOLD + in.name,
                        ChatColor.GRAY + "Jumping in " + ChatColor.WHITE + secLeft + "s"
                                + ChatColor.GRAY + " \u00B7 " + ChatColor.YELLOW + fmt(in.price) + " \u26C3"
                                + ChatColor.GRAY + " \u00B7 step out to cancel", 0, 25, 5);
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 0.8f + (total - secLeft) * 0.08f);
            }
            if (t >= total * 20) {
                countdown.remove(u);
                doJump(p, in, false);
            }
        }
    }

    private void doJump(Player p, Portal pt, boolean free) {
        World w = world();
        if (w == null) return;
        // final balance re-check (may have spent during countdown); charge AFTER success only
        if (!free && (econ == null || econ.getBalance(p) < pt.price)) {
            p.sendMessage(ChatColor.RED + "Not enough coins any more - jump cancelled, nothing charged.");
            return;
        }
        p.sendActionBar(net.kyori.adventure.text.Component.text("Locating your destination..."));
        Location dest = resolveDestination(pt);
        if (dest == null) {
            p.sendMessage(ChatColor.RED + "The portal fizzles... couldn't find a destination. Nothing charged, try again.");
            p.playSound(p.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 1f, 0.8f);
            return;
        }
        dest.setYaw(rng.nextFloat() * 360f);
        p.playSound(p.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 0.6f, 1.0f + rng.nextFloat() * 0.4f);
        p.teleport(dest);
        if (!free) econ.withdrawPlayer(p, pt.price);
        recordZone(pt, dest.getBlockX(), dest.getBlockZ());
        p.sendTitle(color(pt) + "" + ChatColor.BOLD + pt.name,
                ChatColor.GRAY + pt.desc, 5, 50, 15);
        p.sendMessage(color(pt) + "\u27A5 " + pt.name + ChatColor.GRAY + " - "
                + (free ? "free (creative)" : ChatColor.YELLOW + "-" + fmt(pt.price) + " \u26C3")
                + ChatColor.GRAY + " \u00B7 fresh zone at " + ChatColor.WHITE + dest.getBlockX() + " " + dest.getBlockY() + " " + dest.getBlockZ());
        p.sendMessage(ChatColor.GRAY + "No way back but the hard way - beds, /spawn or death. Good luck.");
        p.playSound(dest, Sound.ENTITY_PLAYER_TELEPORT, 1f, 1f);
        w.spawnParticle(Particle.PORTAL, dest.clone().add(0, 1, 0), 60, 0.5, 1, 0.5, 0.5);
    }

    /* ---------------- destination resolution ---------------- */

    private Location resolveDestination(Portal pt) {
        World w = world();
        long min = getConfig().getLong("min-distance", 25000);
        long max = getConfig().getLong("max-distance", 400000);
        int blR = getConfig().getInt("blacklist-radius", 100);
        List<String> zones = data.getStringList("zones." + pt.id);
        int X = 0, Z = 0; boolean ok = false;
        for (int i = 0; i < 60 && !ok; i++) {
            double ang = rng.nextDouble() * Math.PI * 2;
            double dist = min + rng.nextDouble() * (max - min);
            X = (int) Math.round(ROOM_CX + Math.cos(ang) * dist);
            Z = (int) Math.round(ROOM_CZ + Math.sin(ang) * dist);
            ok = true;
            for (String z : zones) {
                String[] s = z.split(",");
                long dx = X - Long.parseLong(s[0]), dz = Z - Long.parseLong(s[1]);
                if (dx * dx + dz * dz < (long) blR * blR * 4) { ok = false; break; } // 2x radius safety between zone centers
            }
        }
        Location origin = new Location(w, X, 100, Z);
        // refine toward the actual biome / structure
        try {
            if (pt.kind.equals("BIOME")) {
                org.bukkit.block.Biome biome = Registry.BIOME.get(NamespacedKey.minecraft(pt.key));
                if (biome != null) {
                    int radius = pt.id.equals("mushroom") ? 12000 : 6400;
                    int step = pt.id.equals("mushroom") ? 256 : 128;
                    BiomeSearchResult r = w.locateNearestBiome(origin, radius, step, 64, biome);
                    if (r != null) { X = r.getLocation().getBlockX(); Z = r.getLocation().getBlockZ(); }
                    else if (!pt.landing.equals("SURFACE")) return null; // cave biomes need the real biome
                }
            } else if (pt.kind.equals("STRUCTURE")) {
                Structure st = Registry.STRUCTURE.get(NamespacedKey.minecraft(pt.key));
                if (st != null) {
                    StructureSearchResult r = w.locateNearestStructure(origin, st, 5000, true);
                    if (r == null) r = w.locateNearestStructure(origin, st, 5000, false);
                    if (r == null) return null;
                    X = r.getLocation().getBlockX(); Z = r.getLocation().getBlockZ();
                }
            }
        } catch (Throwable t) {
            getLogger().warning("locate failed for " + pt.id + ": " + t.getMessage());
        }
        // load the chunk and pick a safe Y
        w.getChunkAt(X >> 4, Z >> 4).load(true);
        if (pt.landing.equals("SURFACE")) {
            int y = w.getHighestBlockYAt(X, Z);
            Block top = w.getBlockAt(X, y, Z);
            if (top.getType() == Material.LAVA) { top.setType(Material.OBSIDIAN); }
            return new Location(w, X + 0.5, y + 1, Z + 0.5);
        }
        // CAVE landing: scan for a natural air pocket in the y range
        for (int y = pt.yMax; y >= pt.yMin; y--) {
            Block floor = w.getBlockAt(X, y, Z);
            if (floor.getType().isSolid() && floor.getType() != Material.LAVA
                    && w.getBlockAt(X, y + 1, Z).getType() == Material.AIR
                    && w.getBlockAt(X, y + 2, Z).getType() == Material.AIR)
                return new Location(w, X + 0.5, y + 1, Z + 0.5);
        }
        // none found: carve a small landing pocket
        int midY = (pt.yMin + pt.yMax) / 2;
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++) {
                w.getBlockAt(X + dx, midY - 1, Z + dz).setType(Material.GLOWSTONE);
                for (int dy = 0; dy <= 2; dy++) w.getBlockAt(X + dx, midY + dy, Z + dz).setType(Material.AIR);
            }
        return new Location(w, X + 0.5, midY, Z + 0.5);
    }

    private void recordZone(Portal pt, int x, int z) {
        List<String> zones = new ArrayList<>(data.getStringList("zones." + pt.id));
        zones.add(x + "," + z);
        int keep = getConfig().getInt("blacklist-size", 50);
        while (zones.size() > keep) zones.remove(0);
        data.set("zones." + pt.id, zones);
        try { data.save(dataFile); } catch (Exception ignored) {}
    }

    /* ---------------- holos ---------------- */

    private void spawnAllHolos() {
        World w = world();
        if (w == null) return;
        for (Portal p : portals) {
            Location loc = new Location(w, p.holoX, p.holoY, p.north ? -1697.6 : -1672.4);
            loc.getChunk().load();
            NamespacedKey idKey = new NamespacedKey(this, "jumpholo_" + p.id);
            for (Entity ent : w.getNearbyEntities(loc, 3, 3, 3))
                if (ent instanceof TextDisplay && ent.getPersistentDataContainer().has(idKey, PersistentDataType.BYTE))
                    ent.remove();
            String text = ChatColor.COLOR_CHAR + "" + p.color + ChatColor.BOLD + p.name
                    + "\n" + ChatColor.GRAY + p.desc
                    + "\n" + ChatColor.YELLOW + fmt(p.price) + " \u26C3" + ChatColor.GRAY + " per jump";
            TextDisplay td = w.spawn(loc, TextDisplay.class, d -> {
                d.setText(text);
                d.setBillboard(Display.Billboard.CENTER);
                d.setShadowed(true);
                d.setSeeThrough(false);
                try { d.setDefaultBackground(false); d.setBackgroundColor(Color.fromARGB(190, 8, 8, 14)); } catch (Throwable ignored) {}
                d.setAlignment(TextDisplay.TextAlignment.CENTER);
                d.setLineWidth(200);
                var tr = d.getTransformation();
                tr.getScale().set(0.72f);
                d.setTransformation(tr);
                d.setViewRange(0.35f);
                try { d.setBrightness(new Display.Brightness(15, 15)); } catch (Throwable ignored) {}
                d.setPersistent(true);
                d.getPersistentDataContainer().set(holoKey, PersistentDataType.BYTE, (byte) 1);
                d.getPersistentDataContainer().set(idKey, PersistentDataType.BYTE, (byte) 1);
            });
        }
        getLogger().info("Spawned " + portals.size() + " jump-portal holograms.");
    }

    /* ---------------- command ---------------- */

    @Override
    public boolean onCommand(CommandSender s, Command c, String lb, String[] a) {
        String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> {
                s.sendMessage(ChatColor.GOLD + "== Portal Room jumps ==");
                for (Portal p : portals)
                    s.sendMessage(color(p) + p.id + ChatColor.GRAY + " (" + (p.north ? "N" : "S") + ") "
                            + p.name + " - " + ChatColor.YELLOW + fmt(p.price) + " \u26C3"
                            + ChatColor.GRAY + " - zones used: " + data.getStringList("zones." + p.id).size());
            }
            case "clearzones" -> {
                if (a.length < 2) { s.sendMessage(ChatColor.RED + "/portalroom clearzones <portalId|all>"); return true; }
                if (a[1].equalsIgnoreCase("all")) { data.set("zones", null); }
                else data.set("zones." + a[1].toLowerCase(Locale.ROOT), null);
                try { data.save(dataFile); } catch (Exception ignored) {}
                s.sendMessage(ChatColor.GREEN + "Zone blacklist cleared (" + a[1] + ").");
            }
            case "reload" -> {
                reloadConfig();
                spawnAllHolos();
                s.sendMessage(ChatColor.GREEN + "MAVOPortalRoom reloaded (holos respawned).");
            }
            default -> s.sendMessage(ChatColor.RED + "/portalroom <list|clearzones|reload>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String lb, String[] a) {
        if (!s.hasPermission("mavoportalroom.admin")) return List.of();
        if (a.length == 1) {
            List<String> out = new ArrayList<>();
            for (String x : List.of("list", "clearzones", "reload"))
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
            return out;
        }
        if (a.length == 2 && a[0].equalsIgnoreCase("clearzones")) {
            List<String> out = new ArrayList<>(portals.stream().map(p -> p.id).toList());
            out.add("all");
            return out;
        }
        return List.of();
    }

    /* ---------------- utils ---------------- */

    private String color(Portal p) { return ChatColor.COLOR_CHAR + "" + p.color; }

    private static String fmt(long v) {
        return String.format(Locale.US, "%,d", v);
    }
}
