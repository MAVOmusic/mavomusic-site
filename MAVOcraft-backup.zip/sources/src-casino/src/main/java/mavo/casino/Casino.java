package mavo.casino;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

/**
 * MAVOCasino - Lucky Louie's gambling den.
 * 5 games, coins or Lucky Coins, 10 attempts per 10 MC days.
 * House edge ~4-8% on every game: fun, not a money printer.
 */
public final class Casino extends JavaPlugin implements Listener {

    private Economy econ;
    private final Random rng = new Random();
    private NamespacedKey luckyKey;     // mavoluckycoins:luckycoin - genuine coin tag
    private NamespacedKey profToolKey, profOwnerKey; // mavoprofessions tool tags (gambler stick)
    private File dataFile;
    private YamlConfiguration data;

    private static final int[] COIN_BETS = {100, 250, 500, 1000, 2500, 5000};
    private static final int[] LUCKY_BETS = {1, 2, 3, 5, 10};

    // ---- Gambler profession lucky sticks: material -> win-luck bonus ----
    // Must match the tier tools in MAVOProfessions config (gambler profession).
    private static final Material[] STICK_MATS = {Material.STICK, Material.BAMBOO, Material.BONE,
            Material.SUGAR_CANE, Material.POINTED_DRIPSTONE, Material.BREEZE_ROD,
            Material.END_ROD, Material.LIGHTNING_ROD, Material.BLAZE_ROD};
    private static final double[] STICK_LUCK = {0.01, 0.02, 0.035, 0.05, 0.065, 0.08, 0.10, 0.12, 0.15};
    private static final double[] MINE_MULT = {1.2, 1.6, 2.2, 3.4, 5.5, 11, 32}; // after k safe reveals
    private static final double[] WHEEL_MULT = {0, 0.5, 1, 2, 3, 10};
    private static final int[] WHEEL_WEIGHT = {34, 25, 15, 16, 9, 1};
    private static final Material[] WHEEL_ICON = {Material.BARRIER, Material.COAL, Material.IRON_INGOT,
            Material.GOLD_INGOT, Material.EMERALD, Material.NETHER_STAR};

    private static final class Holder implements InventoryHolder {
        String view = "main";           // main | cups | flip | dice | wheel | mines
        boolean lucky = false;          // currency
        int betIdx = 0;
        long bet = 0;                   // active game's locked bet
        double luck = 0;                // gambler stick luck bonus locked in at bet time
        boolean busy = false;           // animation running
        boolean settled = true;         // game finished/paid (mines: false while running)
        // mines state
        boolean[] tnt = new boolean[9];
        int revealed = 0;
        Inventory inv;
        @Override public @NotNull Inventory getInventory() { return inv; }
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        luckyKey = new NamespacedKey("mavoluckycoins", "luckycoin");
        profToolKey = new NamespacedKey("mavoprofessions", "proftool");
        profOwnerKey = new NamespacedKey("mavoprofessions", "profowner");
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("MAVOCasino enabled - the house always wins (about 95% of the time).");
    }

    @Override
    public void onDisable() { save(); }

    private void save() { try { data.save(dataFile); } catch (Exception ignored) {} }

    /* ---------------- attempts: 10 per 10 MC days ---------------- */

    private long currentDay() { return Bukkit.getWorlds().get(0).getFullTime() / 24000L; }

    private int attemptsLeft(UUID u) {
        long day = currentDay();
        long start = data.getLong("players." + u + ".window", -100);
        int perWindow = getConfig().getInt("attempts", 10);
        int windowDays = getConfig().getInt("window-days", 10);
        if (day - start >= windowDays || start > day) {
            data.set("players." + u + ".window", day);
            data.set("players." + u + ".left", perWindow);
            return perWindow;
        }
        return data.getInt("players." + u + ".left", perWindow);
    }

    private void useAttempt(UUID u) {
        data.set("players." + u + ".left", Math.max(0, attemptsLeft(u) - 1));
        save();
    }

    private long nextRefillIn(UUID u) {
        long start = data.getLong("players." + u + ".window", currentDay());
        return Math.max(0, getConfig().getInt("window-days", 10) - (currentDay() - start));
    }

    /* ---------------- money helpers ---------------- */

    private ItemStack makeLucky(int amount) {
        ItemStack it = new ItemStack(Material.SUNFLOWER, amount);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&e&l\u26C0 Lucky Coin"));
        m.setLore(java.util.Arrays.asList(
                ChatColor.GRAY + "Toss it into the " + ChatColor.AQUA + "Wishing Well" + ChatColor.GRAY + " at spawn",
                ChatColor.GRAY + "to trade it for... something.",
                ChatColor.DARK_GRAY + "MAVOcraft fortune token"));
        m.addEnchant(Enchantment.UNBREAKING, 1, true);
        m.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);
        m.getPersistentDataContainer().set(luckyKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    private boolean isLucky(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(luckyKey, PersistentDataType.BYTE);
    }

    private int countLucky(Player p) {
        int n = 0;
        for (ItemStack it : p.getInventory().getContents()) if (isLucky(it)) n += it.getAmount();
        return n;
    }

    private boolean takeLucky(Player p, int n) {
        if (countLucky(p) < n) return false;
        ItemStack[] inv = p.getInventory().getContents();
        for (int i = 0; i < inv.length && n > 0; i++) {
            if (!isLucky(inv[i])) continue;
            int take = Math.min(n, inv[i].getAmount());
            inv[i].setAmount(inv[i].getAmount() - take);
            n -= take;
        }
        return true;
    }

    private void giveLucky(Player p, int n) {
        while (n > 0) {
            int stack = Math.min(64, n);
            var left = p.getInventory().addItem(makeLucky(stack));
            for (ItemStack drop : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), drop);
            n -= stack;
        }
    }

    private boolean chargeBet(Player p, Holder h) {
        long bet = h.lucky ? LUCKY_BETS[h.betIdx] : COIN_BETS[h.betIdx];
        if (h.lucky) {
            if (!takeLucky(p, (int) bet)) {
                p.sendMessage(ChatColor.RED + "You need " + bet + " \u26C0 Lucky Coins in your inventory!");
                return false;
            }
        } else {
            if (econ == null || econ.getBalance(p) < bet) {
                p.sendMessage(ChatColor.RED + "You need \u26C3 " + bet + " coins!");
                return false;
            }
            econ.withdrawPlayer(p, bet);
        }
        h.bet = bet;
        // gambler stick: lock in luck + award profession XP for the wager
        double luck = stickLuck(p);
        h.luck = Math.max(0, luck);
        if (luck >= 0) profXp(p, h.lucky ? bet * 5.0 : bet / 100.0);
        // achievements: coins/lucky coins wagered
        achProgress(p, h.lucky ? "luckybets" : "betting", bet);
        return true;
    }

    /* ---------------- gambler profession bridge (MAVOProfessions) ---------------- */

    /** Luck bonus of the gambler stick the player is holding; -1 if none held. */
    private double stickLuck(Player p) {
        double best = -1;
        ItemStack[] hands = {p.getInventory().getItemInMainHand(), p.getInventory().getItemInOffHand()};
        for (ItemStack it : hands) {
            if (it == null || !it.hasItemMeta()) continue;
            var pdc = it.getItemMeta().getPersistentDataContainer();
            String t = pdc.get(profToolKey, PersistentDataType.STRING);
            String o = pdc.get(profOwnerKey, PersistentDataType.STRING);
            if (t == null || !t.startsWith("gambler:")) continue;
            if (!p.getUniqueId().toString().equals(o)) continue;
            for (int i = 0; i < STICK_MATS.length; i++)
                if (STICK_MATS[i] == it.getType()) best = Math.max(best, STICK_LUCK[i]);
        }
        return best;
    }

    private void profXp(Player p, double amount) {
        org.bukkit.plugin.Plugin pl = Bukkit.getPluginManager().getPlugin("MAVOProfessions");
        if (pl == null || !pl.isEnabled()) return;
        try {
            pl.getClass().getMethod("externalXp", Player.class, String.class, double.class)
                    .invoke(pl, p, "gambler", amount);
        } catch (Exception ignored) {}
    }

    private void achProgress(Player p, String category, long amount) {
        org.bukkit.plugin.Plugin pl = Bukkit.getPluginManager().getPlugin("MAVOAchievements");
        if (pl == null || !pl.isEnabled()) return;
        try {
            pl.getClass().getMethod("externalProgress", Player.class, String.class, long.class)
                    .invoke(pl, p, category, amount);
        } catch (Exception ignored) {}
    }

    private void payout(Player p, Holder h, double mult) {
        long win = h.lucky ? Math.round(h.bet * mult) : (long) Math.floor(h.bet * mult);
        if (win <= 0) {
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 0.8f);
            p.sendMessage(ChatColor.RED + "\u2620 House wins. " + ChatColor.GRAY + "Better luck next time...");
            return;
        }
        if (h.lucky) giveLucky(p, (int) win);
        else if (econ != null) econ.depositPlayer(p, win);
        achProgress(p, h.lucky ? "luckywins" : "winnings", win);
        recordBalances(p);
        String cur = h.lucky ? " \u26C0 Lucky Coins" : " \u26C3 coins";
        if (mult >= 2) {
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1.2f);
            p.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "\u2605 WINNER! " + ChatColor.GREEN + "+" + win + cur
                    + ChatColor.GRAY + " (" + mult + "x)");
            if (p.hasPermission("mavocasino.pokercards")) pokerEmote(p);
        } else {
            p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
            p.sendMessage(ChatColor.GREEN + "You get back " + win + cur + ChatColor.GRAY + " (" + mult + "x)");
        }
    }

    /** Balance achievements: highwater-mark of coin balance + lucky coins carried. */
    private void recordBalances(Player p) {
        org.bukkit.plugin.Plugin pl = Bukkit.getPluginManager().getPlugin("MAVOAchievements");
        if (pl == null || !pl.isEnabled()) return;
        try {
            var m = pl.getClass().getMethod("externalHighwater", Player.class, String.class, long.class);
            if (econ != null) m.invoke(pl, p, "fortune", (long) econ.getBalance(p));
            m.invoke(pl, p, "luckyhoard", (long) countLucky(p));
        } catch (Exception ignored) {}
    }

    /** L1000 ultimate gambler flex: a burst of spinning card-suit particles + jingle. */
    private void pokerEmote(Player p) {
        org.bukkit.Location base = p.getLocation().add(0, 1.2, 0);
        p.getWorld().playSound(base, Sound.ENTITY_PLAYER_LEVELUP, 1f, 2f);
        p.getWorld().playSound(base, Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 1.6f);
        final int[] tick = {0};
        new BukkitRunnable() {
            @Override public void run() {
                if (!p.isOnline() || tick[0]++ >= 20) { cancel(); return; }
                double a = tick[0] * 0.55;
                for (int card = 0; card < 4; card++) {
                    double ang = a + card * Math.PI / 2;
                    double r = 0.9 + 0.25 * Math.sin(tick[0] * 0.4);
                    org.bukkit.Location l = p.getLocation().add(Math.cos(ang) * r, 1.1 + 0.5 * Math.sin(a + card), Math.sin(ang) * r);
                    // red suits = flame/red dust, black suits = smoke/white sparkle
                    if (card % 2 == 0)
                        p.getWorld().spawnParticle(org.bukkit.Particle.DUST, l, 3, 0.05, 0.05, 0.05,
                                new org.bukkit.Particle.DustOptions(org.bukkit.Color.RED, 1.4f));
                    else
                        p.getWorld().spawnParticle(org.bukkit.Particle.DUST, l, 3, 0.05, 0.05, 0.05,
                                new org.bukkit.Particle.DustOptions(org.bukkit.Color.WHITE, 1.4f));
                }
                if (tick[0] % 5 == 0)
                    p.getWorld().spawnParticle(org.bukkit.Particle.FIREWORK, base, 8, 0.4, 0.5, 0.4, 0.05);
            }
        }.runTaskTimer(this, 0L, 2L);
        p.getWorld().getPlayers().forEach(o -> {
            if (o.getLocation().distanceSquared(p.getLocation()) < 400 && !o.equals(p))
                o.sendMessage(ChatColor.RED + "\u2660\u2665 " + ChatColor.GOLD + p.getName()
                        + ChatColor.YELLOW + " fans out their cards - the ultimate gambler wins again! "
                        + ChatColor.RED + "\u2666\u2663");
        });
    }

    /* ---------------- GUI building ---------------- */

    private String trimPct(double luck) {
        double pct = luck * 100;
        return pct == Math.floor(pct) ? String.valueOf((int) pct) : String.valueOf(pct);
    }

    private ItemStack item(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        if (lore != null) {
            List<String> l = new ArrayList<>();
            for (String s : lore) l.add(ChatColor.translateAlternateColorCodes('&', s));
            meta.setLore(l);
        }
        meta.addItemFlags(org.bukkit.inventory.ItemFlag.values());
        it.setItemMeta(meta);
        return it;
    }

    private void fill(Inventory inv) {
        ItemStack pane = item(Material.BLACK_STAINED_GLASS_PANE, " ", null);
        for (int i = 0; i < inv.getSize(); i++) if (inv.getItem(i) == null) inv.setItem(i, pane);
    }

    private void openMain(Player p, Holder prev) {
        Holder h = new Holder();
        if (prev != null) { h.lucky = prev.lucky; h.betIdx = prev.betIdx; }
        Inventory inv = Bukkit.createInventory(h, 36, ChatColor.DARK_RED + "" + ChatColor.BOLD + "\u2663 Lucky Louie's Casino \u2660");
        h.inv = inv;

        int left = attemptsLeft(p.getUniqueId());
        inv.setItem(4, item(Material.CLOCK, "&6&l\u2666 Your Luck Allowance",
                List.of("&fAttempts left: " + (left > 0 ? "&a" : "&c") + left + "&7 / " + getConfig().getInt("attempts", 10),
                        "&7Refills in &e" + nextRefillIn(p.getUniqueId()) + " MC days",
                        "", "&7Every game costs &f1 attempt&7.",
                        "&7Win or lose - Louie doesn't care.")));

        inv.setItem(10, item(Material.DECORATED_POT, "&e&l\u26B1 Pick a Cup",
                List.of("&7Louie shuffles a pearl under 3 cups.", "&7Pick the right one!",
                        "", "&aWin: &f2.7x &7(1 in 3)", "", "&e\u25B6 Click to play")));
        inv.setItem(11, item(Material.SUNFLOWER, "&6&l\u26C0 Coin Flip",
                List.of("&7Heads or tails, double or nothing.", "&7The coin has a tiny dent - house edge!",
                        "", "&aWin: &f2x &7(47.5%)", "", "&e\u25B6 Click to play")));
        inv.setItem(13, item(Material.BONE_BLOCK, "&f&l\u2680 Dice Duel",
                List.of("&7Roll a d6 against Louie.", "&7Higher number wins. &cTies go to Louie!",
                        "", "&aWin: &f2.3x &7(41.7%)", "", "&e\u25B6 Click to play")));
        inv.setItem(15, item(Material.AMETHYST_CLUSTER, "&d&l\u2740 Crystal Wheel",
                List.of("&7Spin the wheel of fate:",
                        "&80x &7\u00B7 &80.5x &7\u00B7 &f1x &7\u00B7 &e2x &7\u00B7 &a3x &7\u00B7 &b10x!",
                        "", "&aAnything can happen...", "", "&e\u25B6 Click to spin")));
        inv.setItem(16, item(Material.TNT, "&c&l\u2620 TNT Tiles",
                List.of("&79 tiles, &c2 hide TNT&7. Reveal tiles,",
                        "&7multiplier grows: &f1.2x \u2192 32x&7!",
                        "&7Cash out any time - or go boom.",
                        "", "&e\u25B6 Click to play")));

        long bet = h.lucky ? LUCKY_BETS[h.betIdx] : COIN_BETS[h.betIdx];
        inv.setItem(28, item(h.lucky ? Material.SUNFLOWER : Material.GOLD_NUGGET,
                "&e&lCurrency: " + (h.lucky ? "&6\u26C0 Lucky Coins" : "&e\u26C3 Coins"),
                List.of("&7Click to switch", "&7You have: &f" + (h.lucky ? countLucky(p) : (econ == null ? 0 : (long) econ.getBalance(p))))));
        inv.setItem(30, item(Material.RED_STAINED_GLASS_PANE, "&c- Lower bet", null));
        inv.setItem(31, item(Material.PAPER, "&f&lBet: &e" + bet + (h.lucky ? " \u26C0" : " \u26C3"),
                List.of("&7Coins: 100 - 5,000", "&7Lucky Coins: 1 - 10")));
        inv.setItem(32, item(Material.LIME_STAINED_GLASS_PANE, "&a+ Raise bet", null));
        double luck = stickLuck(p);
        if (luck >= 0)
            inv.setItem(34, item(Material.BLAZE_ROD, "&6&l\u2660 Lucky Stick held!",
                    List.of("&7Gambler profession bonus:", "&a+" + trimPct(luck) + "% win luck &7on every game",
                            "", "&7Betting also earns &6\u2660 Gambler XP&7.")));
        else
            inv.setItem(34, item(Material.STICK, "&7\u2660 No lucky stick...",
                    List.of("&7Start the &6Gambler &7profession in &e/prof",
                            "&7and HOLD your bound lucky stick here:",
                            "&7- bets earn &6Gambler XP",
                            "&7- the stick adds &awin luck &7(up to +15%)")));
        inv.setItem(35, item(Material.BARRIER, "&cLeave", null));
        fill(inv);
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BANJO, 0.8f, 1.1f);
    }

    private Inventory gameInv(Holder h, String view, String title) {
        h.view = view;
        Inventory inv = Bukkit.createInventory(h, 27, ChatColor.translateAlternateColorCodes('&', title));
        h.inv = inv;
        return inv;
    }

    /* ---------------- games ---------------- */

    private void openCups(Player p, Holder h) {
        Inventory inv = gameInv(h, "cups", "&e&l\u26B1 Pick a Cup &8- bet " + h.bet);
        for (int s : new int[]{11, 13, 15})
            inv.setItem(s, item(Material.DECORATED_POT, "&e&lCup", List.of("&7The pearl is under ONE of these...", "&e\u25B6 Pick me!")));
        inv.setItem(4, item(Material.ENDER_PEARL, "&d&lWhere's the pearl?", List.of("&7One cup pays &a2.7x&7. Choose wisely.")));
        fill(inv);
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_BARREL_OPEN, 1f, 1.2f);
    }

    private void resolveCups(Player p, Holder h, int clickedSlot) {
        h.busy = true;
        int[] slots = {11, 13, 15};
        boolean won = rng.nextDouble() < (1.0 / 3.0 + h.luck);
        int winSlot;
        if (won) winSlot = clickedSlot;
        else { do { winSlot = slots[rng.nextInt(3)]; } while (winSlot == clickedSlot); }
        for (int s : slots) {
            if (s == winSlot) h.inv.setItem(s, item(Material.ENDER_PEARL, "&d&lThe pearl!", null));
            else h.inv.setItem(s, item(Material.BARRIER, "&8Empty", null));
        }
        p.playSound(p.getLocation(), Sound.BLOCK_BARREL_CLOSE, 1f, 0.9f);
        finishLater(p, h, won ? 2.7 : 0, 25);
    }

    private void openFlip(Player p, Holder h) {
        Inventory inv = gameInv(h, "flip", "&6&l\u26C0 Coin Flip &8- bet " + h.bet);
        inv.setItem(11, item(Material.REDSTONE_BLOCK, "&c&lRED side", List.of("&e\u25B6 Call red!")));
        inv.setItem(15, item(Material.LAPIS_BLOCK, "&9&lBLUE side", List.of("&e\u25B6 Call blue!")));
        inv.setItem(4, item(Material.SUNFLOWER, "&6&lCall the flip", List.of("&7Right call pays &a2x")));
        fill(inv);
        p.openInventory(inv);
    }

    private void resolveFlip(Player p, Holder h, boolean calledRed) {
        h.busy = true;
        boolean won = rng.nextDouble() < 0.475 + h.luck;
        boolean landsRed = won == calledRed;
        final int[] tick = {0};
        new BukkitRunnable() {
            @Override public void run() {
                if (!p.isOnline()) { cancel(); return; }
                tick[0]++;
                if (tick[0] < 8) {
                    boolean red = tick[0] % 2 == 0;
                    h.inv.setItem(13, item(red ? Material.REDSTONE_BLOCK : Material.LAPIS_BLOCK,
                            red ? "&c&l\u26C0 spinning..." : "&9&l\u26C0 spinning...", null));
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.6f, 1f + tick[0] * 0.1f);
                    return;
                }
                cancel();
                h.inv.setItem(13, item(landsRed ? Material.REDSTONE_BLOCK : Material.LAPIS_BLOCK,
                        landsRed ? "&c&lIt's RED!" : "&9&lIt's BLUE!", null));
                finishNow(p, h, won ? 2.0 : 0);
            }
        }.runTaskTimer(this, 5L, 4L);
    }

    private void openDice(Player p, Holder h) {
        Inventory inv = gameInv(h, "dice", "&f&l\u2680 Dice Duel &8- bet " + h.bet);
        inv.setItem(13, item(Material.BONE_BLOCK, "&f&lROLL THE DICE", List.of("&7Beat Louie's roll to win &a2.3x", "&cTies go to Louie!", "", "&e\u25B6 Click to roll")));
        fill(inv);
        p.openInventory(inv);
    }

    private void resolveDice(Player p, Holder h) {
        h.busy = true;
        boolean won = rng.nextDouble() < 15.0 / 36.0 + h.luck; // base 41.7% + stick luck
        int mine, louie;
        do { mine = 1 + rng.nextInt(6); louie = 1 + rng.nextInt(6); }
        while (won != (mine > louie));
        h.inv.setItem(11, item(Material.LIME_CONCRETE, "&a&lYou rolled: " + mine, null));
        h.inv.setItem(15, item(Material.RED_CONCRETE, "&c&lLouie rolled: " + louie, null));
        h.inv.setItem(13, item(won ? Material.GOLD_BLOCK : Material.COAL_BLOCK,
                won ? "&6&lYOU WIN!" : (mine == louie ? "&c&lTIE - Louie takes it!" : "&c&lLouie wins!"), null));
        p.playSound(p.getLocation(), Sound.BLOCK_STONE_HIT, 1f, 0.8f);
        finishLater(p, h, won ? 2.3 : 0, 25);
    }

    private void openWheel(Player p, Holder h) {
        Inventory inv = gameInv(h, "wheel", "&d&l\u2740 Crystal Wheel &8- bet " + h.bet);
        inv.setItem(13, item(Material.AMETHYST_CLUSTER, "&d&lSPIN", List.of("&80x &7\u00B7 &80.5x &7\u00B7 &f1x &7\u00B7 &e2x &7\u00B7 &a3x &7\u00B7 &b10x", "", "&e\u25B6 Click to spin")));
        fill(inv);
        p.openInventory(inv);
    }

    private int pickWheel() {
        int total = 0; for (int w : WHEEL_WEIGHT) total += w;
        int r = rng.nextInt(total);
        for (int i = 0; i < WHEEL_WEIGHT.length; i++) { r -= WHEEL_WEIGHT[i]; if (r < 0) return i; }
        return 0;
    }

    private void resolveWheel(Player p, Holder h) {
        h.busy = true;
        int firstSpin = pickWheel();
        // gambler stick luck: chance to spin twice and keep the better result
        if (h.luck > 0 && rng.nextDouble() < h.luck * 2) firstSpin = Math.max(firstSpin, pickWheel());
        final int result = firstSpin;
        final int[] tick = {0};
        new BukkitRunnable() {
            @Override public void run() {
                if (!p.isOnline()) { cancel(); return; }
                tick[0]++;
                if (tick[0] < 12) {
                    int show = rng.nextInt(WHEEL_MULT.length);
                    h.inv.setItem(13, item(WHEEL_ICON[show], "&d&l" + WHEEL_MULT[show] + "x ...", null));
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_XYLOPHONE, 0.6f, 0.8f + tick[0] * 0.1f);
                    return;
                }
                cancel();
                double mult = WHEEL_MULT[result];
                h.inv.setItem(13, item(WHEEL_ICON[result],
                        (mult >= 2 ? "&a&l" : mult >= 1 ? "&e&l" : "&c&l") + "Landed on " + mult + "x!", null));
                finishNow(p, h, mult);
            }
        }.runTaskTimer(this, 5L, 3L);
    }

    private void openMines(Player p, Holder h) {
        Inventory inv = gameInv(h, "mines", "&c&l\u2620 TNT Tiles &8- bet " + h.bet);
        h.settled = false;
        h.revealed = 0;
        java.util.Arrays.fill(h.tnt, false);
        int placed = 0;
        while (placed < 2) {
            int t = rng.nextInt(9);
            if (!h.tnt[t]) { h.tnt[t] = true; placed++; }
        }
        int[] grid = {3, 4, 5, 12, 13, 14, 21, 22, 23};
        for (int g : grid) inv.setItem(g, item(Material.GRAY_WOOL, "&7? Tile", List.of("&e\u25B6 Reveal (2 TNT hiding!)")));
        inv.setItem(17, item(Material.GOLD_INGOT, "&6&lCASH OUT",
                List.of("&7Current: &f1.0x &7(your bet back)", "&7Next safe tile: &a1.2x")));
        fill(inv);
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 0.7f);
    }

    private int mineIndex(int slot) {
        int[] grid = {3, 4, 5, 12, 13, 14, 21, 22, 23};
        for (int i = 0; i < grid.length; i++) if (grid[i] == slot) return i;
        return -1;
    }

    private void resolveMineClick(Player p, Holder h, int slot) {
        int idx = mineIndex(slot);
        if (idx >= 0) {
            ItemStack cur = h.inv.getItem(slot);
            if (cur == null || cur.getType() != Material.GRAY_WOOL) return; // already revealed
            // gambler stick luck: chance the TNT "fizzles" and slides to another hidden tile
            if (h.tnt[idx] && h.luck > 0 && rng.nextDouble() < h.luck) {
                int[] grid = {3, 4, 5, 12, 13, 14, 21, 22, 23};
                List<Integer> spots = new ArrayList<>();
                for (int i = 0; i < 9; i++) {
                    if (i == idx || h.tnt[i]) continue;
                    ItemStack tile = h.inv.getItem(grid[i]);
                    if (tile != null && tile.getType() == Material.GRAY_WOOL) spots.add(i);
                }
                if (!spots.isEmpty()) {
                    h.tnt[idx] = false;
                    h.tnt[spots.get(rng.nextInt(spots.size()))] = true;
                    p.playSound(p.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 1f, 1.4f);
                    p.sendMessage(ChatColor.GOLD + "\u2660 " + ChatColor.YELLOW + "Your lucky stick trembles... the TNT fizzles out!");
                }
            }
            if (h.tnt[idx]) {
                // boom - reveal all
                int[] grid = {3, 4, 5, 12, 13, 14, 21, 22, 23};
                for (int i = 0; i < 9; i++)
                    h.inv.setItem(grid[i], item(h.tnt[i] ? Material.TNT : Material.LIME_WOOL,
                            h.tnt[i] ? "&c&lTNT!" : "&aSafe", null));
                h.settled = true;
                h.busy = true;
                p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
                finishLater(p, h, 0, 30);
                return;
            }
            h.revealed++;
            double mult = MINE_MULT[h.revealed - 1];
            h.inv.setItem(slot, item(Material.LIME_WOOL, "&a&lSafe! &f" + mult + "x", null));
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 0.8f + h.revealed * 0.15f);
            if (h.revealed >= 7) { // all safe tiles found
                h.settled = true;
                h.busy = true;
                p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                finishLater(p, h, MINE_MULT[6], 30);
                return;
            }
            double next = MINE_MULT[h.revealed];
            h.inv.setItem(17, item(Material.GOLD_INGOT, "&6&lCASH OUT",
                    List.of("&7Current: &a" + mult + "x", "&7Next safe tile: &a" + next + "x",
                            "&7TNT left: &c2 &7in &f" + (9 - h.revealed - 0) + " tiles... wait, still 2!")));
            return;
        }
        if (slot == 17) { // cash out
            double mult = h.revealed == 0 ? 1.0 : MINE_MULT[h.revealed - 1];
            h.settled = true;
            h.busy = true;
            finishNow(p, h, mult);
        }
    }

    /* ---------------- finish helpers ---------------- */

    private void finishNow(Player p, Holder h, double mult) {
        h.settled = true;
        payout(p, h, mult);
        Bukkit.getScheduler().runTaskLater(this, () -> { if (p.isOnline()) openMain(p, h); }, 30L);
    }

    private void finishLater(Player p, Holder h, double mult, long delayTicks) {
        h.settled = true;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline()) return;
            payout(p, h, mult);
            openMain(p, h);
        }, delayTicks);
    }

    /* ---------------- events ---------------- */

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getRawSlot() >= e.getInventory().getSize()) return; // clicks in own inventory
        if (h.busy) return;
        int slot = e.getRawSlot();

        if (h.view.equals("main")) {
            switch (slot) {
                case 28 -> { h.lucky = !h.lucky; h.betIdx = 0; openMain(p, h); }
                case 30 -> { h.betIdx = Math.max(0, h.betIdx - 1); openMain(p, h); }
                case 32 -> { h.betIdx = Math.min((h.lucky ? LUCKY_BETS : COIN_BETS).length - 1, h.betIdx + 1); openMain(p, h); }
                case 35 -> p.closeInventory();
                case 10, 11, 13, 15, 16 -> startGame(p, h, slot);
            }
            return;
        }
        // in-game clicks
        switch (h.view) {
            case "cups" -> { if (slot == 11 || slot == 13 || slot == 15) resolveCups(p, h, slot); }
            case "flip" -> { if (slot == 11) resolveFlip(p, h, true); else if (slot == 15) resolveFlip(p, h, false); }
            case "dice" -> { if (slot == 13) resolveDice(p, h); }
            case "wheel" -> { if (slot == 13) resolveWheel(p, h); }
            case "mines" -> resolveMineClick(p, h, slot);
        }
    }

    private void startGame(Player p, Holder h, int slot) {
        if (p.getGameMode() != GameMode.SURVIVAL) {
            p.sendMessage(ChatColor.RED + "Louie only takes bets from SURVIVAL players.");
            return;
        }
        if (attemptsLeft(p.getUniqueId()) <= 0) {
            p.sendMessage(ChatColor.RED + "\u2620 You're out of luck! " + ChatColor.GRAY + "Attempts refill in "
                    + nextRefillIn(p.getUniqueId()) + " MC days.");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 0.8f);
            return;
        }
        if (!chargeBet(p, h)) return;
        useAttempt(p.getUniqueId());
        switch (slot) {
            case 10 -> openCups(p, h);
            case 11 -> openFlip(p, h);
            case 13 -> openDice(p, h);
            case 15 -> openWheel(p, h);
            case 16 -> openMines(p, h);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        // walked away mid-TNT-run: auto cash-out at current multiplier
        if (h.view.equals("mines") && !h.settled) {
            h.settled = true;
            double mult = h.revealed == 0 ? 1.0 : MINE_MULT[h.revealed - 1];
            long win = h.lucky ? Math.round(h.bet * mult) : (long) Math.floor(h.bet * mult);
            if (win > 0) {
                if (h.lucky) giveLucky(p, (int) win);
                else if (econ != null) econ.depositPlayer(p, win);
                achProgress(p, h.lucky ? "luckywins" : "winnings", win);
                recordBalances(p);
                p.sendMessage(ChatColor.YELLOW + "Cashed out " + win + (h.lucky ? " \u26C0" : " \u26C3")
                        + ChatColor.GRAY + " (" + mult + "x) - you walked away from the table.");
            }
        }
    }

    /* ---------------- command ---------------- */

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        openMain(p, null);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) { return List.of(); }
}
