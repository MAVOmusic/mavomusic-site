package mavo.vault;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.block.DoubleChest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;

/**
 * MAVOVault - two paid-access rooms at spawn + buyable personal vault chests.
 *
 * GATES: two named regions ("vault" 50,000 / "portalroom" 25,000). Walking into
 * a gate region without access bounces you back and offers a purchase GUI.
 * Buy once, enter forever.
 *
 * VAULT CHESTS: right-click an unclaimed (double) chest inside the vault region
 * -> purchase GUI (5,000). Chest becomes yours: only you open/break it, floating
 * nametag "<player>'s Vault [name]" above it, renameable any time.
 */
public final class VaultRooms extends JavaPlugin implements Listener {

    private Economy econ;
    private File dataFile;
    private YamlConfiguration data;
    private NamespacedKey holoKey;
    private final Map<UUID, Location[]> setup = new HashMap<>();   // admin pos1/pos2 buffer
    private final Map<UUID, String> renaming = new HashMap<>();    // player -> chest key awaiting chat name
    private final Map<UUID, Long> lastNag = new HashMap<>();       // anti chat spam on bounce
    private final Map<UUID, Integer> countdown = new HashMap<>();  // player -> ticks stood in a teaser portal
    private final Map<UUID, Long> soonCooldown = new HashMap<>();  // anti-spam for "coming soon"
    private final Map<String, UUID[]> gateHolos = new HashMap<>(); // gate id -> [unlockedHolo, lockedHolo]
    private final java.util.Random rng = new java.util.Random();
    private int fxTick = 0;

    static final class Holder implements InventoryHolder {
        String kind;     // "gate" | "chest" | "room" | "slot"
        String gateId;   // vault | portalroom
        String chestKey; // world:x:y:z of primary half
        String roomId;   // e.g. L1N3
        int slotUnit;    // chest unit index 0..14
        Inventory inv;
        @Override public @NotNull Inventory getInventory() { return inv; }
    }

    /* ---------------- private room model (matches datapack vault_build) ---------------- */

    static final int[] LEVEL_Y = {200, 206, 212, 218, 224, 230};
    static final long[] SLOT_PRICES = {0, 1000, 1000, 2500, 2500, 2500,
            5000, 5000, 5000, 5000, 10000, 10000, 10000, 10000, 10000};

    static final class Room {
        String id;          // L<level+1><N|S><col+1>
        int level, col;
        boolean south;
        int y0;             // floor walk level
        int ax;             // west interior col A
        int doorX, doorZ, signZ;
        Map<Long, Integer> unitAt = new HashMap<>(); // packed x,z -> unit 0..14
    }

    private final Map<String, Room> rooms = new java.util.LinkedHashMap<>();

    private static long pack(int x, int z) { return ((long) x << 32) ^ (z & 0xffffffffL); }

    private void buildRoomTable() {
        for (int level = 0; level < 6; level++)
            for (int s = 0; s < 2; s++)
                for (int col = 0; col < 8; col++) {
                    boolean south = s == 1;
                    Room r = new Room();
                    r.level = level; r.col = col; r.south = south;
                    r.id = "L" + (level + 1) + (south ? "S" : "N") + (col + 1);
                    r.y0 = LEVEL_Y[level];
                    int A = -2793 + 11 * col, B = A + 8, c = A + 4;
                    r.ax = A;
                    r.doorX = c;
                    r.doorZ = south ? -1681 : -1689;
                    r.signZ = south ? -1682 : -1688;
                    int u;
                    if (!south) {
                        int[] zs = {-1702, -1699, -1696, -1693};
                        u = 0;
                        for (int z : zs) { r.unitAt.put(pack(A, z), u); r.unitAt.put(pack(A, z + 1), u); u++; }
                        for (int z : zs) { r.unitAt.put(pack(B, z), u); r.unitAt.put(pack(B, z + 1), u); u++; }
                        for (int x : new int[]{c - 2, c + 1}) { r.unitAt.put(pack(x, -1702), u); r.unitAt.put(pack(x + 1, -1702), u); u++; }
                        for (int x : new int[]{A, A + 7}) { r.unitAt.put(pack(x, -1690), u); r.unitAt.put(pack(x + 1, -1690), u); u++; }
                        for (int z : new int[]{-1700, -1697, -1694}) { r.unitAt.put(pack(c - 1, z), u); r.unitAt.put(pack(c, z), u); u++; }
                    } else {
                        int[] zs = {-1669, -1672, -1675, -1678};
                        u = 0;
                        for (int z : zs) { r.unitAt.put(pack(A, z), u); r.unitAt.put(pack(A, z + 1), u); u++; }
                        for (int z : zs) { r.unitAt.put(pack(B, z), u); r.unitAt.put(pack(B, z + 1), u); u++; }
                        for (int x : new int[]{c - 2, c + 1}) { r.unitAt.put(pack(x, -1668), u); r.unitAt.put(pack(x + 1, -1668), u); u++; }
                        for (int x : new int[]{A, A + 7}) { r.unitAt.put(pack(x, -1680), u); r.unitAt.put(pack(x + 1, -1680), u); u++; }
                        for (int z : new int[]{-1670, -1673, -1676}) { r.unitAt.put(pack(c - 1, z), u); r.unitAt.put(pack(c, z), u); u++; }
                    }
                    rooms.put(r.id, r);
                }
    }

    /** room whose interior or door contains this block, else null */
    private Room roomAt(Block b) {
        int x = b.getX(), y = b.getY(), z = b.getZ();
        for (Room r : rooms.values()) {
            if (y < r.y0 || y > r.y0 + 4) continue;
            if (x < r.ax - 1 || x > r.ax + 9) continue;
            boolean inZ = r.south ? (z >= -1681 && z <= -1667) : (z >= -1703 && z <= -1689);
            if (inZ) return r;
        }
        return null;
    }

    private String roomOwner(String roomId) { return data.getString("rooms." + roomId + ".owner", null); }
    private String roomOfPlayer(UUID u) { return data.getString("playerroom." + u, null); }
    private List<Integer> unlockedSlots(String roomId) { return data.getIntegerList("rooms." + roomId + ".slots"); }

    private long nextSlotPrice(String roomId) {
        int owned = unlockedSlots(roomId).size();
        return owned >= 15 ? -1 : SLOT_PRICES[owned];
    }

    private void writeRoomSign(Room r, String ownerName) {
        World w = Bukkit.getWorld(getConfig().getString("gates.vault.region.world", "world"));
        if (w == null) return;
        Block sb = w.getBlockAt(r.doorX, r.y0 + 2, r.signZ);
        if (!(sb.getState() instanceof org.bukkit.block.Sign sign)) return;
        var side = sign.getSide(org.bukkit.block.sign.Side.FRONT);
        if (ownerName == null) {
            side.setLine(0, ChatColor.DARK_GRAY + "\u2726 \u2726 \u2726");
            side.setLine(1, ChatColor.GRAY + "Unclaimed");
            side.setLine(2, ChatColor.GRAY + "Vault Room");
            side.setLine(3, ChatColor.DARK_GRAY + r.id);
        } else {
            side.setLine(0, ChatColor.DARK_RED + "\u2726\u2726\u2726\u2726\u2726\u2726\u2726");
            side.setLine(1, ChatColor.GOLD + "" + ChatColor.BOLD + ownerName + "'s");
            side.setLine(2, ChatColor.GOLD + "" + ChatColor.BOLD + "Vault");
            side.setLine(3, ChatColor.DARK_RED + "\u2726 " + ChatColor.GRAY + r.id + ChatColor.DARK_RED + " \u2726");
        }
        sign.setWaxed(true);
        sign.update(true, false);
    }

    private void refreshAllSigns() {
        for (Room r : rooms.values()) {
            String o = roomOwner(r.id);
            String name = null;
            if (o != null) {
                var op = Bukkit.getOfflinePlayer(UUID.fromString(o));
                name = op.getName() != null ? op.getName() : "Someone";
            }
            writeRoomSign(r, name);
        }
    }


    /* ---------------- lifecycle ---------------- */

    @Override
    public void onEnable() {
        saveDefaultConfig();
        holoKey = new NamespacedKey(this, "vaultholo");
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider();
        buildRoomTable();
        getServer().getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskLater(this, this::respawnAllHolos, 60L);
        Bukkit.getScheduler().runTaskLater(this, this::refreshAllSigns, 100L);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            spawnPortalHolo("vault"); spawnPortalHolo("portalroom");
            spawnPortalHolo("vault_return"); spawnPortalHolo("portalroom_return");
        }, 80L);
        Bukkit.getScheduler().runTaskTimer(this, this::fxLoop, 40L, 2L);
        Bukkit.getScheduler().runTaskTimer(this, this::countdownLoop, 40L, 10L);
        Bukkit.getScheduler().runTaskTimer(this, this::holoVisibilityLoop, 100L, 40L);
        getLogger().info("MAVOVault enabled - gates: vault "
                + gatePrice("vault") + " / portalroom " + gatePrice("portalroom")
                + ", chest price " + chestPrice() + ".");
    }

    @Override
    public void onDisable() { save(); }

    private void save() { try { data.save(dataFile); } catch (Exception ignored) {} }

    private long gatePrice(String id) { return getConfig().getLong("gates." + id + ".price", id.equals("vault") ? 50000 : 25000); }
    private long chestPrice() { return getConfig().getLong("chest-price", 5000); }
    private long renamePrice() { return getConfig().getLong("rename-price", 0); }

    private String gateName(String id) {
        return id.equals("vault") ? ChatColor.GOLD + "" + ChatColor.BOLD + "\u2666 THE VAULT \u2666"
                : ChatColor.AQUA + "" + ChatColor.BOLD + "\u25C9 PORTAL ROOM \u25C9";
    }

    /* ---------------- regions ---------------- */

    private boolean inRegion(String id, Location l) {
        String base = "gates." + id + ".region.";
        String w = getConfig().getString(base + "world", null);
        if (w == null || l.getWorld() == null || !l.getWorld().getName().equals(w)) return false;
        double x1 = getConfig().getDouble(base + "x1"), x2 = getConfig().getDouble(base + "x2");
        double y1 = getConfig().getDouble(base + "y1"), y2 = getConfig().getDouble(base + "y2");
        double z1 = getConfig().getDouble(base + "z1"), z2 = getConfig().getDouble(base + "z2");
        return l.getX() >= Math.min(x1, x2) && l.getX() <= Math.max(x1, x2) + 1
                && l.getY() >= Math.min(y1, y2) && l.getY() <= Math.max(y1, y2) + 1
                && l.getZ() >= Math.min(z1, z2) && l.getZ() <= Math.max(z1, z2) + 1;
    }

    private String regionAt(Location l) {
        if (inRegion("vault", l)) return "vault";
        if (inRegion("portalroom", l)) return "portalroom";
        return null;
    }

    private boolean hasAccess(Player p, String id) {
        if (p.hasPermission("mavovault.admin") && p.getGameMode() == GameMode.CREATIVE) return true;
        return data.getStringList("access." + id).contains(p.getUniqueId().toString());
    }

    private void grantAccess(UUID u, String id) {
        List<String> l = data.getStringList("access." + id);
        if (!l.contains(u.toString())) { l.add(u.toString()); data.set("access." + id, l); save(); }
    }

    /* ---------------- gate enforcement ---------------- */

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo(), from = e.getFrom();
        if (to == null) return;
        if (to.getBlockX() == from.getBlockX() && to.getBlockY() == from.getBlockY()
                && to.getBlockZ() == from.getBlockZ()) return;
        String id = regionAt(to);
        if (id == null) return;
        Player p = e.getPlayer();
        if (hasAccess(p, id)) return;
        // bounce them back out
        e.setCancelled(true);
        Vector push = from.toVector().subtract(to.toVector());
        push.setY(0);
        if (push.lengthSquared() > 0.0001) {
            push.normalize().multiply(0.6).setY(0.25);
            p.setVelocity(push);
        }
        long now = System.currentTimeMillis();
        Long last = lastNag.get(p.getUniqueId());
        if (last == null || now - last > 3000) {
            lastNag.put(p.getUniqueId(), now);
            p.playSound(p.getLocation(), Sound.BLOCK_CHEST_LOCKED, 1f, 0.7f);
            openGateGui(p, id);
        }
    }

    private void openGateGui(Player p, String id) {
        Holder h = new Holder(); h.kind = "gate"; h.gateId = id;
        Inventory inv = Bukkit.createInventory(h, 27, gateName(id));
        h.inv = inv;
        long price = gatePrice(id);
        long bal = econ == null ? 0 : (long) econ.getBalance(p);
        List<String> what = id.equals("vault")
                ? List.of("&7Behind this door: private &fvault chests&7.",
                        "&7Buy chests, name them, stash your most",
                        "&7precious loot away from your base.",
                        "", "&7One-time entry fee. Yours forever.")
                : List.of("&7Behind this door: &fdestination portals&7.",
                        "&7Biome jumps, cave dives and more",
                        "&7as the room fills out over time.",
                        "", "&7One-time entry fee. Yours forever.");
        List<String> lore = new ArrayList<>(what);
        lore.add("");
        lore.add("&fPrice: &e" + fmt(price) + " \u26C3");
        lore.add("&fYour coins: " + (bal >= price ? "&a" : "&c") + fmt(bal) + " \u26C3");
        inv.setItem(13, item(id.equals("vault") ? Material.GOLD_BLOCK : Material.END_PORTAL_FRAME,
                gateName(id), lore, true));
        if (bal >= price)
            inv.setItem(11, item(Material.LIME_CONCRETE, "&a&l\u2714 UNLOCK ACCESS",
                    List.of("&7Pay &e" + fmt(price) + " \u26C3 &7once,", "&7enter whenever you like."), false));
        else
            inv.setItem(11, item(Material.GRAY_CONCRETE, "&8\u2718 Not enough coins",
                    List.of("&7You need &c" + fmt(price - bal) + " \u26C3 &7more."), false));
        inv.setItem(15, item(Material.RED_CONCRETE, "&c\u2718 Not today", null, false));
        fill(inv);
        p.openInventory(inv);
    }

    /* ---------------- chest helpers ---------------- */

    private String chestKey(Block b) {
        return b.getWorld().getName() + ":" + b.getX() + ":" + b.getY() + ":" + b.getZ();
    }

    /** primary half of a (double) chest = the half with the lowest x, then lowest z */
    private Block primaryHalf(Block b) {
        if (!(b.getState() instanceof Chest c)) return b;
        InventoryHolder ih = c.getInventory().getHolder();
        if (ih instanceof DoubleChest dc) {
            Chest l = (Chest) dc.getLeftSide(), r = (Chest) dc.getRightSide();
            if (l == null || r == null) return b;
            Block lb = l.getBlock(), rb = r.getBlock();
            if (lb.getX() != rb.getX()) return lb.getX() < rb.getX() ? lb : rb;
            return lb.getZ() < rb.getZ() ? lb : rb;
        }
        return b;
    }

    private String ownerOf(String key) { return data.getString("chests." + key + ".owner", null); }
    private String nameOf(String key) { return data.getString("chests." + key + ".name", "Vault"); }

    private void setChest(String key, UUID owner, String name) {
        data.set("chests." + key + ".owner", owner.toString());
        data.set("chests." + key + ".name", name);
        save();
    }

    /* ---------------- chest holo ---------------- */

    private void respawnAllHolos() {
        var sec = data.getConfigurationSection("chests");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) spawnChestHolo(key);
    }

    private Location keyToLoc(String key) {
        String[] p = key.split(":");
        World w = Bukkit.getWorld(p[0]);
        if (w == null) return null;
        return new Location(w, Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]));
    }

    private void spawnChestHolo(String key) {
        Location base = keyToLoc(key);
        if (base == null) return;
        String ownerId = ownerOf(key);
        if (ownerId == null) return;
        var op = Bukkit.getOfflinePlayer(UUID.fromString(ownerId));
        String pname = op.getName() != null ? op.getName() : "Someone";
        // double chest? center between halves
        Location loc = base.clone().add(0.5, 1.35, 0.5);
        Block b = base.getBlock();
        if (b.getState() instanceof Chest c && c.getInventory().getHolder() instanceof DoubleChest dc) {
            Location l = ((Chest) dc.getLeftSide()).getBlock().getLocation();
            Location r = ((Chest) dc.getRightSide()).getBlock().getLocation();
            loc = l.add(r).multiply(0.5).add(0.5, 1.35, 0.5);
            loc.setWorld(base.getWorld());
        }
        base.getChunk().load();
        // sweep orphans near this chest
        for (Entity ent : base.getWorld().getNearbyEntities(loc, 1.2, 2, 1.2))
            if (ent instanceof TextDisplay && ent.getPersistentDataContainer().has(holoKey, PersistentDataType.BYTE))
                ent.remove();
        String text = ChatColor.GOLD + pname + "'s Vault" + ChatColor.GRAY + " \u2666 "
                + ChatColor.YELLOW + "[" + ChatColor.WHITE + nameOf(key) + ChatColor.YELLOW + "]";
        TextDisplay td = base.getWorld().spawn(loc, TextDisplay.class, d -> {
            d.setText(text);
            d.setBillboard(Display.Billboard.CENTER);
            d.setShadowed(true);
            d.setSeeThrough(false);
            try { d.setDefaultBackground(false); d.setBackgroundColor(Color.fromARGB(170, 15, 10, 5)); } catch (Throwable ignored) {}
            d.setAlignment(TextDisplay.TextAlignment.CENTER);
            d.setLineWidth(200);
            var tr = d.getTransformation();
            tr.getScale().set(0.7f);
            d.setTransformation(tr);
            d.setViewRange(0.6f);
            try { d.setBrightness(new Display.Brightness(15, 15)); } catch (Throwable ignored) {}
            d.setPersistent(true);
            d.getPersistentDataContainer().set(holoKey, PersistentDataType.BYTE, (byte) 1);
        });
        data.set("chests." + key + ".holo", td.getUniqueId().toString());
        save();
    }

    private void removeChestHolo(String key) {
        String id = data.getString("chests." + key + ".holo", null);
        if (id != null) {
            try { Entity ent = Bukkit.getEntity(UUID.fromString(id)); if (ent != null) ent.remove(); }
            catch (Exception ignored) {}
        }
        Location base = keyToLoc(key);
        if (base != null)
            for (Entity ent : base.getWorld().getNearbyEntities(base.clone().add(0.5, 1.35, 0.5), 1.5, 2.5, 1.5))
                if (ent instanceof TextDisplay && ent.getPersistentDataContainer().has(holoKey, PersistentDataType.BYTE))
                    ent.remove();
    }

    /* ---------------- chest interaction ---------------- */

    /** Fixed Vault interior box (matches the builder datapack) - room/chest/door
     *  protection must NOT depend on the admin-set gate region, which may be
     *  smaller (e.g. only the doorway used for entry enforcement). */
    private boolean inVaultInterior(Location l) {
        if (l.getWorld() == null) return false;
        String w = getConfig().getString("gates.vault.region.world", "world");
        if (!l.getWorld().getName().equals(w)) return false;
        int x = l.getBlockX(), y = l.getBlockY(), z = l.getBlockZ();
        return x >= -2799 && x <= -2701 && y >= 199 && y <= 237 && z >= -1704 && z <= -1666;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        Block b = e.getClickedBlock();
        boolean isChest = b.getType() == Material.CHEST || b.getType() == Material.TRAPPED_CHEST;
        boolean isDoor = b.getType() == Material.BIRCH_DOOR;
        if (!isChest && !isDoor) return;
        if (!inVaultInterior(b.getLocation())) return;
        Player p = e.getPlayer();
        boolean adminCreative = p.hasPermission("mavovault.admin") && p.getGameMode() == GameMode.CREATIVE;
        Room r = roomAt(b);
        if (r == null) { if (!adminCreative) e.setCancelled(true); return; }
        String owner = roomOwner(r.id);

        if (isDoor) {
            // your key only: owner (or admin creative) may open a claimed door
            if (owner == null) {
                e.setCancelled(true);
                if (!hasAccess(p, "vault")) { openGateGui(p, "vault"); return; }
                openRoomBuyGui(p, r);
                return;
            }
            if (!owner.equals(p.getUniqueId().toString()) && !adminCreative) {
                e.setCancelled(true);
                var op = Bukkit.getOfflinePlayer(UUID.fromString(owner));
                p.sendMessage(ChatColor.RED + "\u26D4 " + ChatColor.GOLD
                        + (op.getName() != null ? op.getName() : "Someone") + "'s Vault"
                        + ChatColor.RED + " - your key doesn't fit.");
                p.playSound(p.getLocation(), Sound.BLOCK_CHEST_LOCKED, 1f, 0.6f);
            }
            return; // owner: vanilla door open proceeds
        }

        // chest inside a room
        if (owner == null) {
            e.setCancelled(true);
            if (!hasAccess(p, "vault")) { openGateGui(p, "vault"); return; }
            openRoomBuyGui(p, r);
            return;
        }
        if (!owner.equals(p.getUniqueId().toString()) && !adminCreative) {
            e.setCancelled(true);
            p.playSound(p.getLocation(), Sound.BLOCK_CHEST_LOCKED, 1f, 0.6f);
            return;
        }
        if (adminCreative && !owner.equals(p.getUniqueId().toString())) return; // admin bypass
        Integer unit = r.unitAt.get(pack(b.getX(), b.getZ()));
        if (unit == null) { e.setCancelled(true); return; }
        if (!unlockedSlots(r.id).contains(unit)) {
            e.setCancelled(true);
            openSlotBuyGui(p, r, unit);
        }
        // unlocked slot: vanilla open proceeds
    }

    private void openRoomBuyGui(Player p, Room r) {
        String existing = roomOfPlayer(p.getUniqueId());
        Holder h = new Holder(); h.kind = "room"; h.roomId = r.id;
        Inventory inv = Bukkit.createInventory(h, 27, ChatColor.GOLD + "" + ChatColor.BOLD + "Claim Vault Room " + r.id + "?");
        h.inv = inv;
        long price = chestPrice(); // room claim price reuses chest-price (5,000)
        long bal = econ == null ? 0 : (long) econ.getBalance(p);
        if (existing != null) {
            inv.setItem(13, item(Material.BARRIER, "&c&lYou already own room " + existing,
                    List.of("&7One private vault room per player.",
                            "&7Yours is &f" + existing + "&7 (L=level, N/S=side).",
                            "&7Ask an admin to &f/vaultroom releaseroom&7 it",
                            "&7if you want to move."), false));
            inv.setItem(15, item(Material.RED_CONCRETE, "&cClose", null, false));
            fill(inv); p.openInventory(inv); return;
        }
        inv.setItem(13, item(Material.OAK_DOOR, "&6&lPrivate Vault Room " + r.id,
                List.of("&7Claim this WHOLE room as YOURS:",
                        "&7- only your key opens the door",
                        "&7- 15 double chests inside",
                        "&7- 1st chest &aFREE&7, more unlock with coins",
                        "&7- your name on the door sign",
                        "",
                        "&fClaim price: &e" + fmt(price) + " \u26C3",
                        "&fYour coins: " + (bal >= price ? "&a" : "&c") + fmt(bal) + " \u26C3"), true));
        if (bal >= price)
            inv.setItem(11, item(Material.LIME_CONCRETE, "&a&l\u2714 CLAIM ROOM", null, false));
        else
            inv.setItem(11, item(Material.GRAY_CONCRETE, "&8\u2718 Not enough coins",
                    List.of("&7You need &c" + fmt(price - bal) + " \u26C3 &7more."), false));
        inv.setItem(15, item(Material.RED_CONCRETE, "&cCancel", null, false));
        fill(inv);
        p.openInventory(inv);
    }

    private void openSlotBuyGui(Player p, Room r, int unit) {
        Holder h = new Holder(); h.kind = "slot"; h.roomId = r.id; h.slotUnit = unit;
        Inventory inv = Bukkit.createInventory(h, 27, ChatColor.GOLD + "" + ChatColor.BOLD + "Unlock Vault Slot?");
        h.inv = inv;
        int owned = unlockedSlots(r.id).size();
        long price = nextSlotPrice(r.id);
        long bal = econ == null ? 0 : (long) econ.getBalance(p);
        List<String> lore = new ArrayList<>(List.of(
                "&7This chest is still &fsealed&7.",
                "&7Slots unlocked so far: &f" + owned + "&7/&f15",
                "",
                "&7Unlock ladder:",
                "&7#1 &aFREE &8| &7#2-3 &e1,000 &8| &7#4-6 &e2,500",
                "&7#7-10 &e5,000 &8| &7#11-15 &e10,000",
                ""));
        if (price == 0) lore.add("&fThis one: &a&lFREE");
        else lore.add("&fThis one: &e" + fmt(price) + " \u26C3" + " &8(&7you have "
                + (bal >= price ? "&a" : "&c") + fmt(bal) + "&8)");
        inv.setItem(13, item(Material.CHEST, "&6&lVault Slot #" + (owned + 1), lore, true));
        if (price == 0 || bal >= price)
            inv.setItem(11, item(Material.LIME_CONCRETE, price == 0 ? "&a&l\u2714 UNLOCK (FREE)" : "&a&l\u2714 UNLOCK", null, false));
        else
            inv.setItem(11, item(Material.GRAY_CONCRETE, "&8\u2718 Not enough coins",
                    List.of("&7You need &c" + fmt(price - bal) + " \u26C3 &7more."), false));
        inv.setItem(15, item(Material.RED_CONCRETE, "&cCancel", null, false));
        fill(inv);
        p.openInventory(inv);
    }

    private void startRename(Player p, String key) {
        renaming.put(p.getUniqueId(), key);
        p.closeInventory();
        p.sendMessage(ChatColor.GOLD + "\u270E Type the new vault name in chat "
                + ChatColor.GRAY + "(max 20 chars, or type " + ChatColor.WHITE + "cancel" + ChatColor.GRAY + ")"
                + (renamePrice() > 0 ? ChatColor.GRAY + " - costs " + ChatColor.YELLOW + fmt(renamePrice()) + " \u26C3" : ""));
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent e) {
        String key = renaming.remove(e.getPlayer().getUniqueId());
        if (key == null) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        String raw = ChatColor.stripColor(e.getMessage()).trim();
        Bukkit.getScheduler().runTask(this, () -> {
            if (raw.equalsIgnoreCase("cancel") || raw.isEmpty()) {
                p.sendMessage(ChatColor.GRAY + "Rename cancelled.");
                return;
            }
            String name = raw.length() > 20 ? raw.substring(0, 20) : raw;
            long fee = renamePrice();
            if (fee > 0) {
                if (econ == null || econ.getBalance(p) < fee) {
                    p.sendMessage(ChatColor.RED + "You need " + fmt(fee) + " \u26C3 to rename.");
                    return;
                }
                econ.withdrawPlayer(p, fee);
            }
            data.set("chests." + key + ".name", name);
            save();
            spawnChestHolo(key);
            p.sendMessage(ChatColor.GREEN + "\u2714 Vault renamed to " + ChatColor.WHITE + "[" + name + "]");
            p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.4f);
        });
    }

    /* ---------------- protect owned chests ---------------- */

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (!inVaultInterior(b.getLocation())) return;
        Player p = e.getPlayer();
        boolean adminCreative = p.hasPermission("mavovault.admin") && p.getGameMode() == GameMode.CREATIVE;
        // inside the vault, NOTHING is breakable except by admin creative - rooms stay intact
        if (!adminCreative) {
            e.setCancelled(true);
            if (b.getType() == Material.CHEST || b.getType() == Material.BIRCH_DOOR)
                p.sendMessage(ChatColor.RED + "Vault rooms can't be broken.");
        }
    }

    /** safety net: block hoppers etc. is overkill at spawn, but block non-owner inventory opens too */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onOpen(InventoryOpenEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        Location loc = e.getInventory().getLocation();
        if (loc == null || !inVaultInterior(loc)) return;
        Block b = loc.getBlock();
        if (b.getType() != Material.CHEST && b.getType() != Material.TRAPPED_CHEST) return;
        boolean adminCreative = p.hasPermission("mavovault.admin") && p.getGameMode() == GameMode.CREATIVE;
        Room r = roomAt(b);
        if (r == null) { if (!adminCreative) e.setCancelled(true); return; }
        String owner = roomOwner(r.id);
        if (owner == null) { if (!adminCreative) e.setCancelled(true); return; }
        if (!owner.equals(p.getUniqueId().toString()) && !adminCreative) { e.setCancelled(true); return; }
        Integer unit = r.unitAt.get(pack(b.getX(), b.getZ()));
        if (unit == null || !unlockedSlots(r.id).contains(unit))
            if (!adminCreative) e.setCancelled(true);
    }

    /* ---------------- teaser portals (Vault / Portal Room - coming soon) ---------------- */

    private boolean inPortal(String id, Location l) {
        String base = "portals." + id + ".";
        String w = getConfig().getString(base + "world", null);
        if (w == null || l.getWorld() == null || !l.getWorld().getName().equals(w)) return false;
        double x1 = getConfig().getDouble(base + "x1"), x2 = getConfig().getDouble(base + "x2");
        double y1 = getConfig().getDouble(base + "y1"), y2 = getConfig().getDouble(base + "y2");
        double z1 = getConfig().getDouble(base + "z1"), z2 = getConfig().getDouble(base + "z2");
        return l.getX() >= Math.min(x1, x2) && l.getX() <= Math.max(x1, x2) + 1
                && l.getY() >= Math.min(y1, y2) && l.getY() <= Math.max(y1, y2) + 1
                && l.getZ() >= Math.min(z1, z2) && l.getZ() <= Math.max(z1, z2) + 1;
    }

    private boolean portalDefined(String id) {
        return getConfig().getString("portals." + id + ".world", null) != null;
    }

    /** Fill the whole portal volume with themed particles.
     *  vault: pitch black veil + white sparkles. portalroom: deep red veil + yellow sparkles. */
    private void fxLoop() {
        fxTick += 2;
        renderTeaser("vault", Color.fromRGB(5, 5, 8), Particle.END_ROD);
        renderTeaser("portalroom", Color.fromRGB(200, 20, 20), Particle.WAX_OFF);
        // return-to-spawn portals inside the rooms: green/gold, matches the Home Portal theme
        renderTeaser("vault_return", Color.fromRGB(15, 150, 55), Particle.WAX_OFF);
        renderTeaser("portalroom_return", Color.fromRGB(15, 150, 55), Particle.WAX_OFF);
    }

    private boolean isReturnId(String id) { return id != null && id.endsWith("_return"); }

    private void renderTeaser(String id, Color veil, Particle sparkle) {
        if (!portalDefined(id)) return;
        String base = "portals." + id + ".";
        World w = Bukkit.getWorld(getConfig().getString(base + "world", ""));
        if (w == null) return;
        double x1 = Math.min(getConfig().getDouble(base + "x1"), getConfig().getDouble(base + "x2"));
        double x2 = Math.max(getConfig().getDouble(base + "x1"), getConfig().getDouble(base + "x2")) + 1;
        double y1 = Math.min(getConfig().getDouble(base + "y1"), getConfig().getDouble(base + "y2"));
        double y2 = Math.max(getConfig().getDouble(base + "y1"), getConfig().getDouble(base + "y2")) + 1;
        double z1 = Math.min(getConfig().getDouble(base + "z1"), getConfig().getDouble(base + "z2"));
        double z2 = Math.max(getConfig().getDouble(base + "z1"), getConfig().getDouble(base + "z2")) + 1;
        double cx = (x1 + x2) / 2, cy = (y1 + y2) / 2, cz = (z1 + z2) / 2;
        boolean near = false;
        for (Player p : w.getPlayers()) {
            Location l = p.getLocation();
            if (Math.abs(l.getX() - cx) < 44 && Math.abs(l.getZ() - cz) < 44) { near = true; break; }
        }
        if (!near) return;
        double sx = x2 - x1, sy = y2 - y1, sz = z2 - z1;
        double vol = Math.max(1, sx * sy * sz);
        // dense colored veil filling the volume
        if (fxTick % 4 == 0) {
            int n = (int) Math.min(80, Math.max(18, vol * 2.2));
            for (int i = 0; i < n; i++) {
                double px = x1 + rng.nextDouble() * sx;
                double py = y1 + rng.nextDouble() * sy;
                double pz = z1 + rng.nextDouble() * sz;
                w.spawnParticle(Particle.DUST, px, py, pz, 1, 0.04, 0.04, 0.04, 0,
                        new Particle.DustOptions(veil, 1.6f));
            }
        }
        // bright sparkles drifting through it
        if (fxTick % 6 == 0) {
            int n = (int) Math.min(14, Math.max(4, vol / 3));
            for (int i = 0; i < n; i++) {
                double px = x1 + rng.nextDouble() * sx;
                double py = y1 + rng.nextDouble() * sy;
                double pz = z1 + rng.nextDouble() * sz;
                w.spawnParticle(sparkle, px, py, pz, 1, 0.02, 0.02, 0.02, 0.01);
            }
        }
        // slow swirl in the middle plane for depth
        double maxR = Math.min(Math.max(sx, sz), sy) / 2.0 - 0.2;
        for (double r = 0.4; r < maxR; r += 0.8) {
            double ang = fxTick * 0.09 + r * 1.1;
            boolean thinZ = sz <= sx;
            double du = Math.cos(ang) * r, dv = Math.sin(ang) * r;
            double px = thinZ ? cx + du : cx, py = cy + dv, pz = thinZ ? cz : cz + du;
            w.spawnParticle(Particle.DUST, px, py, pz, 1, 0, 0, 0, 0,
                    new Particle.DustOptions(isReturnId(id) ? Color.fromRGB(255, 215, 60)
                            : id.equals("vault") ? Color.fromRGB(240, 240, 255) : Color.fromRGB(255, 210, 40), 1.1f));
        }
        // low hum
        if (fxTick % 100 == 0) {
            Location c = new Location(w, cx, cy, cz);
            for (Player p : w.getPlayers())
                if (p.getLocation().distanceSquared(c) < 400)
                    p.playSound(c, Sound.BLOCK_PORTAL_AMBIENT, 0.25f, id.equals("vault") ? 0.55f : 0.8f);
        }
    }

    /** every 10 ticks: track who stands inside a portal. ALL portals are active now:
     *  plaza portals (vault/portalroom): need gate access (GUI offered if locked), 3s countdown, teleport into room.
     *  return portals (vault_return/portalroom_return): 3s countdown, teleport back to spawn. */
    private void countdownLoop() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            String in = null;
            for (String id : List.of("vault", "portalroom", "vault_return", "portalroom_return"))
                if (portalDefined(id) && inPortal(id, p.getLocation())) { in = id; break; }
            UUID u = p.getUniqueId();
            if (in == null) {
                if (countdown.remove(u) != null) p.sendTitle(" ", "", 0, 1, 0); // step-out = instant cancel
                continue;
            }
            long now = System.currentTimeMillis();
            boolean ret = isReturnId(in);
            // plaza gate portals: must own access first -> open the unlock GUI instead of counting
            if (!ret && !hasAccess(p, in)) {
                countdown.remove(u);
                Long cd = soonCooldown.get(u);
                if (cd != null && now - cd < 8000) continue; // GUI just shown; don't spam-reopen
                soonCooldown.put(u, now);
                p.playSound(p.getLocation(), Sound.BLOCK_CHEST_LOCKED, 1f, 0.8f);
                openGateGui(p, in);
                p.sendMessage(gateName(in) + ChatColor.YELLOW + " - unlock access, then step into the portal again.");
                continue;
            }
            // adventure rules: creative is exempt -> instant
            if (p.getGameMode() == org.bukkit.GameMode.CREATIVE) {
                countdown.remove(u);
                if (ret) returnToSpawn(p); else teleportToRoom(p, in);
                continue;
            }
            // blocked while hostile monsters within 12 blocks
            boolean danger = p.getLocation().getWorld().getNearbyEntities(p.getLocation(), 12, 12, 12).stream()
                    .anyMatch(en -> en instanceof org.bukkit.entity.Monster);
            if (danger) {
                countdown.remove(u);
                p.sendTitle(ChatColor.RED + "" + ChatColor.BOLD + "\u2716",
                        ChatColor.RED + "Monsters nearby - clear them first!", 0, 15, 5);
                continue;
            }
            int t = countdown.merge(u, 10, Integer::sum); // ticks accumulated
            int total = 3;
            int secLeft = total - (t / 20);
            if (t % 20 == 0 && secLeft > 0) {
                ChatColor col = ret ? ChatColor.GREEN : in.equals("vault") ? ChatColor.WHITE : ChatColor.RED;
                p.sendTitle(col + "" + ChatColor.BOLD + secLeft,
                        ChatColor.GRAY + (ret ? "Returning to spawn... step out to cancel"
                                : "Entering " + ChatColor.stripColor(gateName(in)) + "... step out to cancel"),
                        0, 25, 5);
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 0.9f + (total - secLeft) * 0.15f);
            }
            if (t >= total * 20) {
                countdown.remove(u);
                if (ret) returnToSpawn(p); else teleportToRoom(p, in);
            }
        }
    }

    /** Teleport into the Vault / Portal Room (config portal-dest.<id>.*, with sane built-in fallbacks). */
    private void teleportToRoom(Player p, String id) {
        String base = "portal-dest." + id + ".";
        String w = getConfig().getString(base + "world", null);
        World world = w == null ? p.getWorld() : Bukkit.getWorld(w);
        if (world == null) world = p.getWorld();
        Location dest;
        if (w != null) {
            dest = new Location(world, getConfig().getDouble(base + "x"), getConfig().getDouble(base + "y"),
                    getConfig().getDouble(base + "z"), (float) getConfig().getDouble(base + "yaw", 0.0), 0f);
        } else if (id.equals("vault")) {
            dest = new Location(world, -2704.5, 200, -1684.5, 90f, 0f);   // just inside the east door, facing in
        } else {
            dest = new Location(world, -2445.5, 200, -1684.5, -90f, 0f);  // just inside the west door, facing in
        }
        dest.getChunk().load();
        p.playSound(p.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 0.5f, id.equals("vault") ? 0.7f : 1.1f);
        p.teleport(dest);
        p.sendTitle(gateName(id), ChatColor.GRAY + (id.equals("vault")
                ? "Your treasures await" : "Choose your destination... soon"), 5, 40, 10);
        p.playSound(dest, Sound.ENTITY_PLAYER_TELEPORT, 1f, 1f);
    }

    /** Teleport to the configured return point (config return-spawn.*), falling back to world spawn. */
    private void returnToSpawn(Player p) {
        Location dest;
        String w = getConfig().getString("return-spawn.world", null);
        World world = w == null ? null : Bukkit.getWorld(w);
        if (world != null) {
            dest = new Location(world,
                    getConfig().getDouble("return-spawn.x"),
                    getConfig().getDouble("return-spawn.y"),
                    getConfig().getDouble("return-spawn.z"),
                    (float) getConfig().getDouble("return-spawn.yaw", 0.0), 0f);
        } else {
            World def = p.getWorld();
            dest = def.getSpawnLocation().add(0.5, 0, 0.5);
        }
        p.playSound(p.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 0.5f, 1.4f);
        p.teleport(dest);
        p.sendTitle(ChatColor.GREEN + "" + ChatColor.BOLD + "\u2714",
                ChatColor.GRAY + "Welcome back to spawn", 5, 30, 10);
        p.playSound(dest, Sound.ENTITY_PLAYER_TELEPORT, 1f, 1f);
    }

    /* ---------------- portal holos ---------------- */

    private void spawnPortalHolo(String id) {
        if (!portalDefined(id)) return;
        String base = "portals." + id + ".";
        World w = Bukkit.getWorld(getConfig().getString(base + "world", ""));
        if (w == null) return;
        double cx = (getConfig().getDouble(base + "x1") + getConfig().getDouble(base + "x2")) / 2.0 + 0.5;
        double topY = Math.max(getConfig().getDouble(base + "y1"), getConfig().getDouble(base + "y2"));
        double cz = (getConfig().getDouble(base + "z1") + getConfig().getDouble(base + "z2")) / 2.0 + 0.5;
        Location loc = new Location(w, cx, topY + 2.0, cz);
        loc.getChunk().load();
        for (Entity ent : w.getNearbyEntities(loc, 6, 6, 6))
            if (ent instanceof TextDisplay && ent.getPersistentDataContainer().has(holoKey, PersistentDataType.BYTE)
                    && ent.getPersistentDataContainer().has(new NamespacedKey(this, "portalholo_" + id), PersistentDataType.BYTE))
                ent.remove();
        NamespacedKey idKey = new NamespacedKey(this, "portalholo_" + id);
        if (isReturnId(id)) {
            String text = ChatColor.GREEN + "" + ChatColor.BOLD + "\u2302 BACK TO SPAWN \u2302"
                    + "\n" + ChatColor.GRAY + "Stand inside for 3 seconds";
            spawnHoloDisplay(w, loc, text, idKey, true);
            return;
        }
        // gate portals: TWO stacked holos - "unlocked" (default visible) and
        // "locked" (default hidden); a per-player visibility task shows the right one.
        String open = id.equals("vault")
                ? ChatColor.GOLD + "" + ChatColor.BOLD + "\u2666 THE VAULT \u2666"
                    + "\n" + ChatColor.GREEN + "" + ChatColor.BOLD + "\u2714 UNLOCKED"
                    + "\n" + ChatColor.GRAY + "Private chests for your treasures"
                    + "\n" + ChatColor.GRAY + "Stand inside for 3 seconds"
                : ChatColor.AQUA + "" + ChatColor.BOLD + "\u25C9 PORTAL ROOM \u25C9"
                    + "\n" + ChatColor.GREEN + "" + ChatColor.BOLD + "\u2714 UNLOCKED"
                    + "\n" + ChatColor.GRAY + "Biome jumps \u00B7 cave dives \u00B7 and more"
                    + "\n" + ChatColor.GRAY + "Stand inside for 3 seconds";
        String locked = id.equals("vault")
                ? ChatColor.GOLD + "" + ChatColor.BOLD + "\u2666 THE VAULT \u2666"
                    + "\n" + ChatColor.RED + "" + ChatColor.BOLD + "\uD83D\uDD12 LOCKED"
                    + "\n" + ChatColor.GRAY + "One-time entry: " + ChatColor.YELLOW + fmt(gatePrice("vault")) + " \u26C3"
                    + "\n" + ChatColor.GRAY + "Step in to unlock \u00B7 yours forever"
                : ChatColor.AQUA + "" + ChatColor.BOLD + "\u25C9 PORTAL ROOM \u25C9"
                    + "\n" + ChatColor.RED + "" + ChatColor.BOLD + "\uD83D\uDD12 LOCKED"
                    + "\n" + ChatColor.GRAY + "One-time entry: " + ChatColor.YELLOW + fmt(gatePrice("portalroom")) + " \u26C3"
                    + "\n" + ChatColor.GRAY + "Step in to unlock \u00B7 yours forever";
        TextDisplay openTd = spawnHoloDisplay(w, loc, open, idKey, true);
        TextDisplay lockTd = spawnHoloDisplay(w, loc, locked, idKey, false);
        gateHolos.put(id, new UUID[]{openTd.getUniqueId(), lockTd.getUniqueId()});
    }

    private TextDisplay spawnHoloDisplay(World w, Location loc, String text, NamespacedKey idKey, boolean visibleDefault) {
        return w.spawn(loc, TextDisplay.class, d -> {
            d.setText(text);
            d.setBillboard(Display.Billboard.CENTER);
            d.setShadowed(true);
            d.setSeeThrough(true);
            try { d.setDefaultBackground(false); d.setBackgroundColor(Color.fromARGB(200, 10, 10, 20)); } catch (Throwable ignored) {}
            d.setAlignment(TextDisplay.TextAlignment.CENTER);
            d.setLineWidth(260);
            var tr = d.getTransformation();
            tr.getScale().set(1.9f);
            d.setTransformation(tr);
            d.setViewRange(1.2f);
            try { d.setBrightness(new Display.Brightness(15, 15)); } catch (Throwable ignored) {}
            d.setPersistent(true);
            d.setVisibleByDefault(visibleDefault);
            d.getPersistentDataContainer().set(holoKey, PersistentDataType.BYTE, (byte) 1);
            d.getPersistentDataContainer().set(idKey, PersistentDataType.BYTE, (byte) 1);
        });
    }

    /** every 2s: show each online player the correct holo variant (locked/unlocked) per gate */
    private void holoVisibilityLoop() {
        for (Map.Entry<String, UUID[]> en : gateHolos.entrySet()) {
            Entity open = Bukkit.getEntity(en.getValue()[0]);
            Entity lock = Bukkit.getEntity(en.getValue()[1]);
            if (open == null || lock == null) continue;
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getWorld() != open.getWorld()) continue;
                if (p.getLocation().distanceSquared(open.getLocation()) > 4096) continue; // 64 blocks
                boolean has = hasAccessRaw(p, en.getKey());
                if (has) { p.showEntity(this, open); p.hideEntity(this, lock); }
                else { p.hideEntity(this, open); p.showEntity(this, lock); }
            }
        }
    }

    /* ---------------- GUI clicks ---------------- */

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getRawSlot() >= e.getInventory().getSize()) return;
        int slot = e.getRawSlot();
        if (slot == 15) { p.closeInventory(); return; }
        if (slot != 11) return;

        if (h.kind.equals("gate")) {
            long price = gatePrice(h.gateId);
            if (hasAccess(p, h.gateId)) { p.closeInventory(); return; }
            if (econ == null || econ.getBalance(p) < price) {
                p.sendMessage(ChatColor.RED + "Not enough coins - you need " + fmt(price) + " \u26C3.");
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 0.8f);
                return;
            }
            econ.withdrawPlayer(p, price);
            grantAccess(p.getUniqueId(), h.gateId);
            p.closeInventory();
            p.playSound(p.getLocation(), Sound.BLOCK_END_PORTAL_FRAME_FILL, 1f, 1.2f);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            p.sendMessage(ChatColor.GOLD + "\u2714 " + gateName(h.gateId) + ChatColor.GREEN
                    + " unlocked forever! " + ChatColor.GRAY + "(-" + fmt(price) + " \u26C3)");
            Bukkit.broadcastMessage(ChatColor.AQUA + p.getName() + ChatColor.GRAY + " unlocked "
                    + gateName(h.gateId) + ChatColor.GRAY + "!");
            return;
        }

        if (h.kind.equals("room")) {
            long price = chestPrice();
            if (roomOwner(h.roomId) != null) { p.closeInventory(); return; } // raced
            if (roomOfPlayer(p.getUniqueId()) != null) { p.closeInventory(); return; }
            if (econ == null || econ.getBalance(p) < price) {
                p.sendMessage(ChatColor.RED + "Not enough coins - you need " + fmt(price) + " \u26C3.");
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 0.8f);
                return;
            }
            econ.withdrawPlayer(p, price);
            data.set("rooms." + h.roomId + ".owner", p.getUniqueId().toString());
            data.set("rooms." + h.roomId + ".slots", List.of(0)); // slot #1 free
            data.set("playerroom." + p.getUniqueId(), h.roomId);
            save();
            Room r = rooms.get(h.roomId);
            if (r != null) writeRoomSign(r, p.getName());
            p.closeInventory();
            p.playSound(p.getLocation(), Sound.BLOCK_END_PORTAL_FRAME_FILL, 1f, 1.1f);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            p.sendMessage(ChatColor.GOLD + "\u2714 Vault Room " + h.roomId + ChatColor.GREEN
                    + " is yours forever! " + ChatColor.GRAY + "(-" + fmt(price) + " \u26C3) First chest slot is FREE - right-click a chest inside.");
            Bukkit.broadcastMessage(ChatColor.GOLD + p.getName() + ChatColor.GRAY + " claimed private Vault Room "
                    + ChatColor.GOLD + h.roomId + ChatColor.GRAY + "!");
            return;
        }

        if (h.kind.equals("slot")) {
            Room r = rooms.get(h.roomId);
            if (r == null) { p.closeInventory(); return; }
            String owner = roomOwner(h.roomId);
            if (owner == null || !owner.equals(p.getUniqueId().toString())) { p.closeInventory(); return; }
            List<Integer> slots = new ArrayList<>(unlockedSlots(h.roomId));
            if (slots.contains(h.slotUnit)) { p.closeInventory(); return; } // raced
            long price = nextSlotPrice(h.roomId);
            if (price < 0) { p.closeInventory(); return; }
            if (price > 0) {
                if (econ == null || econ.getBalance(p) < price) {
                    p.sendMessage(ChatColor.RED + "Not enough coins - you need " + fmt(price) + " \u26C3.");
                    p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 0.8f);
                    return;
                }
                econ.withdrawPlayer(p, price);
            }
            slots.add(h.slotUnit);
            data.set("rooms." + h.roomId + ".slots", slots);
            save();
            p.closeInventory();
            p.playSound(p.getLocation(), Sound.BLOCK_CHEST_LOCKED, 1f, 1.4f);
            p.sendMessage(ChatColor.GREEN + "\u2714 Vault slot #" + slots.size() + " unlocked"
                    + (price > 0 ? ChatColor.GRAY + " (-" + fmt(price) + " \u26C3)" : ChatColor.GRAY + " (free)")
                    + ChatColor.GRAY + " - " + (15 - slots.size()) + " sealed slots left"
                    + (slots.size() < 15 ? ", next costs " + ChatColor.YELLOW + fmt(nextSlotPrice(h.roomId)) + " \u26C3" : ""));
        }
    }

    /* ---------------- items / util ---------------- */

    private ItemStack item(Material m, String name, List<String> lore, boolean glow) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return it;
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        if (lore != null) {
            List<String> l = new ArrayList<>();
            for (String s : lore) l.add(ChatColor.translateAlternateColorCodes('&', s));
            meta.setLore(l);
        }
        if (glow) meta.setEnchantmentGlintOverride(true);
        meta.addItemFlags(org.bukkit.inventory.ItemFlag.values());
        it.setItemMeta(meta);
        return it;
    }

    private void fill(Inventory inv) {
        ItemStack pane = item(Material.BLACK_STAINED_GLASS_PANE, " ", null, false);
        for (int i = 0; i < inv.getSize(); i++) if (inv.getItem(i) == null) inv.setItem(i, pane);
    }

    private String fmt(long n) { return String.format(Locale.UK, "%,d", n); }

    /* ---------------- command ---------------- */

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0) {
            if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
            boolean v = hasAccessRaw(p, "vault"), pr = hasAccessRaw(p, "portalroom");
            p.sendMessage(ChatColor.GOLD + "\u2666 Vault access: " + (v ? ChatColor.GREEN + "UNLOCKED" : ChatColor.RED + "locked (" + fmt(gatePrice("vault")) + " \u26C3)"));
            p.sendMessage(ChatColor.AQUA + "\u25C9 Portal Room access: " + (pr ? ChatColor.GREEN + "UNLOCKED" : ChatColor.RED + "locked (" + fmt(gatePrice("portalroom")) + " \u26C3)"));
            int mine = 0;
            var sec = data.getConfigurationSection("chests");
            if (sec != null) for (String k : sec.getKeys(false))
                if (p.getUniqueId().toString().equals(ownerOf(k))) mine++;
            p.sendMessage(ChatColor.GRAY + "Your vault chests: " + ChatColor.WHITE + mine);
            return true;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        if (!s.hasPermission("mavovault.admin")) { s.sendMessage(ChatColor.RED + "No permission."); return true; }

        switch (sub) {
            case "reload" -> {
                reloadConfig();
                spawnPortalHolo("vault");
                spawnPortalHolo("portalroom");
                spawnPortalHolo("vault_return");
                spawnPortalHolo("portalroom_return");
                s.sendMessage(ChatColor.GREEN + "MAVOVault reloaded.");
            }
            case "pos1", "pos2" -> {
                if (!(s instanceof Player p)) { s.sendMessage("In-game only."); return true; }
                Location[] buf = setup.computeIfAbsent(p.getUniqueId(), k -> new Location[2]);
                buf[sub.equals("pos1") ? 0 : 1] = p.getLocation().getBlock().getLocation();
                s.sendMessage(ChatColor.GREEN + sub + " set at " + fmtLoc(p.getLocation()) + ChatColor.GRAY
                        + " - now /vaultroom gate <vault|portalroom>");
            }
            case "gate" -> {
                if (!(s instanceof Player p)) { s.sendMessage("In-game only."); return true; }
                if (a.length < 2 || (!a[1].equalsIgnoreCase("vault") && !a[1].equalsIgnoreCase("portalroom"))) {
                    s.sendMessage(ChatColor.RED + "/vaultroom gate <vault|portalroom> - after pos1+pos2");
                    return true;
                }
                Location[] buf = setup.get(p.getUniqueId());
                if (buf == null || buf[0] == null || buf[1] == null) {
                    s.sendMessage(ChatColor.RED + "Set /vaultroom pos1 and pos2 first (opposite corners of the doorway/room).");
                    return true;
                }
                String id = a[1].toLowerCase(Locale.ROOT);
                String base = "gates." + id + ".region.";
                getConfig().set(base + "world", buf[0].getWorld().getName());
                getConfig().set(base + "x1", buf[0].getX()); getConfig().set(base + "y1", buf[0].getY()); getConfig().set(base + "z1", buf[0].getZ());
                getConfig().set(base + "x2", buf[1].getX()); getConfig().set(base + "y2", buf[1].getY()); getConfig().set(base + "z2", buf[1].getZ());
                saveConfig();
                s.sendMessage(ChatColor.GREEN + "\u2714 " + gateName(id) + ChatColor.GREEN + " region saved. Price: "
                        + ChatColor.YELLOW + fmt(gatePrice(id)) + " \u26C3");
            }
            case "portal" -> {
                if (!(s instanceof Player p)) { s.sendMessage("In-game only."); return true; }
                List<String> validIds = List.of("vault", "portalroom", "vault_return", "portalroom_return");
                if (a.length < 2 || !validIds.contains(a[1].toLowerCase(Locale.ROOT))) {
                    s.sendMessage(ChatColor.RED + "/vaultroom portal <vault|portalroom|vault_return|portalroom_return> - after pos1+pos2");
                    return true;
                }
                Location[] buf = setup.get(p.getUniqueId());
                if (buf == null || buf[0] == null || buf[1] == null) {
                    s.sendMessage(ChatColor.RED + "Set /vaultroom pos1 (bottom corner) and pos2 (opposite top corner) first.");
                    return true;
                }
                String id = a[1].toLowerCase(Locale.ROOT);
                String base = "portals." + id + ".";
                getConfig().set(base + "world", buf[0].getWorld().getName());
                getConfig().set(base + "x1", buf[0].getX()); getConfig().set(base + "y1", buf[0].getY()); getConfig().set(base + "z1", buf[0].getZ());
                getConfig().set(base + "x2", buf[1].getX()); getConfig().set(base + "y2", buf[1].getY()); getConfig().set(base + "z2", buf[1].getZ());
                saveConfig();
                spawnPortalHolo(id);
                s.sendMessage(isReturnId(id)
                        ? ChatColor.GREEN + "\u2714 Return portal saved (" + id + ") - green FX, 3s countdown, teleports to spawn."
                        : ChatColor.GREEN + "\u2714 Portal saved for " + gateName(id) + ChatColor.GREEN
                            + " - ACTIVE: gate check + 3s countdown + teleport into the room.");
            }
            case "portalremove" -> {
                List<String> validIds = List.of("vault", "portalroom", "vault_return", "portalroom_return");
                if (a.length < 2 || !validIds.contains(a[1].toLowerCase(Locale.ROOT))) {
                    s.sendMessage(ChatColor.RED + "/vaultroom portalremove <vault|portalroom|vault_return|portalroom_return>");
                    return true;
                }
                String id = a[1].toLowerCase(Locale.ROOT);
                if (!portalDefined(id)) { s.sendMessage(ChatColor.RED + "That portal is not set."); return true; }
                // sweep its holo (PDC-tagged) near the stored region
                String base = "portals." + id + ".";
                World w = Bukkit.getWorld(getConfig().getString(base + "world", ""));
                if (w != null) {
                    double cx = (getConfig().getDouble(base + "x1") + getConfig().getDouble(base + "x2")) / 2.0;
                    double ty = Math.max(getConfig().getDouble(base + "y1"), getConfig().getDouble(base + "y2"));
                    double cz = (getConfig().getDouble(base + "z1") + getConfig().getDouble(base + "z2")) / 2.0;
                    Location hl = new Location(w, cx, ty + 2.0, cz);
                    hl.getChunk().load();
                    NamespacedKey idKey = new NamespacedKey(this, "portalholo_" + id);
                    for (Entity ent : w.getNearbyEntities(hl, 8, 8, 8))
                        if (ent instanceof TextDisplay && ent.getPersistentDataContainer().has(idKey, PersistentDataType.BYTE))
                            ent.remove();
                }
                getConfig().set("portals." + id, null);
                saveConfig();
                s.sendMessage(ChatColor.GREEN + "\u2714 Portal '" + id + "' removed (FX + holo gone). Redo with pos1/pos2 + /vaultroom portal " + id);
            }
            case "portaldest" -> {
                if (!(s instanceof Player p)) { s.sendMessage("In-game only."); return true; }
                if (a.length < 2 || (!a[1].equalsIgnoreCase("vault") && !a[1].equalsIgnoreCase("portalroom"))) {
                    s.sendMessage(ChatColor.RED + "/vaultroom portaldest <vault|portalroom> - stand at the arrival spot first");
                    return true;
                }
                String id = a[1].toLowerCase(Locale.ROOT);
                Location dl = p.getLocation();
                String base = "portal-dest." + id + ".";
                getConfig().set(base + "world", dl.getWorld().getName());
                getConfig().set(base + "x", dl.getX());
                getConfig().set(base + "y", dl.getY());
                getConfig().set(base + "z", dl.getZ());
                getConfig().set(base + "yaw", (double) dl.getYaw());
                saveConfig();
                s.sendMessage(ChatColor.GREEN + "\u2714 " + gateName(id) + ChatColor.GREEN
                        + " arrival point set to your position (" + fmtLoc(dl) + ", facing kept).");
            }
            case "releaseroom" -> {
                if (a.length < 2) { s.sendMessage(ChatColor.RED + "/vaultroom releaseroom <roomId|player>"); return true; }
                String rid = a[1].toUpperCase(Locale.ROOT);
                if (!rooms.containsKey(rid)) {
                    var op = Bukkit.getOfflinePlayer(a[1]);
                    String pr = op == null ? null : roomOfPlayer(op.getUniqueId());
                    if (pr == null) { s.sendMessage(ChatColor.RED + "No such room or player-room: " + a[1]); return true; }
                    rid = pr;
                }
                String o = roomOwner(rid);
                if (o != null) data.set("playerroom." + o, null);
                data.set("rooms." + rid, null);
                save();
                Room rr = rooms.get(rid);
                if (rr != null) writeRoomSign(rr, null);
                s.sendMessage(ChatColor.GREEN + "\u2714 Room " + rid + " released (chests keep their items; slots reset).");
            }
            case "roominfo" -> {
                int owned = 0;
                StringBuilder sb2 = new StringBuilder();
                for (Room rr : rooms.values()) {
                    String o = roomOwner(rr.id);
                    if (o != null) {
                        owned++;
                        var op = Bukkit.getOfflinePlayer(UUID.fromString(o));
                        sb2.append(ChatColor.GOLD).append(rr.id).append(ChatColor.GRAY).append("=")
                           .append(op.getName() != null ? op.getName() : "?")
                           .append("(").append(unlockedSlots(rr.id).size()).append("/15) ");
                    }
                }
                s.sendMessage(ChatColor.GOLD + "Vault rooms: " + owned + "/96 claimed.");
                if (owned > 0) s.sendMessage(sb2.toString());
            }
            case "signs" -> {
                refreshAllSigns();
                s.sendMessage(ChatColor.GREEN + "\u2714 All 96 room door signs rewritten.");
            }
            case "returnspawn" -> {
                if (!(s instanceof Player p)) { s.sendMessage("In-game only."); return true; }
                Location rl = p.getLocation();
                getConfig().set("return-spawn.world", rl.getWorld().getName());
                getConfig().set("return-spawn.x", rl.getX());
                getConfig().set("return-spawn.y", rl.getY());
                getConfig().set("return-spawn.z", rl.getZ());
                getConfig().set("return-spawn.yaw", (double) rl.getYaw());
                saveConfig();
                s.sendMessage(ChatColor.GREEN + "\u2714 Return-portal destination set to your position ("
                        + fmtLoc(rl) + ", facing kept).");
            }
            case "price" -> {
                if (a.length < 3) { s.sendMessage(ChatColor.RED + "/vaultroom price <vault|portalroom> <coins>"); return true; }
                try {
                    getConfig().set("gates." + a[1].toLowerCase(Locale.ROOT) + ".price", Long.parseLong(a[2]));
                    saveConfig();
                    s.sendMessage(ChatColor.GREEN + "Price set.");
                } catch (NumberFormatException ex) { s.sendMessage(ChatColor.RED + "Bad number."); }
            }
            case "chestprice" -> {
                if (a.length < 2) { s.sendMessage(ChatColor.RED + "/vaultroom chestprice <coins>"); return true; }
                try { getConfig().set("chest-price", Long.parseLong(a[1])); saveConfig(); s.sendMessage(ChatColor.GREEN + "Chest price set."); }
                catch (NumberFormatException ex) { s.sendMessage(ChatColor.RED + "Bad number."); }
            }
            case "renameprice" -> {
                if (a.length < 2) { s.sendMessage(ChatColor.RED + "/vaultroom renameprice <coins>"); return true; }
                try { getConfig().set("rename-price", Long.parseLong(a[1])); saveConfig(); s.sendMessage(ChatColor.GREEN + "Rename price set."); }
                catch (NumberFormatException ex) { s.sendMessage(ChatColor.RED + "Bad number."); }
            }
            case "grant", "revoke" -> {
                if (a.length < 3) { s.sendMessage(ChatColor.RED + "/vaultroom " + sub + " <vault|portalroom> <player>"); return true; }
                var op = Bukkit.getOfflinePlayer(a[2]);
                String id = a[1].toLowerCase(Locale.ROOT);
                List<String> lst = data.getStringList("access." + id);
                if (sub.equals("grant")) { if (!lst.contains(op.getUniqueId().toString())) lst.add(op.getUniqueId().toString()); }
                else lst.remove(op.getUniqueId().toString());
                data.set("access." + id, lst); save();
                s.sendMessage(ChatColor.GREEN + sub + " done for " + a[2] + " on " + id + ".");
            }
            case "release" -> {
                if (!(s instanceof Player p)) { s.sendMessage("In-game only."); return true; }
                Block target = p.getTargetBlockExact(6);
                if (target == null || (target.getType() != Material.CHEST && target.getType() != Material.TRAPPED_CHEST)) {
                    s.sendMessage(ChatColor.RED + "Look at a vault chest within 6 blocks.");
                    return true;
                }
                String key = chestKey(primaryHalf(target));
                if (ownerOf(key) == null) { s.sendMessage(ChatColor.RED + "That chest isn't claimed."); return true; }
                removeChestHolo(key);
                data.set("chests." + key, null); save();
                s.sendMessage(ChatColor.GREEN + "Chest released - it can be bought again.");
            }
            default -> s.sendMessage(ChatColor.RED + "Subcommands: pos1 pos2 gate portal portalremove portaldest returnspawn releaseroom roominfo signs price chestprice renameprice grant revoke release reload");
        }
        return true;
    }

    private boolean hasAccessRaw(Player p, String id) {
        return data.getStringList("access." + id).contains(p.getUniqueId().toString());
    }

    private String fmtLoc(Location l) {
        return l.getBlockX() + " " + l.getBlockY() + " " + l.getBlockZ();
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("mavovault.admin")) return List.of();
        if (a.length == 1) {
            List<String> out = new ArrayList<>();
            for (String x : List.of("pos1", "pos2", "gate", "portal", "portalremove", "portaldest", "returnspawn", "releaseroom", "roominfo", "signs", "price", "chestprice", "renameprice", "grant", "revoke", "release", "reload"))
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
            return out;
        }
        if (a.length == 2 && List.of("portal", "portalremove").contains(a[0].toLowerCase(Locale.ROOT)))
            return List.of("vault", "portalroom", "vault_return", "portalroom_return");
        if (a.length == 2 && List.of("gate", "portaldest", "price", "grant", "revoke").contains(a[0].toLowerCase(Locale.ROOT)))
            return List.of("vault", "portalroom");
        return List.of();
    }
}
