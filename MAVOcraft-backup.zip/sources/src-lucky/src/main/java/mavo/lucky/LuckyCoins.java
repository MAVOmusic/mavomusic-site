package mavo.lucky;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public final class LuckyCoins extends JavaPlugin implements Listener {

    private NamespacedKey coinKey, placedKey;
    private final Random rng = new Random();
    private File dataFile;
    private YamlConfiguration data;
    private boolean dirty = false;
    private boolean wellMode;
    private String wellWorld;
    private int wellX, wellY, wellZ, wellRadius;

    @Override
    public void onEnable() {
        coinKey = new NamespacedKey(this, "luckycoin");
        placedKey = new NamespacedKey(this, "lcplaced");
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.getParentFile().exists()) dataFile.getParentFile().mkdirs();
        data = YamlConfiguration.loadConfiguration(dataFile);
        getConfig().addDefault("drop-chance", 0.01);
        getConfig().addDefault("free-coin-every-days", 10);
        getConfig().addDefault("survival-only", true);
        getConfig().addDefault("wishing-well.enabled", false);
        getConfig().addDefault("wishing-well.world", "world");
        getConfig().addDefault("wishing-well.x", 0);
        getConfig().addDefault("wishing-well.y", 64);
        getConfig().addDefault("wishing-well.z", 0);
        getConfig().addDefault("wishing-well.radius", 2);
        getConfig().options().copyDefaults(true);
        saveConfig();
        loadWell();
        getServer().getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (dirty) { try { data.save(dataFile); } catch (Exception ignored) {} dirty = false; }
        }, 200L, 200L);
        getLogger().info("MAVOLuckyCoins enabled - may fortune find you.");
    }

    @Override
    public void onDisable() {
        try { data.save(dataFile); } catch (Exception ignored) {}
    }

    private void loadWell() {
        wellMode = getConfig().getBoolean("wishing-well.enabled", false);
        wellWorld = getConfig().getString("wishing-well.world", "world");
        wellX = getConfig().getInt("wishing-well.x", 0);
        wellY = getConfig().getInt("wishing-well.y", 64);
        wellZ = getConfig().getInt("wishing-well.z", 0);
        wellRadius = getConfig().getInt("wishing-well.radius", 2);
    }

    private boolean survivalOnly(Player pl) {
        return getConfig().getBoolean("survival-only", true)
                && pl.getGameMode() != org.bukkit.GameMode.SURVIVAL;
    }

    // ---------------- the coin item ----------------
    private ItemStack makeCoin(int amount) {
        ItemStack it = new ItemStack(Material.SUNFLOWER, amount);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&e&l\u26C0 Lucky Coin"));
        m.setLore(Arrays.asList(
                ChatColor.GRAY + "Toss it into the " + ChatColor.AQUA + "Wishing Well" + ChatColor.GRAY + " at spawn",
                ChatColor.GRAY + "to trade it for... something.",
                ChatColor.DARK_GRAY + "MAVOcraft fortune token"));
        m.addEnchant(Enchantment.UNBREAKING, 1, true);
        m.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);
        m.getPersistentDataContainer().set(coinKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    private boolean isCoin(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(coinKey, PersistentDataType.BYTE);
    }

    private void giveCoin(Player pl, String reason) {
        ItemStack coin = makeCoin(1);
        var left = pl.getInventory().addItem(coin);
        if (!left.isEmpty()) pl.getWorld().dropItemNaturally(pl.getLocation(), coin);
        pl.playSound(pl.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.8f);
        pl.sendMessage(ChatColor.YELLOW + "\u26C0 " + ChatColor.GOLD + "A Lucky Coin! " + ChatColor.GRAY + reason);
    }

    // ---------------- 1% drops from grinding ----------------
    private void tryDrop(Player pl) {
        if (survivalOnly(pl)) return;
        if (rng.nextDouble() < getConfig().getDouble("drop-chance", 0.01))
            giveCoin(pl, "(lucky drop!)");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        e.getBlock().getChunk().getPersistentDataContainer(); // ensure chunk pdc exists
        long k = (((long) (e.getBlock().getY() + 512)) << 8) | ((e.getBlock().getX() & 15) << 4) | (e.getBlock().getZ() & 15);
        var pdc = e.getBlock().getChunk().getPersistentDataContainer();
        long[] arr = pdc.get(placedKey, PersistentDataType.LONG_ARRAY);
        if (arr == null) pdc.set(placedKey, PersistentDataType.LONG_ARRAY, new long[]{k});
        else {
            for (long v : arr) if (v == k) return;
            long[] out = Arrays.copyOf(arr, arr.length + 1);
            out[arr.length] = k;
            pdc.set(placedKey, PersistentDataType.LONG_ARRAY, out);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        long k = (((long) (e.getBlock().getY() + 512)) << 8) | ((e.getBlock().getX() & 15) << 4) | (e.getBlock().getZ() & 15);
        long[] arr = e.getBlock().getChunk().getPersistentDataContainer().get(placedKey, PersistentDataType.LONG_ARRAY);
        if (arr != null) for (long v : arr) if (v == k) return; // player-placed: no luck
        tryDrop(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onKill(EntityDeathEvent e) {
        Player k = e.getEntity().getKiller();
        if (k != null && !(e.getEntity() instanceof Player)) tryDrop(k);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent e) {
        if (e.getState() == PlayerFishEvent.State.CAUGHT_FISH) tryDrop(e.getPlayer());
    }

    // ---------------- /ccollect: free coin every 10 MC days ----------------
    private boolean handleCollect(Player pl) {
        int everyDays = getConfig().getInt("free-coin-every-days", 10);
        long day = pl.getWorld().getFullTime() / 24000L;
        long window = day / everyDays; // current 10-day window index
        long lastWindow = data.getLong("collect." + pl.getUniqueId(), -1);
        if (lastWindow == window) {
            long nextDay = (window + 1) * everyDays;
            pl.sendMessage(ChatColor.RED + "Already collected this window! Next free coin on MC day " + nextDay
                    + ChatColor.GRAY + " (now day " + day + "). Uncollected coins don't stack!");
            return true;
        }
        data.set("collect." + pl.getUniqueId(), window);
        dirty = true;
        giveCoin(pl, "(free collection - next in " + everyDays + " MC days)");
        return true;
    }

    // ---------------- /wish ----------------
    private static final List<Material> GEAR = new ArrayList<>();
    private static final List<Integer> GEAR_W = new ArrayList<>();
    private static int GEAR_TOTAL = 0;
    private static void addGear(String matName, int w) {
        Material m = Material.matchMaterial(matName);
        if (m == null) return;
        GEAR.add(m); GEAR_W.add(w); GEAR_TOTAL += w;
    }
    static {
        // tier weights: common junk likely, netherite a jackpot
        String[] armorTiers = {"LEATHER", "CHAINMAIL", "IRON", "GOLDEN", "DIAMOND", "NETHERITE"};
        String[] toolTiers  = {"WOODEN", "STONE", "IRON", "GOLDEN", "DIAMOND", "NETHERITE"};
        int[] tierW = {28, 22, 18, 14, 8, 3};
        for (int i = 0; i < armorTiers.length; i++)
            for (String piece : List.of("HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS"))
                addGear(armorTiers[i] + "_" + piece, tierW[i]);
        for (int i = 0; i < toolTiers.length; i++)
            for (String tool : List.of("SWORD", "AXE", "PICKAXE", "SHOVEL", "HOE"))
                addGear(toolTiers[i] + "_" + tool, tierW[i]);
        addGear("BOW", 12); addGear("CROSSBOW", 10); addGear("FISHING_ROD", 12);
        addGear("SHIELD", 12); addGear("TRIDENT", 3); addGear("ELYTRA", 1);
    }

    private Material pickGear() {
        int r = rng.nextInt(GEAR_TOTAL);
        for (int i = 0; i < GEAR.size(); i++) { r -= GEAR_W.get(i); if (r < 0) return GEAR.get(i); }
        return GEAR.get(0);
    }

    private boolean handleWish(Player pl) {
        if (wellMode) {
            pl.sendMessage(ChatColor.RED + "Wishes are made at the " + ChatColor.AQUA + "Wishing Well" + ChatColor.RED + " now!");
            pl.sendMessage(ChatColor.GRAY + "Visit spawn and " + ChatColor.YELLOW + "toss (Q) a \u26C0 Lucky Coin" + ChatColor.GRAY + " into the well...");
            return true;
        }
        ItemStack hand = pl.getInventory().getItemInMainHand();
        if (!isCoin(hand)) {
            pl.sendMessage(ChatColor.RED + "Hold a " + ChatColor.YELLOW + "\u26C0 Lucky Coin" + ChatColor.RED + " in your main hand to /wish!");
            return true;
        }
        hand.setAmount(hand.getAmount() - 1);
        grantWish(pl);
        return true;
    }

    private void grantWish(Player pl) {
        ItemStack prize;
        if (rng.nextDouble() < 0.25) {
            // gear wish: random tier + random enchants
            Material m = pickGear();
            prize = new ItemStack(m);
            ItemMeta meta = prize.getItemMeta();
            List<Enchantment> pool = new ArrayList<>();
            for (Enchantment en : Registry.ENCHANTMENT)
                if (en.canEnchantItem(prize) && !en.isCursed()) pool.add(en);
            int count = rng.nextInt(3) + (rng.nextDouble() < 0.15 ? 2 : 0); // 0-2, 15% for 2-4
            java.util.Collections.shuffle(pool, rng);
            int added = 0;
            for (Enchantment en : pool) {
                if (added >= count) break;
                boolean conflict = false;
                for (Enchantment have : meta.getEnchants().keySet())
                    if (en.conflictsWith(have)) { conflict = true; break; }
                if (conflict) continue;
                meta.addEnchant(en, 1 + rng.nextInt(en.getMaxLevel()), true);
                added++;
            }
            prize.setItemMeta(meta);
        } else {
            // literally anything (item-form, obtainable-ish)
            List<Material> all = new ArrayList<>();
            for (Material m : Material.values()) {
                if (!m.isItem() || m.isAir() || m.isLegacy()) continue;
                String n = m.name();
                if (n.contains("COMMAND") || n.contains("STRUCTURE") || n.contains("JIGSAW")
                        || n.contains("BARRIER") || n.contains("DEBUG") || n.contains("SPAWN_EGG")
                        || n.equals("BEDROCK") || n.contains("REINFORCED_DEEPSLATE") || n.contains("LIGHT")) continue;
                all.add(m);
            }
            Material m = all.get(rng.nextInt(all.size()));
            int max = m.getMaxStackSize();
            int amount = 1 + rng.nextInt(max);
            prize = new ItemStack(m, amount);
        }
        var left = pl.getInventory().addItem(prize);
        for (ItemStack rest : left.values()) pl.getWorld().dropItemNaturally(pl.getLocation(), rest);
        String pname = prize.getItemMeta() != null && prize.getItemMeta().hasDisplayName()
                ? prize.getItemMeta().getDisplayName()
                : prize.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ');
        pl.playSound(pl.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 0.6f);
        pl.playSound(pl.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
        pl.sendMessage(ChatColor.GOLD + "\u26C0 The coin spins... " + ChatColor.YELLOW + "you got "
                + ChatColor.AQUA + prize.getAmount() + "x " + pname + ChatColor.YELLOW + "!");
        Bukkit.broadcastMessage(ChatColor.GRAY + pl.getName() + " wished on a \u26C0 Lucky Coin and got "
                + ChatColor.AQUA + prize.getAmount() + "x " + pname);
    }

    // ---------------- wishing well: toss a coin in ----------------
    @EventHandler(ignoreCancelled = true)
    public void onCoinToss(org.bukkit.event.player.PlayerDropItemEvent e) {
        if (!wellMode) return;
        org.bukkit.entity.Item drop = e.getItemDrop();
        if (!isCoin(drop.getItemStack())) return;
        Player pl = e.getPlayer();
        org.bukkit.World w = Bukkit.getWorld(wellWorld);
        if (w == null || !pl.getWorld().equals(w)) return;
        org.bukkit.Location l = pl.getLocation();
        if (Math.abs(l.getBlockX() - wellX) > wellRadius + 3
                || Math.abs(l.getBlockZ() - wellZ) > wellRadius + 3
                || Math.abs(l.getBlockY() - wellY) > 8) return;

        int count = drop.getItemStack().getAmount();
        drop.remove();
        org.bukkit.Location well = new org.bukkit.Location(w, wellX + 0.5, wellY, wellZ + 0.5);
        w.spawnParticle(org.bukkit.Particle.SPLASH, well, 40, 0.4, 0.3, 0.4, 0.1);
        w.spawnParticle(org.bukkit.Particle.END_ROD, well, 25, 0.3, 0.6, 0.3, 0.05);
        w.playSound(well, Sound.ENTITY_GENERIC_SPLASH, 1f, 1.1f);
        w.playSound(well, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 0.8f);
        for (int i = 0; i < count; i++) {
            final int delay = i * 15;
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (pl.isOnline()) grantWish(pl);
            }, 20L + delay);
        }
    }

    private boolean handleWellSet(Player pl) {
        getConfig().set("wishing-well.enabled", true);
        getConfig().set("wishing-well.world", pl.getWorld().getName());
        getConfig().set("wishing-well.x", pl.getLocation().getBlockX());
        getConfig().set("wishing-well.y", pl.getLocation().getBlockY());
        getConfig().set("wishing-well.z", pl.getLocation().getBlockZ());
        saveConfig();
        loadWell();
        spawnWellHolo();
        pl.sendMessage(ChatColor.AQUA + "Wishing Well set here! " + ChatColor.GRAY + "("
                + wellX + ", " + wellY + ", " + wellZ + ") - /wish is now disabled; players toss coins in."
                + ChatColor.AQUA + " Floating sign placed.");
        return true;
    }

    // ---------------- floating sign over the well ----------------
    private void spawnWellHolo() {
        org.bukkit.World w = Bukkit.getWorld(wellWorld);
        if (w == null) return;
        // remove old holo if recorded
        String old = getConfig().getString("wishing-well.holo-uuid");
        if (old != null) {
            try {
                org.bukkit.entity.Entity e = Bukkit.getEntity(UUID.fromString(old));
                if (e != null) e.remove();
            } catch (Exception ignored) {}
        }
        org.bukkit.Location loc = new org.bukkit.Location(w, wellX + 0.5, wellY + 4.6, wellZ + 0.5);
        loc.getChunk().load();
        org.bukkit.entity.TextDisplay td = w.spawn(loc, org.bukkit.entity.TextDisplay.class, d -> {
            d.setText(ChatColor.AQUA + "" + ChatColor.BOLD + "\u2728 WISHING WELL \u2728"
                    + "\n" + ChatColor.WHITE + "Toss " + ChatColor.YELLOW + "(Q)" + ChatColor.WHITE + " a " + ChatColor.GOLD + "\u26C0 Lucky Coin" + ChatColor.WHITE + " in"
                    + "\n" + ChatColor.GRAY + "75% any item \u00B7 25% enchanted gear"
                    + "\n" + ChatColor.AQUA + "Fortune favours the bold!");
            d.setBillboard(org.bukkit.entity.Display.Billboard.CENTER);
            d.setShadowed(true);
            d.setSeeThrough(true);
            try { d.setDefaultBackground(false); d.setBackgroundColor(org.bukkit.Color.fromARGB(200, 5, 15, 25)); } catch (Throwable ignored) {}
            d.setAlignment(org.bukkit.entity.TextDisplay.TextAlignment.CENTER);
            d.setLineWidth(260);
            var tr = d.getTransformation();
            tr.getScale().set(1.9f);
            d.setTransformation(tr);
            d.setViewRange(1.3f);
            try { d.setBrightness(new org.bukkit.entity.Display.Brightness(15, 15)); } catch (Throwable ignored) {}
            d.setPersistent(true);
        });
        getConfig().set("wishing-well.holo-uuid", td.getUniqueId().toString());
        saveConfig();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player pl)) { sender.sendMessage("In-game only."); return true; }
        if (command.getName().equalsIgnoreCase("wish")) {
            if (args.length == 1 && args[0].equalsIgnoreCase("well") && pl.hasPermission("mavolucky.admin"))
                return handleWellSet(pl);
            return handleWish(pl);
        }
        if (command.getName().equalsIgnoreCase("ccollect")) {
            // admin: /ccollect give [amount] - conjure genuine lucky coins for testing
            if (args.length >= 1 && args[0].equalsIgnoreCase("give") && pl.hasPermission("mavolucky.admin")) {
                int n = 1;
                if (args.length >= 2) try { n = Integer.parseInt(args[1]); } catch (NumberFormatException ignored) {}
                n = Math.max(1, Math.min(64, n));
                ItemStack coins = makeCoin(n);
                var left = pl.getInventory().addItem(coins);
                for (ItemStack rest : left.values()) pl.getWorld().dropItemNaturally(pl.getLocation(), rest);
                pl.playSound(pl.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.8f);
                pl.sendMessage(ChatColor.YELLOW + "\u26C0 " + ChatColor.GOLD + "Conjured " + n + " Lucky Coin(s). " + ChatColor.GRAY + "(admin)");
                return true;
            }
            return handleCollect(pl);
        }
        return true;
    }
}
