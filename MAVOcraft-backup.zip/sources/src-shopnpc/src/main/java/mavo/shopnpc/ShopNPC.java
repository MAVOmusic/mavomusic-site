package mavo.shopnpc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityPortalEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.EntityTransformEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public final class ShopNPC extends JavaPlugin implements Listener, TabCompleter {

    private NamespacedKey npcKey;
    private final Map<UUID, Long> clickCooldown = new HashMap<>();

    @Override
    public void onEnable() {
        npcKey = new NamespacedKey(this, "shopnpc");
        saveDefaultConfigIfMissing();
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("shopnpc") != null) getCommand("shopnpc").setTabCompleter(this);
        // re-apply protections to known NPCs after restart
        Bukkit.getScheduler().runTaskLater(this, this::reapplyAll, 60L);
        getLogger().info("MAVOShopNPC enabled.");
    }

    private void saveDefaultConfigIfMissing() {
        if (!new java.io.File(getDataFolder(), "config.yml").exists()) {
            getConfig().set("npcs", new HashMap<String, Object>());
            saveConfig();
        }
    }

    private void reapplyAll() {
        ConfigurationSection s = getConfig().getConfigurationSection("npcs");
        if (s == null) return;
        int found = 0;
        for (String name : s.getKeys(false)) {
            String uid = s.getString(name + ".uuid");
            if (uid == null) continue;
            Entity e = Bukkit.getEntity(UUID.fromString(uid));
            if (e instanceof Villager v) { protect(v); found++; }
        }
        getLogger().info("Re-applied protection to " + found + " shop NPC(s).");
    }

    private void protect(Villager v) {
        v.setAI(false);
        v.setInvulnerable(true);
        v.setSilent(true);
        v.setPersistent(true);
        v.setRemoveWhenFarAway(false);
        v.setCollidable(false);
        v.setCanPickupItems(false);
        v.setBreed(false);
        v.setAgeLock(true);
        v.setAdult();
        v.setCustomNameVisible(true);
    }

    private boolean isShopNpc(Entity e) {
        return e != null && e.getPersistentDataContainer().has(npcKey, PersistentDataType.STRING);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteract(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (!isShopNpc(e.getRightClicked())) return;
        e.setCancelled(true);
        Player pl = e.getPlayer();
        long now = System.currentTimeMillis();
        Long last = clickCooldown.get(pl.getUniqueId());
        if (last != null && now - last < 600) return; // debounce double-fire
        clickCooldown.put(pl.getUniqueId(), now);
        String cmd = e.getRightClicked().getPersistentDataContainer().get(npcKey, PersistentDataType.STRING);
        if (cmd == null || cmd.isEmpty()) cmd = "shop";
        while (cmd.startsWith("/")) cmd = cmd.substring(1);
        pl.playSound(pl.getLocation(), Sound.ENTITY_VILLAGER_TRADE, 1f, 1f);
        pl.performCommand(cmd);
    }

    // ---- protections ----
    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (isShopNpc(e.getEntity())) e.setCancelled(true);
    }
    @EventHandler
    public void onCombust(EntityCombustEvent e) {
        if (isShopNpc(e.getEntity())) e.setCancelled(true);
    }
    @EventHandler
    public void onTransform(EntityTransformEvent e) {
        if (isShopNpc(e.getEntity())) e.setCancelled(true); // no zombification
    }
    @EventHandler
    public void onPortal(EntityPortalEvent e) {
        if (isShopNpc(e.getEntity())) e.setCancelled(true);
    }
    @EventHandler
    public void onTarget(EntityTargetEvent e) {
        if (e.getTarget() != null && isShopNpc(e.getTarget())) e.setCancelled(true);
    }

    // ---- commands ----
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player pl)) { sender.sendMessage("In-game only."); return true; }
        if (args.length == 0) {
            pl.sendMessage(ChatColor.RED + "/shopnpc spawn <name> [command]  " + ChatColor.GRAY + "(spawns at your feet)");
            pl.sendMessage(ChatColor.RED + "/shopnpc setcmd <name> <command>");
            pl.sendMessage(ChatColor.RED + "/shopnpc remove <name>");
            pl.sendMessage(ChatColor.RED + "/shopnpc list");
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("spawn")) {
            if (args.length < 2) { pl.sendMessage(ChatColor.RED + "Name it! /shopnpc spawn <name> [command]"); return true; }
            String name = args[1];
            String cmd = args.length > 2 ? String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)) : "shop";
            while (cmd.startsWith("/")) cmd = cmd.substring(1);
            if (cmd.isBlank()) cmd = "shop";
            if (getConfig().contains("npcs." + name)) {
                pl.sendMessage(ChatColor.RED + "An NPC named " + name + " already exists. Remove it first.");
                return true;
            }
            Location loc = pl.getLocation().clone();
            Villager v = pl.getWorld().spawn(loc, Villager.class);
            v.setProfession(Villager.Profession.NITWIT);
            v.setVillagerType(Villager.Type.PLAINS);
            v.setCustomName(ChatColor.translateAlternateColorCodes('&',
                    "&c&l" + name.replace('_', ' ') + " &9&l\u2726"));
            protect(v);
            v.getPersistentDataContainer().set(npcKey, PersistentDataType.STRING, cmd);
            getConfig().set("npcs." + name + ".uuid", v.getUniqueId().toString());
            getConfig().set("npcs." + name + ".command", cmd);
            getConfig().set("npcs." + name + ".world", loc.getWorld().getName());
            getConfig().set("npcs." + name + ".x", loc.getX());
            getConfig().set("npcs." + name + ".y", loc.getY());
            getConfig().set("npcs." + name + ".z", loc.getZ());
            saveConfig();
            pl.sendMessage(ChatColor.GREEN + "Shop NPC " + ChatColor.AQUA + name + ChatColor.GREEN
                    + " spawned. Right-click runs: " + ChatColor.YELLOW + "/" + cmd);
            return true;
        }
        if (sub.equals("remove")) {
            if (args.length < 2) { pl.sendMessage(ChatColor.RED + "/shopnpc setcmd <name> <command>");
            pl.sendMessage(ChatColor.RED + "/shopnpc remove <name>"); return true; }
            String name = args[1];
            String uid = getConfig().getString("npcs." + name + ".uuid");
            if (uid == null) { pl.sendMessage(ChatColor.RED + "No NPC named " + name); return true; }
            Entity ent = Bukkit.getEntity(UUID.fromString(uid));
            if (ent != null) ent.remove();
            String oldHolo = getConfig().getString("npcs." + name + ".holo-uuid");
            if (oldHolo != null) {
                try { Entity oh = Bukkit.getEntity(UUID.fromString(oldHolo)); if (oh != null) oh.remove(); } catch (Exception ignored) {}
            }
            getConfig().set("npcs." + name, null);
            saveConfig();
            pl.sendMessage(ChatColor.GREEN + "Removed NPC " + name + (ent == null ? " (entity was already gone)" : ""));
            return true;
        }
        if (sub.equals("setcmd")) {
            if (args.length < 3) { pl.sendMessage(ChatColor.RED + "/shopnpc setcmd <name> <command>"); return true; }
            String name = args[1];
            String uid = getConfig().getString("npcs." + name + ".uuid");
            if (uid == null) { pl.sendMessage(ChatColor.RED + "No NPC named " + name); return true; }
            String cmd = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
            while (cmd.startsWith("/")) cmd = cmd.substring(1);
            if (cmd.isBlank()) { pl.sendMessage(ChatColor.RED + "Give a real command."); return true; }
            Entity ent = Bukkit.getEntity(UUID.fromString(uid));
            if (ent == null) { pl.sendMessage(ChatColor.RED + "NPC entity not loaded - go near it and retry."); return true; }
            ent.getPersistentDataContainer().set(npcKey, PersistentDataType.STRING, cmd);
            getConfig().set("npcs." + name + ".command", cmd);
            saveConfig();
            pl.sendMessage(ChatColor.GREEN + "NPC " + ChatColor.AQUA + name + ChatColor.GREEN + " now runs: " + ChatColor.YELLOW + "/" + cmd);
            return true;
        }
        if (sub.equals("list")) {
            ConfigurationSection s = getConfig().getConfigurationSection("npcs");
            if (s == null || s.getKeys(false).isEmpty()) { pl.sendMessage(ChatColor.GRAY + "No shop NPCs yet."); return true; }
            for (String n : s.getKeys(false))
                pl.sendMessage(ChatColor.AQUA + n + ChatColor.GRAY + " -> /" + s.getString(n + ".command", "shop")
                        + ChatColor.DARK_GRAY + " @ " + s.getString(n + ".world") + " "
                        + (int) s.getDouble(n + ".x") + "," + (int) s.getDouble(n + ".y") + "," + (int) s.getDouble(n + ".z"));
            return true;
        }
        if (sub.equals("adopt")) {
            // re-register an orphaned NPC (entity exists + is tagged, but missing from config)
            if (args.length < 2) { pl.sendMessage(ChatColor.RED + "/shopnpc adopt <name> [command] " + ChatColor.GRAY + "(stand next to the NPC)"); return true; }
            String name = args[1];
            if (getConfig().contains("npcs." + name)) {
                pl.sendMessage(ChatColor.RED + "An NPC named " + name + " already exists in the registry.");
                return true;
            }
            Villager nearest = null;
            double best = Double.MAX_VALUE;
            for (Entity ent : pl.getNearbyEntities(6, 6, 6)) {
                if (!(ent instanceof Villager v) || !isShopNpc(v)) continue;
                double d = ent.getLocation().distanceSquared(pl.getLocation());
                if (d < best) { best = d; nearest = v; }
            }
            if (nearest == null) {
                pl.sendMessage(ChatColor.RED + "No shop NPC within 6 blocks. Stand right next to it.");
                return true;
            }
            // don't adopt one that's already registered under another name
            ConfigurationSection sec = getConfig().getConfigurationSection("npcs");
            if (sec != null) for (String n : sec.getKeys(false)) {
                if (nearest.getUniqueId().toString().equals(sec.getString(n + ".uuid"))) {
                    pl.sendMessage(ChatColor.RED + "That NPC is already registered as " + ChatColor.AQUA + n);
                    return true;
                }
            }
            String cmd;
            if (args.length > 2) {
                cmd = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
                while (cmd.startsWith("/")) cmd = cmd.substring(1);
                if (cmd.isBlank()) cmd = "shop";
                nearest.getPersistentDataContainer().set(npcKey, PersistentDataType.STRING, cmd);
            } else {
                cmd = nearest.getPersistentDataContainer().get(npcKey, PersistentDataType.STRING);
                if (cmd == null || cmd.isEmpty()) cmd = "shop";
            }
            protect(nearest);
            Location loc = nearest.getLocation();
            getConfig().set("npcs." + name + ".uuid", nearest.getUniqueId().toString());
            getConfig().set("npcs." + name + ".command", cmd);
            getConfig().set("npcs." + name + ".world", loc.getWorld().getName());
            getConfig().set("npcs." + name + ".x", loc.getX());
            getConfig().set("npcs." + name + ".y", loc.getY());
            getConfig().set("npcs." + name + ".z", loc.getZ());
            saveConfig();
            pl.sendMessage(ChatColor.GREEN + "Adopted nearest NPC as " + ChatColor.AQUA + name + ChatColor.GREEN
                    + ". Right-click runs: " + ChatColor.YELLOW + "/" + cmd);
            return true;
        }
        if (sub.equals("holo")) {
            if (args.length < 3) {
                pl.sendMessage(ChatColor.RED + "/shopnpc holo <name> <text - use | for a new line>");
                pl.sendMessage(ChatColor.GRAY + "Example: /shopnpc holo Tutorial_Guide &a&l\u270E TUTORIAL|&fNew here? Right-click me!");
                return true;
            }
            String name = args[1];
            String uid = getConfig().getString("npcs." + name + ".uuid");
            if (uid == null) { pl.sendMessage(ChatColor.RED + "No NPC named " + name); return true; }
            Entity ent = Bukkit.getEntity(UUID.fromString(uid));
            if (ent == null) { pl.sendMessage(ChatColor.RED + "NPC entity not loaded - go near it and retry."); return true; }
            // remove old holo
            String oldHolo = getConfig().getString("npcs." + name + ".holo-uuid");
            if (oldHolo != null) {
                try { Entity oh = Bukkit.getEntity(UUID.fromString(oldHolo)); if (oh != null) oh.remove(); } catch (Exception ignored) {}
            }
            String raw = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
            String text = ChatColor.translateAlternateColorCodes('&', raw.replace("|", "\n"));
            Location hl = ent.getLocation().clone().add(0, 2.65, 0);
            org.bukkit.entity.TextDisplay td = ent.getWorld().spawn(hl, org.bukkit.entity.TextDisplay.class, d -> {
                d.setText(text);
                d.setBillboard(org.bukkit.entity.Display.Billboard.CENTER);
                d.setShadowed(true);
                d.setSeeThrough(true);
                try { d.setDefaultBackground(false); d.setBackgroundColor(org.bukkit.Color.fromARGB(190, 10, 10, 20)); } catch (Throwable ignored) {}
                d.setAlignment(org.bukkit.entity.TextDisplay.TextAlignment.CENTER);
                d.setLineWidth(200);
                var tr = d.getTransformation();
                tr.getScale().set(0.9f);
                d.setTransformation(tr);
                d.setViewRange(0.8f);
                try { d.setBrightness(new org.bukkit.entity.Display.Brightness(15, 15)); } catch (Throwable ignored) {}
                d.setPersistent(true);
            });
            getConfig().set("npcs." + name + ".holo-uuid", td.getUniqueId().toString());
            saveConfig();
            pl.sendMessage(ChatColor.GREEN + "Floating sign set above " + ChatColor.AQUA + name);
            return true;
        }
        if (sub.equals("holoremove")) {
            if (args.length < 2) { pl.sendMessage(ChatColor.RED + "/shopnpc holoremove <name>"); return true; }
            String name = args[1];
            String oldHolo = getConfig().getString("npcs." + name + ".holo-uuid");
            if (oldHolo == null) { pl.sendMessage(ChatColor.RED + "No floating sign recorded for " + name); return true; }
            try { Entity oh = Bukkit.getEntity(UUID.fromString(oldHolo)); if (oh != null) oh.remove(); } catch (Exception ignored) {}
            getConfig().set("npcs." + name + ".holo-uuid", null);
            saveConfig();
            pl.sendMessage(ChatColor.GREEN + "Floating sign removed from " + name);
            return true;
        }
        pl.sendMessage(ChatColor.RED + "Unknown subcommand.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("spawn", "remove", "setcmd", "list", "holo", "holoremove", "adopt"))
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("remove") || args[0].equalsIgnoreCase("setcmd") || args[0].equalsIgnoreCase("holo") || args[0].equalsIgnoreCase("holoremove"))) {
            ConfigurationSection s = getConfig().getConfigurationSection("npcs");
            if (s != null) for (String n : s.getKeys(false))
                if (n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(n);
        }
        return out;
    }
}
