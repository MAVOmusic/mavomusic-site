package mavo.spawn;

import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.projectiles.ProjectileSource;

public final class SpawnProtect extends JavaPlugin implements Listener {

    private static final String PREFIX = "\u00A74[\u00A7cMAVO\u00A79Spawn\u00A74]\u00A7r ";

    private String world;
    private int cx, cy, cz, radH, radV;
    private boolean requireCreative, noPvp, noHostiles;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadVals();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("MAVOSpawn enabled - protecting " + world + " (" + cx + "," + cy + "," + cz + ") r=" + radH + " h / " + radV + " v.");
    }

    private void loadVals() {
        reloadConfig();
        world = getConfig().getString("world", "world");
        cx = getConfig().getInt("center.x", -2578);
        cy = getConfig().getInt("center.y", 200);
        cz = getConfig().getInt("center.z", -1684);
        radH = getConfig().getInt("radius.horizontal", 60);
        radV = getConfig().getInt("radius.vertical", 60);
        requireCreative = getConfig().getBoolean("bypass-requires-creative", true);
        noPvp = getConfig().getBoolean("no-pvp", true);
        noHostiles = getConfig().getBoolean("no-hostile-spawns", true);
    }

    private boolean inRegion(Location l) {
        if (l.getWorld() == null || !l.getWorld().getName().equals(world)) return false;
        return Math.abs(l.getBlockX() - cx) <= radH
                && Math.abs(l.getBlockZ() - cz) <= radH
                && Math.abs(l.getBlockY() - cy) <= radV;
    }

    private boolean canBuild(Player p) {
        if (!p.hasPermission("mavospawn.bypass")) return false;
        return !requireCreative || p.getGameMode() == GameMode.CREATIVE;
    }

    private void deny(Player p) {
        p.sendMessage(PREFIX + "\u00A7cSpawn is protected. \u00A77Enjoy the sights - shop, trade, wish!");
    }

    /* ---------------- block protection ---------------- */

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (inRegion(e.getBlock().getLocation()) && !canBuild(e.getPlayer())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (inRegion(e.getBlock().getLocation()) && !canBuild(e.getPlayer())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if (inRegion(e.getBlock().getLocation()) && !canBuild(e.getPlayer())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (inRegion(e.getBlock().getLocation()) && !canBuild(e.getPlayer())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    /* ---------------- explosions / fire / entity grief ---------------- */

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        stripProtected(e.blockList());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        stripProtected(e.blockList());
    }

    private void stripProtected(List<Block> blocks) {
        Iterator<Block> it = blocks.iterator();
        while (it.hasNext()) if (inRegion(it.next().getLocation())) it.remove();
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        if (!inRegion(e.getBlock().getLocation())) return;
        Player p = e.getPlayer();
        if (p == null || !canBuild(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        if (inRegion(e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onEntityChangeBlock(EntityChangeBlockEvent e) {
        // endermen, wither, falling-block grief etc.
        if (!(e.getEntity() instanceof Player) && inRegion(e.getBlock().getLocation())) e.setCancelled(true);
    }

    /* ---------------- decorations (frames, stands, paintings) ---------------- */

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent e) {
        if (!inRegion(e.getEntity().getLocation())) return;
        if (e.getRemover() instanceof Player p && canBuild(p)) return;
        e.setCancelled(true);
        if (e.getRemover() instanceof Player p) deny(p);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onArmorStand(PlayerArmorStandManipulateEvent e) {
        if (inRegion(e.getRightClicked().getLocation()) && !canBuild(e.getPlayer())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageByEntityEvent e) {
        Entity victim = e.getEntity();
        if (!inRegion(victim.getLocation())) return;

        Player attacker = resolveAttacker(e.getDamager());

        // villagers/traders at spawn are shop infrastructure - untouchable
        if (victim instanceof org.bukkit.entity.AbstractVillager) {
            if (attacker == null || !canBuild(attacker)) {
                e.setCancelled(true);
                if (attacker != null) attacker.sendMessage(PREFIX + "\u00A7cThe spawn merchants are protected!");
            }
            return;
        }
        // decorations: only builders may destroy
        if (victim instanceof ItemFrame || victim instanceof ArmorStand) {
            if (attacker == null || !canBuild(attacker)) {
                e.setCancelled(true);
                if (attacker != null) deny(attacker);
            }
            return;
        }
        // pvp off at spawn
        if (noPvp && victim instanceof Player && attacker != null && attacker != victim) {
            e.setCancelled(true);
            attacker.sendMessage(PREFIX + "\u00A7cNo fighting at spawn!");
        }
    }

    private Player resolveAttacker(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof org.bukkit.entity.Projectile proj) {
            ProjectileSource src = proj.getShooter();
            if (src instanceof Player p) return p;
        }
        return null;
    }

    /* ---------------- hostile spawn suppression ---------------- */

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (!noHostiles) return;
        if (e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.CUSTOM
                || e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.SPAWNER_EGG
                || e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.COMMAND) return;
        if (e.getEntity() instanceof Enemy && inRegion(e.getLocation())) e.setCancelled(true);
    }

    /* ---------------- admin command ---------------- */

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("info")) {
            s.sendMessage(PREFIX + "\u00A79Region: \u00A77" + world + " center (" + cx + ", " + cy + ", " + cz + ") \u00A79radius \u00A77" + radH + " horizontal, " + radV + " vertical");
            s.sendMessage(PREFIX + "\u00A77Bypass: op/mavospawn.bypass" + (requireCreative ? " \u00A7c+ CREATIVE mode" : "") + " \u00B7 PvP " + (noPvp ? "\u00A7cOFF" : "\u00A79on") + " \u00A77\u00B7 hostile spawns " + (noHostiles ? "\u00A7cblocked" : "\u00A79allowed"));
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "sethere" -> {
                if (!(s instanceof Player p)) { s.sendMessage("In-game only."); return true; }
                getConfig().set("world", p.getWorld().getName());
                getConfig().set("center.x", p.getLocation().getBlockX());
                getConfig().set("center.y", p.getLocation().getBlockY());
                getConfig().set("center.z", p.getLocation().getBlockZ());
                saveConfig();
                loadVals();
                s.sendMessage(PREFIX + "\u00A79Center moved here. \u00A77(" + cx + ", " + cy + ", " + cz + ")");
            }
            case "radius" -> {
                if (a.length != 3) { s.sendMessage(PREFIX + "\u00A77Usage: /spawnprot radius <horizontal> <vertical>"); return true; }
                try {
                    getConfig().set("radius.horizontal", Integer.parseInt(a[1]));
                    getConfig().set("radius.vertical", Integer.parseInt(a[2]));
                    saveConfig();
                    loadVals();
                    s.sendMessage(PREFIX + "\u00A79Radius updated: \u00A77" + radH + " h / " + radV + " v");
                } catch (NumberFormatException ex) {
                    s.sendMessage(PREFIX + "\u00A7cNumbers only.");
                }
            }
            case "reload" -> {
                loadVals();
                s.sendMessage(PREFIX + "\u00A79Config reloaded.");
            }
            default -> s.sendMessage(PREFIX + "\u00A77/spawnprot [info|sethere|radius <h> <v>|reload]");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        if (a.length == 1) return List.of("info", "sethere", "radius", "reload");
        return List.of();
    }
}
