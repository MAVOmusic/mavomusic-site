package mavo.streaks;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class Streaks extends JavaPlugin implements Listener {

    private Economy econ;
    private File dataFile;
    private YamlConfiguration data;
    private boolean dirty = false;

    @Override
    public void onEnable() {
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.getParentFile().exists()) dataFile.getParentFile().mkdirs();
        data = YamlConfiguration.loadConfiguration(dataFile);
        getConfig().addDefault("base-reward", 20);
        getConfig().addDefault("per-day-bonus", 10);
        getConfig().addDefault("daily-cap", 100);
        getConfig().addDefault("weekly-bonus", 100);
        getConfig().options().copyDefaults(true);
        saveConfig();
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider();
        getServer().getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (dirty) { try { data.save(dataFile); } catch (Exception ignored) {} dirty = false; }
        }, 200L, 200L);
        getLogger().info("MAVOStreaks enabled - see you tomorrow.");
    }

    @Override
    public void onDisable() { try { data.save(dataFile); } catch (Exception ignored) {} }

    private long today() { return System.currentTimeMillis() / 86400000L; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        String k = "players." + p.getUniqueId();
        long last = data.getLong(k + ".last", -1);
        long today = today();
        if (last == today) return; // already counted today

        int streak = data.getInt(k + ".streak", 0);
        streak = (last == today - 1) ? streak + 1 : 1;
        int best = Math.max(streak, data.getInt(k + ".best", 0));
        data.set(k + ".streak", streak);
        data.set(k + ".best", best);
        data.set(k + ".last", today);
        data.set(k + ".name", p.getName());
        dirty = true;

        int base = getConfig().getInt("base-reward", 20);
        int bonus = getConfig().getInt("per-day-bonus", 10);
        int cap = getConfig().getInt("daily-cap", 100);
        int reward = Math.min(base + (streak - 1) * bonus, cap);
        boolean weekly = streak % 7 == 0;
        if (weekly) reward += getConfig().getInt("weekly-bonus", 100);

        if (econ != null) econ.depositPlayer(p, reward);
        final int fStreak = streak; final int fReward = reward; final boolean fWeekly = weekly;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline()) return;
            p.sendMessage(ChatColor.RED + "\uD83D\uDD25 " + ChatColor.GOLD + "Login streak: " + ChatColor.WHITE + fStreak
                    + (fStreak == 1 ? " day" : " days") + ChatColor.GOLD + "  +" + ChatColor.YELLOW + "\u26C3" + fReward
                    + (fWeekly ? ChatColor.AQUA + "  (weekly bonus!)" : ""));
            p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.5f);
            if (fWeekly)
                Bukkit.broadcastMessage(ChatColor.RED + "\uD83D\uDD25 " + ChatColor.GOLD + p.getName() + ChatColor.GRAY
                        + " is on a " + ChatColor.WHITE + fStreak + "-day" + ChatColor.GRAY + " login streak!");
        }, 60L);
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length > 0 && a[0].equalsIgnoreCase("top")) {
            ConfigurationSection sec = data.getConfigurationSection("players");
            List<String[]> rows = new ArrayList<>();
            if (sec != null) for (String id : sec.getKeys(false)) {
                long last = sec.getLong(id + ".last", -1);
                int streak = sec.getInt(id + ".streak", 0);
                if (last < today() - 1) streak = 0; // broken streak
                rows.add(new String[]{sec.getString(id + ".name", "?"), String.valueOf(streak), String.valueOf(sec.getInt(id + ".best", 0))});
            }
            rows.sort(Comparator.comparingInt((String[] r) -> Integer.parseInt(r[1])).reversed());
            s.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "\uD83D\uDD25 Top Login Streaks");
            int i = 1;
            for (String[] r : rows) {
                if (i > 10) break;
                s.sendMessage(ChatColor.GRAY + "" + i + ". " + ChatColor.WHITE + r[0] + ChatColor.GOLD + "  " + r[1] + " days" + ChatColor.DARK_GRAY + "  (best " + r[2] + ")");
                i++;
            }
            if (rows.isEmpty()) s.sendMessage(ChatColor.GRAY + "Nobody yet.");
            return true;
        }
        if (!(s instanceof Player p)) { s.sendMessage("Players only (try /streak top)."); return true; }
        String k = "players." + p.getUniqueId();
        long last = data.getLong(k + ".last", -1);
        int streak = data.getInt(k + ".streak", 0);
        if (last < today() - 1) streak = 0;
        p.sendMessage(ChatColor.RED + "\uD83D\uDD25 " + ChatColor.GOLD + "Your streak: " + ChatColor.WHITE + streak
                + (streak == 1 ? " day" : " days") + ChatColor.DARK_GRAY + "  (best " + data.getInt(k + ".best", 0) + ")"
                + ChatColor.GRAY + "  Log in daily to keep it going!");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return List.of("top");
        return List.of();
    }
}
